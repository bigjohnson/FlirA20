////////////////////////////////////////
// Behavior dba extends languageDba

function behavior()
{
//  languageDba.call(this);
  var protect = this._protected_(languageDba);


  protect.placeHolders = new Array();
  protect.placeHoldersName = new Array();

  protect.setupStrings();
}

