
////////////////////////////////////////
// controler object
function pageControler(initFile)
{
  
  var protect = this._protected_();
  languageDba.prototype = new mainDba();
  validate.prototype = new languageDba();
  behavior.prototype = new languageDba();
  setupPage.prototype = new behavior();
  protect.setupObject = new setupPage(initFile);
  protect.setupObject.setUrl(initFile);
  this.setup = function(){if (protect.setupObject.readyState() == false)wait("setup();", this, null); else setupControler();}
  this.readyState = function(){return protect.setupObject.readyState();}

  function setupControler()
  {
    var langObj = protect.setupObject.getObject("language");
    var lang = "English";
    if (langObj != null)
      lang = langObj.value;
    protect.setupObject.setLanguage(lang);
    protect.setupObject.initiate();
    //var validateObject = new validate();
  }
  this.getString = function(strID)
  {
      return protect.setupObject.getString(strID);
  }
}
var dba = null;
function initXMLscripts(initFile)
{
  if (dba != null)
    return;
  dba = new pageControler(initFile);
  dba.setup();
}
