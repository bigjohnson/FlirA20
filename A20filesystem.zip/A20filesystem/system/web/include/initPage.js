////////////////////////////////
// Keep while debugging

var debug = true;




var ssPage = null;
function setup(fileName)
{
    ssPage = new setupPage(fileName);
}


function setupUseScript()
{
    ssPage.useScripts();
}
// ====================================================================
// setupPage(fileName)
// Description: 
// loads page scripts and runs initFunctions
// Parameters:
// fileName: optional, XML-file defining scripts to load for current page. default = "/include/init.xml"
// Return value none
// ====================================================================
function setupPage(fileName)
{
var init = "/user/config/init.xml";
var numScripts = 0;
var scriptLoaded = 0;
var pageStr = String(window.location);
var pageArr = pageStr.split("/");
pageArr = pageArr[pageArr.length - 1].split(".");
var thisPage = pageArr[0];
var scriptTimer = null;
var hasFinnished = false;
var fileDoc = null;
var initScripts = new Array();
var initError = new String();
var preLoad = false;
var numPreLoad = 0;
var numPreLoaded = 0;
this.setupAll = setupFiles;
this.useScripts = useScript;


// check if default filename shall be used or not
  init = fileName == null ? init : fileName;
// check if document.implementation.createDocument exists
// otherwise use window.ActiveXObject if existing
  var hasImplementation = window.document.implementation != null ? true : false;
  var hasCreateDoc = false;
  if (hasImplementation)
    hasCreateDoc = window.document.implementation.createDocument != null ? true : false;
  if (hasCreateDoc == true)
  {
    fileDoc = window.document.implementation.createDocument("", "", null);
    fileDoc.onload = function(){setupFiles();}
    fileDoc.load(init);
  }
  else if (window.ActiveXObject)
  {
    fileDoc = new ActiveXObject("Microsoft.XMLDOM");
    fileDoc.onreadystatechange = function(){if (fileDoc.readyState == 4){setupFiles();}}
    fileDoc.load(init);
  }
  else
  {
    return;
  }
  

  // ====================================================================
  // setPreLoad() : private method defined in setupPage scope
  // Description: 
  // checks if all preload-scripts are loaded
  // Return value none
  // ====================================================================
  function setPreLoad()
  {
    var docScripts = document.getElementsByTagName("script");
    if (docScripts.length == 0)
    {
      if (scriptTimer == null)
        scriptTimer = window.setInterval("setPreLoad();", 50);
      return;
    }
    if (docScripts[0].readyState == null)
    {
      if (scriptTimer == null)
        scriptTimer = window.setInterval("setPreLoad();", 50);
      return;
    }
    if (scriptTimer != null)
      window.clearInterval(scriptTimer);
    if (preLoad == true)
      return;  
    if (docScripts.length == 0)
      return;
    var scrLoad = 0;
    if (docScripts[0].readyState != null)
    {
      for (var i = 0; i < docScripts.length; i++)
      {
        if (docScripts[i].readyState == "complete" || docScripts[i].readyState == "loaded")
          scrLoad++;
      }
    }
    numPreLoaded = scrLoad;
    if (numPreLoaded < numPreLoad)
      return;
    preLoad = true;
    setupFiles();
  }

  // ====================================================================
  // setupFiles() : private method defined in setupPage scope
  // Description: 
  // loads all script files
  // Return value none
  // ====================================================================
  function setupFiles()
  {
    preLoad = false;
    var scriptsList = fileDoc.getElementsByTagName("scripts");
    var pages = null;
    var scripts = null;

    for (var i = 0; i < scriptsList.length; i++)
    {
       pages = scriptsList[i].getElementsByTagName("page");
       for (var j = 0; j < pages.length; j++)
       {
	 if (pages[j].getAttribute("id") == thisPage)
	 {
	   scripts = scriptsList[i].getElementsByTagName("script");
	   break;
	 }
       }
       if (scripts != null)
       {
	 break;
       }
    }
    if (scripts == null)
      return;
    var docScripts = document.getElementsByTagName("script");
    if (preLoadObj == null)
      preLoad = true;
    else if (preLoad = false)
    {
      var preLoadObj = document.getElementsByTagName("preLoad");
      var preLoadScripts = preLoadObj.getElementsByTagName("script");
      preLoad = preLoadScripts.length + docScripts.length;
      preLoaded = docScripts.length;

      if (preLoadScripts != null)
      {
        for (var i = 0; i < preLoadScripts.length; i++)
        {
          var fileName = preLoadScripts[i].getAttribute("fileName");
          var scriptObj = document.createElement("script");
          try
	  {
            scriptObj.setAttribute("type", "text/javascript");
            scriptObj.setAttribute("language", "JavaScript1.5");
            scriptObj.setAttribute("src", fileName);
	  }
	  catch (exeption)
	  {
	    if (debug)
	      alert (exeption);
	  }
          try
	  {
	    if (scriptObj.attachEvent != null)
              scriptObj.attachEvent("onreadystatechange", setPreLoaded);
	    else if (scriptObj.addEventListener != null)
	      scriptObj.addEventListener("load", setPreLoaded, false);

	  }
	  catch (exeption)
	  {
	    if (debug)
	      alert (exeption);
	  }
          document.body.appendChild(scriptObj);
        }
      }
    }
    if (preLoad == false)
      return;
    numScripts = scripts.length + docScripts.length;
    scriptLoaded = docScripts.length;
    if (scripts != null)
    {
      for (i = 0; i < scripts.length; i++)
      {
        var fileName = scripts[i].getAttribute("fileName");
        var initScript = scripts[i].getAttribute("init");
        var ref = scripts[i].getAttribute("ref");
        if (initScript.length > 0 || ref.length > 0)
        {
          initScripts[initScripts.length] = new Array(initScript, ref);
        }
        var scriptObj = document.createElement("script");
        try
	{
          scriptObj.setAttribute("type", "text/javascript");
          scriptObj.setAttribute("language", "JavaScript1.5");
          scriptObj.setAttribute("src", fileName);
	}
	catch (exeption)
	{
	    if (debug)
	      alert (exeption);
	}
        try
	{
          if (scriptObj.attachEvent != null)
             scriptObj.attachEvent("onreadystatechange", useScript);
	  else if (scriptObj.addEventListener != null)
            scriptObj.addEventListener("load", onScriptLoad, false);
	}
	catch (exeption)
	{
	    if (debug)
	      alert (exeption);
	}
        document.body.appendChild(scriptObj);
      }
    }
  }

  // ====================================================================
  // onScriptLoad() : private method defined in setupPage scope
  // Description: 
  // called when a script is loaded, W3C-DOM only
  // Return value none
  // ====================================================================
  function onScriptLoad()
  {
    scriptLoaded++;
    useScript();
  }

  // ====================================================================
  // useScript() : private method defined in setupPage scope
  // Description: 
  // called when a script is loaded, IE.
  // checks if all scripts are loaded and runs init-methods
  // Return value none
  // ====================================================================
  function useScript()
  {
    var docScripts = document.getElementsByTagName("script");
    if (docScripts[0].readyState == null && scriptTimer == null)
    {
      scriptTimer = window.setInterval("setupUseScript();", 50);
      return;
    }
    if (scriptTimer != null)
      window.clearInterval(scriptTimer);
    if (hasFinnished == true)
      return;
    if (docScripts.length == 0)
      return;
    if (docScripts[0].readyState != null)
    {
      var srcLoad = 0;
      for (var i = 0; i < docScripts.length; i++)
      {
        if (docScripts[i].readyState == "complete" || docScripts[i].readyState == "loaded")
          srcLoad++;
      }
      scriptLoaded = srcLoad;
    }
    if (scriptLoaded < numScripts)
      return;
    hasFinnished = true;

    for (var i = 0; i < initScripts.length; i++)
    {
      var evalArr = initScripts[i];
      if (evalArr.length != 2)
        continue;
      evalString = evalArr[0] + "('" + evalArr[1] + "');";
  //    try
      {
	  //initXMLscripts("/user/config/autmn.xml")
	  eval(evalString);
      }
  /*    catch(e)
      {
        if (e instanceof Error)
          initError += "[" + e.name + " : " + e.message + "]\n";
        if (debug)
          alert (initError);
      }*/
    }
  }



  function loadScripts()
  {
    var items = params.getElementsByTagName("scriptFile");
    numScripts = items.length;
    scriptLoaded = 0;
    for (var i = 0; i < items.length; i++)
    {
      var fn = items[i].firstChild.data;
      var js = document.createElement("script");
      js.setAttribute("type", "text/javascript");
      js.setAttribute("language", "JavaScript1.3");
      js.setAttribute("src", fn);
      js.attachEvent("onload", onScriptLoad);
      js.attachEvent("onreadystatechange", useScript);
      document.body.appendChild(js);
    }
  }
}

