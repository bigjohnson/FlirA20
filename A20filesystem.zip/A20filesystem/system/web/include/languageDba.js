
//////////////////////////////////////////
// Language dba extends mainDba

function languageDba()
{
  mainDba.call(this);
  var protect = this._protected_(mainDba);
  ////////////////////////////
  // stringDba protected members
     protect.strings = null;
     protect.setupStrings = setup;
     protect.getString = getStringFromID;
     protect.getID = getStringID;
     protect.getRefValue = getObjValue;
     protect.getOptions = getSelOptions;
     protect.getValidatorRules = getValidator;
     protect.getObjHandler = getObjEvent;
     protect.getCamObj = getCamObj;
     protect.getRadioGroups = getRadios;

  /////////////////////////////
  // protected methods
  protect.languageInitiate = languageAfterLoaded;

  ///////////////////////////
  // stringDba methods
  this.setupStrings = setup;
  this.initiate = languageAfterLoaded;
  


  ///////////////////////////
  // stringDba properties
  this.getString = getStringFromID;

  //////////////////////////
  // private methods

  function languageAfterLoaded()
  {
    protect.dbaInitiate();
    if (protect.ready != true)
    {
      setTimeout("afterLoaded()", 50);
      return;
    }
    setup();
  }

  function getStringFromID(identifyer)
  {
    if (protect.ready == false || protect.strings == null || identifyer == null)
      return null;
    var retString = null;
    for (var i = 0; i < protect.strings.length; i++)
    {
      if (protect.baseGetAttributeValue(protect.strings, "id", i) == identifyer)
      {
        retString = protect.baseGetObjectData(protect.strings, i);
        break;
      }
    }
    return retString;
  }
  function getStringID(ref)
  {
    var camObj = getCamObj();
    var nodes = protect.baseGetElements(camObj, "node");
    if (nodes == null)
	return null;
    var retId = null;
    for (i = 0; i < nodes.length; i++)
    {
      if (ref == protect.baseGetAttributeValue(nodes[i], "id"))
      {
        var retObj = protect.baseGetElements(nodes[i], "string");
        if (retObj.length == 0)
          return null;
        retId = protect.baseGetAttributeValue(retObj[0], "id");
        break;
      }
    }
    return retId;
  }
  function getObjValue(ref)
  {
    var camObj = getCamObj();
    var nodes = protect.baseGetElements(camObj, "node");
    if (nodes == null)
	return null;
    var refObj = null;
    var refArr = ref.split(".");
    var refIter = 0;
    for (var i = 0; i < refArr.length; i++)
	{
	    if (!isNaN(refArr[i]))
		{
		    refIter = Number(refArr[i]);
		    refArr[i] = "|iterator|";
		}
	}
    ref = refArr.join(".");
    for (i = 0; i < nodes.length; i++)
    {
      if (ref == protect.baseGetAttributeValue(nodes[i], "id"))
      {
        var refObj = protect.baseGetElements(nodes[i], "refobj");
        if (refObj.length == 0)
          return null;
        break;
      }
    }
    if (refObj == null)
      return null;
    var refName = protect.baseGetAttributeValue(refObj[0], "value");
    refArr = refName.split("|");
    for (var i = 0; i < refArr.length; i++)
    {
      if (refArr[i] == "iterator")
	refArr[i] = String(refIter);
    }
    refName = refArr.join("");
    var forms = document.forms;
    var frmElem = null;
    for (var i = 0; i < forms.length; i++)
    {
      frmElem = forms[i].elements[refName];
      if (frmElem != null)
	break;
    }
    if (frmElem == null)
      return null;
    var retVal = frmElem.value == null ? null : frmElem.value;
    if (retVal == null)
	return null;
    if (retVal.length == 0)
	return null;
    var concatIter = false;
    for (i = 0; i < retVal.length; i++)
    {
      if (isNaN(retVal.charAt(i)))
	continue;
      refIter = 0;
      do
      {
	refIter *= 10;
	refIter += Number(retVal.charAt(i));
	i++;
      }
      while(!isNaN(retVal.charAt(i)) && i < retVal.length)
      break;
    }
    var subst = protect.baseGetElements(refObj[0], "substitute");
    for (i = 0; i < subst.length; i++)
    {
      var substStr = protect.baseGetAttributeValue(subst[i], "value");
      refArr = substStr.split("|");
      for (var j = 0; j < refArr.length; j++)
      {
	if (refArr[j] == "iterator")
	{
	  refArr[j] = String(refIter);
	  concatIter = true;
	}
	if (refArr[j] == "noiterator")
	{
	  refArr[j] = String(refIter);
          concatIter = false;
	}
      }
      substStr = refArr.join("");
      if (retVal == substStr)
      {
        var strID = protect.baseGetAttributeValue(subst[i], "string");
        retVal = protect.getString(strID);
        break;
      }
    }
    if (concatIter)
	retVal += String(refIter);
    return retVal;
  }
  function getObjEvent(ref)
  {
    var refArr = ref.split(".");
    for (var i = 0; i < refArr.length; i++)
    {
	if (!isNaN(refArr[i]))
	    refArr[i] = "|iterator|";
    }
    ref = refArr.join(".");
    var camObj = getCamObj();
    var nodes = protect.baseGetElements(camObj, "node");
    if (nodes == null)
	return null;
    var handler = null;
    for (i = 0; i < nodes.length; i++)
    {
      if (ref == protect.baseGetAttributeValue(nodes[i], "id"))
      {
        var handler = protect.baseGetElements(nodes[i], "handler");
        if (handler.length == 0)
          return null;
        break;
      }
    }
    if (handler == null)
      return null;
    var eventNodes = protect.baseGetElements(handler[0], "script");
    var entries = protect.baseGetAttributeValue(handler[0], "entries");
    var handlerStr = protect.baseGetAttributeValue(handler[0], "event");
    var eventArr = new Array(entries);
    var eventStr = new String();
    var retArr = new Array();
    retArr[0] = handlerStr;
    for (i = 0; i < entries && i < eventNodes.length; i++)
    {
      var entry = protect.baseGetAttributeValue(eventNodes[i], "entry");
      var strRef = protect.baseGetElements(eventNodes[i], "string");
      if (strRef.length > 0)
      {
	var strID = protect.baseGetAttributeValue(strRef[0], "id");
	eventStr += protect.getString(strID);
      }
      else
      {
	eventStr += eventNodes[i].firstChild.data;
      }
    }
    retArr[1] = eventStr;
    return retArr;
  }
  function getRadios()
  {
    var camObj = getCamObj();
    if (camObj == null)
      return null;
    var radioGroups = protect.baseGetElements(camObj, "radiogroup");
    var retArr = new Array();
    for (var i = 0; i < radioGroups.length; i++)
    {
      var groupArr = new Array();
      var rName = protect.baseGetAttributeValue(radioGroups[i], "id");
      var rSelected = protect.baseGetAttributeValue(radioGroups[i], "selected");
      var visRef = protect.baseGetAttributeValue(radioGroups[i], "visible");
      var visRefObj = protect.getObject(visRef);
      if (visRefObj != null)
      {
	var visStr = visRefObj.value;
      }
      var rule = protect.baseGetElements(radioGroups[i], "rule");
      var placeholder = protect.baseGetAttributeValue(radioGroups[i], "placeholder");
      var ruleArr = new Array();
      if (rule.length > 0)
      {
        var affected = protect.baseGetAttributeValue(rule[0], "affected");
        var disable = protect.baseGetAttributeValue(rule[0], "disable");
	var refCount = protect.baseGetAttributeValue(rule[0], "refCount");
  	var refGroup = protect.baseGetAttributeValue(rule[0], "refGroup");
	var ruleValue = protect.baseGetAttributeValue(rule[0], "value");
        ruleArr[0] = affected;
	ruleArr[1] = disable;
	ruleArr[2] = refCount;
	ruleArr[3] = refGroup;
	ruleArr[4] = ruleValue;
      }
      var rButtons = protect.baseGetElements(radioGroups[i], "radio");
      for (var j = 0; j < rButtons.length; j++)
      {
	var val = protect.baseGetAttributeValue(rButtons[j], "value");
	if (visStr.indexOf(val) == -1)
	  continue;
	var str = protect.baseGetElements(rButtons[j], "string");
	var img = protect.baseGetElements(rButtons[j], "image");
        var iframe = protect.baseGetElements(rButtons[j], "iframe");
	var buttonArr = new Array();
	buttonArr[0] = rName;
	buttonArr[1] = val;
        if (str.length > 0)
	  buttonArr[2] = protect.baseGetAttributeValue(str[0], "id");
        if (img.length > 0)
          buttonArr[3] = protect.baseGetAttributeValue(img[0], "src");
	if (iframe.length > 0)
	{
	  var iframeArr = new Array(3);
	  iframeArr[0] = protect.baseGetAttributeValue(iframe[0], "src");
	  iframeArr[1] = protect.baseGetAttributeValue(iframe[0], "charset");
	  iframeArr[2] = protect.baseGetAttributeValue(iframe[0], "string");
	  buttonArr[4] = iframeArr;
	}
	buttonArr[5] = ruleArr;
        buttonArr[6] = placeholder;
        buttonArr[7] = rSelected;
	groupArr[groupArr.length] = buttonArr;
      }
      retArr[retArr.length] = groupArr;
    }
    return retArr;
  }

  function getSelOptions(obj)
  {
    if (obj == null)
      return null;
    var objName = obj.name;
    if (objName == null)
      return null;
    var objNameArr = objName.split(".");
    var objNameIterator = 0;
    for (var i = 0; i < objNameArr.length; i++)
	if (!isNaN(objNameArr[i]))
	{
	    objNameIterator = Number(objNameArr[i]);
	    objNameArr[i] = "|iterator|";
	}
    objName = objNameArr.join(".");
    var camObj = getCamObj();
    var selectors = protect.baseGetElements(camObj, "selector");
    var retArr = new Array();
    for (var i = 0; i < selectors.length; i++)
    {
      if (objName == protect.baseGetAttributeValue(selectors[i], "id"))
      {
        var selOpt = protect.baseGetAttributeValue(selectors[i], "selected");
	var selOptArr = selOpt.split(".");
	for (var j = 0; j < selOptArr.length; j++)
	{
	    if (selOptArr[j] == "|iterator|")
		selOptArr[j] = String(objNameIterator);
	}
        selOpt = selOptArr.join(".");
	var opts = protect.baseGetElements(selectors[i], "opt");
        var objFrm = obj.form;
        if (objFrm == null)
	  continue;
	var selObj = objFrm.elements[selOpt];
        var selVal = new String();
	if (selObj != null)
	  selVal = selObj.value;
	for (var j = 0; j < opts.length; j++)
	{
	  var optCondition = protect.baseGetAttributeValue(opts[j], "condition");
          if (optCondition != "null" && optCondition != null)
	  {
	    var condObj = protect.getObject(optCondition);
	    if (condObj != null)
	    {
	      if (condObj.value != null)
	      {
	        if (!isNaN(condObj.value))
		  if (Number(condObj.value) < 1)
		    continue;
	      }
	    }
	  }
	  var optTextID = protect.baseGetAttributeValue(opts[j], "text");
	  var optTextIDArr = optTextID.split("|");
	  var optVal = protect.baseGetAttributeValue(opts[j], "value");
	  var optLang = protect.baseGetAttributeValue(opts[j], "lang");
	  var rule = protect.baseGetElements(opts[j], "rule");
	  var optText = new String();
          

	  var tmpArr = new Array();
	  var bAdd = true;
          for (k = 0; k < optTextIDArr.length; k++)
	  {
	    var textArr = optTextIDArr[k].split(":");
	    if (textArr.length == 1)
              optText += protect.getString(optTextIDArr[0]);
	    else
	    {
	      switch(textArr[0])
	      {
	      case "counter":
		{
		  var refStr = textArr[1];
		  if (refStr.indexOf("ref,") != -1)
		  {
		    var refObj = protect.getObject(refStr.slice(4));
                    if (refObj == null)
			break;
		    if (refObj.value == null)
			break;
		    refStr = refObj.value;
		  }
                  textArr[1] = refStr;
		  var tmpObj = protect.getObject(textArr[1]);
		  if (tmpObj == null)
		      break;
		  if (tmpObj.value == null)
		      break;
		  if (isNaN(tmpObj.value))
		      break;
		  bAdd = false;
		  for(var l = 1; l <= tmpObj.value; l++)
		  {
		    var tmpText = optText + l;
                    var tmpVal = optVal == "|counter|" ? String(l) : optVal;
		    var optSelected = tmpVal == selVal ? true : false;
		    var ruleStr = getRuleString(rule, tmpVal, objNameIterator);
                    tmpArr = new Array(tmpText, tmpVal, optSelected, ruleStr, optLang);
                    retArr[retArr.length] = tmpArr;
		  }
		  break;
		}
	      }
	    }
	  }
	  if (bAdd)
	  {
	    var tmpValArr = optVal.split(":");
            var tmpVal = optVal;
            if (tmpValArr.length > 1)
	    {
	      switch(tmpValArr[0])
	      {
	      case "ref":
		{
		  var tmpObj = protect.getObject(tmpValArr[1]);
		  if (tmpObj == null)
		      break;
		  if (tmpObj.value == null)
		      break;
		  tmpVal = tmpObj.value;
		  if (tmpValArr.length > 2)
		  {
		    if (isNaN(tmpObj.value) || isNaN(tmpValArr[2]))
		      tmpVal += tmpValArr[2];
		    else
		      tmpVal = String(Number(tmpVal) + Number(tmpValArr[2]));
		  }
		  break;
		}
	      }
	    }
	    var optSelected = tmpVal == selVal ? true : false;
 	    var ruleStr = getRuleString(rule, tmpVal, objNameIterator);//new String();
            tmpArr = new Array(optText, tmpVal, optSelected, ruleStr, optLang);
	    retArr[retArr.length] = tmpArr;
	  }
	}
      }
    }
    return retArr;
  }
  function getArr(obj, entries, frmNum)
  {
    if (obj == null || entries == null)
      return null;
    if (entries == 0)
      return null;
    var arr = new Array(entries);
    var localObj = protect.baseGetElements(obj, "*");
    for (var i = 0; i < localObj.length; i++)
    {
      var entry = protect.baseGetAttributeValue(localObj[i], "entry");
      var objID = protect.baseGetAttributeValue(localObj[i], "id");
      switch (localObj[i].tagName)
      {
      case "refval":
	{
	  if (!isNaN(frmNum))
	  {
	      var objIDArr = objID.split(".");
	      for (var j = 0; j < objIDArr.length; j++)
	      {
		  if (objIDArr[j] == "|iterator|")
		      objIDArr[j] = String(frmNum);
	      }
              objID = objIDArr.join(".");
	  }
	  var valObj = protect.getObject(objID);
	  if (valObj == null)
	    break;
	  arr[entry] = valObj.value;
	  break;
	}
      case "operator":
	{
	  if (objID == "subtract")
	    arr[entry] = "-";
	  else if (objID == "add")
	    arr[entry] = "+";
	  break;
	}
      case "string":
	{
	  var str = protect.getString(objID);
	  arr[entry] = str;
	  break;
	}
      case "value":
	{
	  var str = protect.baseGetAttributeValue(localObj[i], "value");
	  arr[entry] = str;
	  break;
	}
      case "number":
	{
	  arr[entry] = "number";;
	  break;
	}
      }
    }
    return arr;
  }
  function getValFromArr(arr)
  {
    if (arr == null)
      return null;
    var val = null;
    for (var i = 0; i < arr.length; i++)
    {
      switch (arr[i])
      {
      case "+":
	{
	  if (arr.length > i && i > 0)
	  {
	    val += arr[i + 1];
	    i++;
	  }
	  break;
	}
      case "-":
	{
	  if (arr.length > i && i > 0)
	  {
	    val -= arr[i + 1];
	    i++;
	  }
	  break;
	}
      default:
        {
	  val = arr[i];
	}
      }
    }
    return val;
  }
  function getValidator(obj)
  {
    if (obj == null)
      return null;
    if (obj.name == null)
      return null;
    if (obj.type != null)
    {
      if (obj.type == "hidden")
	return null;
    }
    var objName = obj.name;
    var objNameArr = objName.split(".");
    var frmNum = 1;
    for (var i = 0; i < objNameArr.length; i++)
    {
	if (!isNaN(objNameArr[i]))
	{
	    frmNum = objNameArr[i];
	    objNameArr[i] = "|iterator|";
	}
    }
    objName = objNameArr.join(".");
    var validators = protect.baseGetElements(protect.pageObj, "validator", protect.pageIter);
    var validObj = null;
    for (var i = 0; i < validators.length; i++)
    {
      if (protect.baseGetAttributeValue(validators[i], "id") != objName)
	continue;
      validObj = validators[i];
      break;
    }
    if (validObj == null)
      return null;
    var minObj = protect.baseGetElements(validObj, "min");
    var maxObj = protect.baseGetElements(validObj, "max");
    var messageObj = protect.baseGetElements(validObj, "message");
    var numberObj = protect.baseGetElements(validObj, "number");
    var minEntries = protect.baseGetAttributeValue(minObj[0], "entries");
    var maxEntries = protect.baseGetAttributeValue(maxObj[0], "entries");
    var messageEntries = protect.baseGetAttributeValue(messageObj[0], "entries");
    var minArr = getArr(minObj[0], minEntries, frmNum);
    var maxArr = getArr(maxObj[0], maxEntries, frmNum);
    var numArr = getArr(numberObj[0], 1, frmNum);
    var minVal = getValFromArr(minArr);
    var maxVal = getValFromArr(maxArr);
    var messageArr = getArr(messageObj[0], messageEntries, frmNum);
    var message = messageArr.join("");
    return new Array(minVal, maxVal, message, numArr);
  }
  function getCamObj()
  {
    var cam = protect.baseGetElements(protect.pageObj, "camera", protect.pageIter);
    var refFrm = document.forms["ref"];
    if (refFrm == null)
      return null;
    var camArticle = refFrm.elements["camArticle"].value;
    var camMeas = refFrm.elements["camMeas"].value;
    camArticle = camArticle.slice(0, 3);
    var camName = new String();
    switch (camArticle)
    {
    case "236":
      {
	camName = "A40";
	break;
      }
    case "227":
      {
	camName = "A20";
	break;
      }
    default:
      {
	camName = "A20";
      }
    }
    if (camMeas == "true")
      camName += "M";
    else
      camName += "V";
    var ioOK = refFrm.elements["camIo"].value;
    if (camName == null || ioOK == null)
      return null;
    var camObj = null;
    for (var i = 0; i < cam.length; i++)
    {
      if (camName == protect.baseGetAttributeValue(cam[i], "id") && ioOK == protect.baseGetAttributeValue(cam[i], "io"))
      {
        camObj = cam[i];
        break;
      }
    }
    if (camObj == null)
	return null;
    if (protect.baseGetAttributeValue(camObj, "visible") == "false")
      return null;
    var camRef = protect.baseGetElements(camObj, "camref");
    if (camRef.length > 0)
    {
	var refID = protect.baseGetAttributeValue(camRef[0], "id");
        var refIO = protect.baseGetAttributeValue(camRef[0], "io");
	for (i = 0; i < cam.length; i++)
	{
	    if (refID == protect.baseGetAttributeValue(cam[i], "id") && refIO == protect.baseGetAttributeValue(cam[i], "io"))
	    {
		camObj = cam[i];
		break;
	    }
	}
    }
    return camObj;
  }
  function setup()
  {
    if (protect.ready == false)
      return false;
    protect.setLanguage(protect.getLanguage());
    protect.strings = protect.baseGetElements(protect.languageObj, "str", protect.languageIter);
    //if (debug)
    if (protect.strings == null)
      return false;
    if (protect.strings.length == 0)
      return false;
    return true;
  }

  function getRuleString(obj, selVal, nameIter)
  {
    var ruleStr = new String();
    if (obj == null)
	return ruleStr;
    for (var k = 0; k < obj.length; k++)
    {
      var affected = protect.baseGetAttributeValue(obj[k], "affected");
      if (nameIter != null)
      {
	  if (nameIter > 0)
	  {
	      var affArr = affected.split(".");
	      for (var l = 0; l < affArr.length; l++)
	      {
		  if (affArr[l] == "|iterator|")
		  {
		      affArr[l] = String(nameIter);
		  }
	      }
	      affected = affArr.join(".");
	  }
      }
      var disable = protect.baseGetAttributeValue(obj[k], "disable");
      var refCount = protect.baseGetAttributeValue(obj[k], "refCount");
      var refGroup = protect.baseGetAttributeValue(obj[k], "refGroup");
      var ruleValue = protect.baseGetAttributeValue(obj[k], "value");
      if (affected != null && (ruleValue == "null" || ruleValue == null))
      {
	if (disable != "null" && disable != null)
	{
	  if (disable.indexOf("size") != -1)
	  {
	      disableCount = disable.slice(5);
	      ruleStr += "if (obj.form.elements['" + affected + "'].options.length == " + disableCount + "){obj.form.elements['" + affected + "'].disabled = true;}else{obj.form.elements['" + affected + "'].disabled = false;}";
	  }
	  else
	    ruleStr += "if (obj.options[obj.selectedIndex].value == '" + selVal + "'){obj.form.elements['" + affected + "'].disabled = " + disable + ";}";
	}
	else if (refCount != "null" && refCount != null)
	{
	  if (isNaN(refCount))
	  {
	    var refCountObj = protect.getObject(refCount);
	    if (refCountObj == null)
		break;
	    if (refCountObj.value == null)
		break;
	    refCount = refCountObj.value;
	    if (isNaN(refCount))
		break;
	  }
	  ruleStr += "if (obj.options[obj.selectedIndex].value == '" + selVal + "'){var rec = obj.form.elements['" + affected + "'];clearCombo(rec);";
	  ruleStr += "for(var i = 1; i <= " + refCount + "; i++){var opt = new Option(i, i, false, false);rec.options[i-1] = opt;}rec.selectedIndex = 0;}";
	}
	else if (refGroup != "null" && refGroup != null)
	{
	  ruleStr += "if (obj.options[obj.selectedIndex].value == '" + selVal + "'){var rec = obj.form.elements['" + affected + "'];clearCombo(rec);var opt = null;";
	  var refGroupArr = refGroup.split("|");
	  for (var l = 0; l < refGroupArr.length; l++)
	  {
	    var tmpArr = refGroupArr[l].split(":");
	    if (tmpArr.length < 2)
		continue;
            var strText = protect.getString(tmpArr[1]);
	    if (strText == null)
		strText = tmpArr[1];
	    ruleStr += "var opt = new Option('" + strText + "', '" + tmpArr[0] + "', false, false);rec.options[rec.options.length] = opt;";
	  }
	  ruleStr += "rec.selectedIndex = 0;}"}
      }
      else if (affected != null && ruleValue != "null" && ruleValue != null)
      {
	var ruleValueArr = ruleValue.split("|");
	switch (ruleValueArr[0])
	{
	case "value":
	  {
	    var setVal = new String();
	    if (ruleValueArr.length > 1)
	    {
	      setVal = ruleValueArr[1];
	      var setValArr = setVal.split(":");
	      if (setValArr.length > 1)
	      {
		switch(setValArr[0])
		{
		case "ref":
		  {
		    if (refValArr.length < 2)
			break;
		    var tmpObj = protect.baseGetObject(refValArr[1]);
		    if (tmpObj == null)
			break;
		    if (tmpObj.value == null)
			break;
		    setVal = tmpObj.value;
		    if (refValArr.length > 2)
		    {
		      if (isNaN(refValArr[2] || isNaN(setVal)))
			setVal += refValArr[2];
		      else
			setVal = String(Number(setVal) + Number(refValArr[2]));
		    }
		    break;
		  }
		}
	      }
	    }
	    else
	      setVal = selVal;
	    ruleStr += "if(obj.options[obj.selectedIndex].value == '" + selVal + "'){obj.form.elements['" + affected + "'].value = " + setVal + ";}";
	    break;
	  }
	}
      }
    }
    return ruleStr;
  }


}
