
function mainDba()
{
var protect = this._protected_();
///////////////////////////////////////////////
// dba protected members

   protect.pageObj = null;
   protect.languageObj = null;
   protect.language = "English"
   protect.pageIter = 0;
   protect.languageIter = 0;
   protect.dba = null;
   protect.ready = false;
   protect.opening = false;
   var url = "/include/text.xml";

///////////////////////////////////////////////
// dba protected methods

protect.setLanguage = setLanguageObject;
protect.getLanguage = getLanguageObjectName;
protect.getCharset  = getLanguageObjectCharset;
protect.setPage = setPageObject;
protect.getPage = getPageObjectName;
protect.dbaInitiate = afterLoaded;
protect.getObject = getObject;

//////////////////////////////////////////////
// dba private members
  var pageId = -1;
  var selObj = null;
  var visObjs = null;
  var selectorObjs = null;
  var optObjs = null;
  var validObjs = null;
  var selectorIter = 0;
  var optIter = 0;
  var visIter = 0;
  var validIter = 0;
  
/////////////////////////////////////////////
// public properties
  
  this.setUrl = function(newUrl){url = newUrl;open();}
  this.getUrl = function(){return url;}
  this.setLanguage = setLanguageObject;
  this.getLanguage = getLanguageObjectName;
  this.setPage = setPageObject;
  this.getPage = getPageObjectName;
  this.getPageUrl = getPageObjectUrl;
  this.readyState = function(){return protect.ready;}
  this.getObject = getObject;

////////////////////////////////////////////
// public methods

  this.initiate = afterLoaded;

  this.checkLang = function()
  {
    var menuLangFrm = window.top.frames['menuframe'].document.forms['langForm'];
    var menuLangObj = null;
    var menuLang = "English";
    if (menuLangFrm != null)
      menuLangObj = menuLangFrm.elements['language'];
    if (menuLangObj != null)
      menuLang = menuLangObj.value;
    var mainLangFrm = window.top.frames['mainframe'].document.forms['langForm'];
    var mainLangObj = null;
    var mainLang = "English";
    if (mainLangFrm != null)
      mainLangObj = mainLangFrm.elements['language'];
    if (mainLangObj != null)
      mainLang = mainLangObj.value;
    if (menuLang == mainLang)
    {
      window.frames['menuframe'].location = '/user/menu.asp';
    }
  }
  function getObjectByID(objName, doc)
  {
    if (objName == null)
      return null;
    if (doc == null)
      doc = document;
    var obj = null;
    if (document.getElementById)
    {
      // W3C DOM
      obj = doc.getElementById(objName);
    }
    else if (document.all)
    {
      // IE4 DOM
      obj = doc.all[objName];
    }
    return obj;
  }

  function getObjectByName(objName, doc)
  {
    if (objName == null)
      return null;
    if (doc == null)
      doc = document;
    var obj = null;
    for (var i = 0; i < doc.forms.length; i++)
    {
      obj = doc.forms[i].elements[objName];
      if (obj != null)
        break;
    }
    return obj;
  }

  function getObject(objName, doc)
  {
    if (objName == null)
      return null;
    if (doc == null)
      doc = document;
    var obj = getObjectByName(objName, doc);
    if (obj == null)
      obj = getObjectByID(objName, doc);
    return obj;
  }

////////////////////////////////////////////
// private methods

  function afterLoaded()
  {
  }
  function setLanguageObject(language)
  {
    protect.language = language == null ? protect.language : language;
    protect.languageObj = getElements(protect.dba, "language");
    if (protect.languageObj == null)
      return false;
    for (var i = 0; i < protect.languageObj.length; i++)
    {
      if (getAttributeValue(protect.languageObj, "id", i) == protect.language)
      {
        protect.languageIter = i;
        break;
      }
    }
    return true;
  }
  function getLanguageObjectName()
  {
    return getAttributeValue(protect.languageObj, "id", protect.languageIter);
  }
  function getLanguageObjectCharset()
  {
    return getAttributeValue(protect.languageObj, "charset", protect.languageIter);
  }
  function setPageObject(pageUrl)
  {
    var pageArr = pageUrl.split("/");
    pageArr = pageArr[pageArr.length - 1].split(".");
    pageString = pageArr[0];
    protect.pageObj = getElements(protect.dba, "page");
    if (protect.pageObj == null)
      return false;
    for (var i = 0; i < protect.pageObj.length; i++)
    {
      if (getAttributeValue(protect.pageObj, "id", i) == pageString)
      {
        protect.pageIter = i;
        break;
      }
    }
    return true;
  }
  function getPageObjectName()
  {
    return getAttributeValue(protect.pageObj, "id", protect.pageIter);
  }
  function getPageObjectUrl()
  {
    linkObj = getElements(protect.pageObj, "link", protect.pageIter);
    return getAttributeValue(linkObj, "file");
  }
  function open()
  {
    if (protect.opening != false)
      return;
    protect.opening = true;
    protect.ready = false;
    var hasImplementation = document.implementation != null ? true : false;
    var hasCreateDoc = false;
    if (hasImplementation)
      hasCreateDoc = document.implementation.createDocument != null ? true : false;
    if (hasCreateDoc == true)
    {
      protect.dba = document.implementation.createDocument("", "doc", null);
      protect.dba.onload = function(){protect.ready = true;}
      protect.dba.load(url);
    }
    else if (window.ActiveXObject)
    {
      protect.dba = new ActiveXObject("Microsoft.XMLDOM");
      protect.dba.onreadystatechange = function(){if (protect.dba.readyState == 4){protect.ready = true;}}
      protect.dba.load(url);
    }
    return;
  }

////////////////////////////////////////
// protected methods

  protect.baseGetElements = getElements;
  function getElements(baseObj, tagString, iterator)
  {
    if (protect.ready == false || baseObj == null || tagString == null)
      return null;
    if (iterator == null)
      return baseObj.getElementsByTagName(tagString);
    else
      return baseObj[iterator].getElementsByTagName(tagString);
  }
  protect.baseGetAttributeValue = getAttributeValue;
  function getAttributeValue(baseObj, attrString, iterator)
  {
    if (protect.ready == false || baseObj == null || attrString == null)
      return null;
    if (iterator == null)
      return baseObj.getAttribute(attrString);
    else
      return baseObj[iterator].getAttribute(attrString);
  }
  protect.baseGetObjectData = getObjectData;
  function getObjectData(obj, iterator)
  {
    if (protect.ready == false)
      return null;
    if (obj == null)
      return null;
    if (iterator == null)
      iterator = 0;
    if (iterator >= obj.length)
      return null;
    if (obj[iterator] == null)
      return null;
    if (obj[iterator].firstChild == null)
      return null;
    return obj[iterator].firstChild.data;
  } 
}

