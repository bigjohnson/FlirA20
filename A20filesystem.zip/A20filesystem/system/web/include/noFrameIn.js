var url = String(window.top.location);
var alowedUrls = new Array("userweb.html", "result.html", "result2.html", "result.asp", "camcontrol.asp", "images.asp", "isoControl.asp", "treeDlg.html");
var urlArr = url.split("?");
if (urlArr.length > 0)
    url = urlArr[0];
urlArr = url.split("/");
if (urlArr.length > 0)
    url = urlArr[urlArr.length - 1];
var isFramedIn = true;
for (var i = 0; i < alowedUrls.length; i++)
{
    if (url == alowedUrls[i])
    {
	isFramedIn = false;
	break;
    }
}
if (isFramedIn)
    window.top.location = "/user/userweb.html";
