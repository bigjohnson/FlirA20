///////////////////////////////////////////////
// some browser compability tests

var hasInstanceOf = false;
var d = new Number();
try
{
  hasInstanceOf = eval("d instanceof Number");
}
catch (exeption)
{
  hasInstanceOf = false;
}

///////////////////////////////////////////////
// extends the Object class to proved protected data members

function _Protected_(ParentClass, ParentClassConstructorArguments)
{
  // make sure this function is called from within the objects constructor
  if (hasInstanceOf && _Protected_.caller && !eval("this instanceof _Protected_.caller"))
  {
    eval('throw new Error("Protected data members can only be shared between related classes.");');
  }
  if (ParentClass)
  {
    // the base class has to be pre-defined as a base of this object
    if (hasInstanceOf && !eval("this instanceof ParentClass"))
      eval('throw new Error("The base class constructor supplied was not pre-defined as the base class for this class.");');
    // reset the _protectedMembers_ property. It may have been modified.
    this._protectedMembers_ = Object.prototype._protectedMembers_;
    // re-initialize the base object of this class for this instance
    ParentClass.apply(this, Array.apply(null, arguments).slice(1));
  }
  var protect;
  var ACCESS_KEY = "1195409";
  function getProtectedMembers(key)
  {
    var returnValue = this;
    if (key == ACCESS_KEY)
      returnValue=protect;
    return returnValue;
  }
  protect = this._protectedMembers_(ACCESS_KEY);
  if (protect == this)
  {
    protect = new Object();
    this._protectedMembers_ = getProtectedMembers;
  }
  return protect;
}
Object.prototype._protected_ = _Protected_;
Object.prototype._protectedMembers_ = function(){return this;}


var timeArr = new Array();
function timer()
{
  this.func = new String();
  this.obj = null;
  this.timeObj = null;
  this.clear = function(){try{window.clearInterval(this.timeObj);}catch(event){alert(event);}}
}
////////////////////////////////////////////
// wait function
// parameters:
// funcStr: name of function to call ["funcName();"]
// obj: object implementing function, object must implement a readyState property
//                                    obj.readyState() = [true/false]
// timeIndex: shall be set to null
function wait(funcStr, obj, timeIndex)
{
  if (obj != null)
    timeIndex = null;
  if (obj == null && timeIndex == null)
    return;
  if (timeIndex == null)
  {
    timeObj = new timer();
    timeIndex = timeArr.length;
    for (var i = 0; i < timeArr.length; i++)
    {
      if (timeArr[i] == null)
      {
        timeIndex = i;
        break;
      }
    }
    timeArr[timeIndex] = timeObj;
    timeObj.func = funcStr;
    timeObj.obj = obj;
    timeObj.timeObj = window.setInterval('eval("wait(null,  null, ' + timeIndex + ');")', 50);
    return;
  }
  if (timeArr[timeIndex] == null)
    return;
  if (timeArr[timeIndex].obj.readyState() == false)
    return;
  timeArr[timeIndex].clear();
  var tmpObj = timeArr[timeIndex].obj;
  var tmpFuncStr = timeArr[timeIndex].func;
  timeArr[timeIndex] = null;
  eval("tmpObj." + tmpFuncStr);
}

function showMessage(obj, id)
{
  var elem = null;
  if (obj.form != null)
    elem = obj.form.elements[id];
  else if (obj.elements != null)
    elem = obj.elements[id];
  if (elem != null)
  {
    alert (elem.value);
  }
}
function showConfirm(obj, id, defVal)
{
  var elem = null;
  if (obj.form != null)
    elem = obj.form.elements[id];
  else if (obj.elements != null)
    elem = obj.elements[id];
  if (elem != null)
  {
    return confirm (elem.value);
  }
  return defVal;
}
function clearCombo(obj)
{
  obj.options.length = 0;
}
function getElement(id, doc)
{
    doc = doc == null ? document : doc;
    if (id == null)
	return null;
    var obj = null;
    if (doc.getElementById)
    {
        obj = doc.getElementById(id);
    }
    else if (doc.all)
    {
        obj = doc.all[id];
    }
    if (obj == null)
    {
	for (var i = 0; i < doc.forms.length; i++)
	{
	    obj = doc.forms[i].elements[id];
	    if (obj != null)
		break;
	}
    }
    return obj;
}
var emsTbl = null;
function popEmisTable(objName)
{
    var url = "/include/treeDlg.html";
    if (objName != null)
	url += "?reciever=" + objName;
    emsTbl = window.open(url, "Emissivity_table", "width=600,height=600,menubar=no,resizable=no,toolbar=no,scrollbars=no");
    window.onunload = function(){if (emsTbl != null) {emsTbl.close();emsTbl = null;}}
}
