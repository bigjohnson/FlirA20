
////////////////////////////////////////
// SetupPage dba extends behaviorDba

function setupPage()
{
//  behavior.call(this);
  var protect = this._protected_(behavior);
  protect.setupPageInitiate = setupPageAfterLoaded;

  this.initiate = setupPageAfterLoaded;

  function getAllElements()
  {
      if (document.all)
      {
	  return document.all;
      }
      return document.getElementsByTagName("*");
  }

  function getPlaceHolders()
  {
    tmpHolders = getAllElements();
    for (var i = 0; i < tmpHolders.length; i++)
    {
      var hasId = (tmpHolders[i].id == null);
      hasId = hasId == true ? false : tmpHolders[i].id.length > 1;
      var hasName = (tmpHolders[i].name == null);
      hasName = hasName == true ? false : tmpHolders[i].name.length > 1;
      if (hasId != false)
      {
        protect.placeHolders[protect.placeHolders.length] = tmpHolders[i];
      }
      if (hasName != false)
      {
        protect.placeHoldersName[protect.placeHoldersName.length] = tmpHolders[i];
      }
    }
  }
  function setNodeText(holder)
  {
      if (holder.length == 0)
	  return;
    
      for (var i = 0; i < holder.length; i++)
	  {
	      var hasId = (holder[i].id == null);
	      hasId = hasId == true ? false : holder[i].id.length > 1;
	      var hasName = (holder[i].name == null);
	      hasName = hasName == true ? false : holder[i].name.length > 1;
	      if (hasId == false && hasName == false)
		  continue;
	      var strID = null;
	      if (hasId)
		  {
		      strID = holder[i].id;
		  }
	      else if (hasName)
		  {
		      strID = holder[i].name;
		  }
	      if (strID == null)
		  continue;
	      if (debug)// check if node is to be lit or not
		  {
		      if (hasId == true)
		        holder[i].style.visibility = "visible";
		      else if (hasName == true)
			if (holder[i].type != "radio")
			  holder[i].style.visibility = "visible";
		  }
	      var strRefID = protect.getID(strID);
	      var str = protect.getString(strRefID);
	      if (str == null)
		  {
		      str = protect.getRefValue(strID);
		  }
	      var handleArr = protect.getObjHandler(strID);
	      if (handleArr != null)
	        if (handleArr.length > 1)
		{
		    switch(handleArr[0])
		    {
		    case "onclick":
		      {
			  holder[i].onclick = new Function("", handleArr[1]);
		      }
		    }
		}
	      if (str == null)
		  continue;
	      if (hasName)
		  {
		      holder[i].value = str;
		  }
	      else
		  {
		      var tn = document.createTextNode(str);
		      holder[i].appendChild(tn);
		  }
	  }
  }
  function setSelectors()
  {
    var holder = document.getElementsByTagName("select");
    if (holder.length == 0)
      return;
    for (var n = 0; n < holder.length; n++)
    {
      if (holder[n].options.length > 0)
        continue;
      var selName = holder[n].name;
      if (selName.length == 0)
        continue;
      var optArr = protect.getOptions(holder[n]);
      var ruleStr = new String();
      for (var j = 0; j < optArr.length; j++)
      {
	var opt = optArr[j];
	if (opt.length < 3)
	  continue;
	var tmpOpt = new Option(opt[0], opt[1], opt[2], opt[2]);
        if (opt.length < 4)
          continue;
        ruleStr += opt[3];
	holder[n].options[holder[n].options.length] = tmpOpt;
	if (opt.length < 5)
	  continue;
       if (opt[4] == null)
	  continue;
	if (opt[4].length == 0)
	  continue;
	tmpOpt.lang = opt[4];
      }
      if (ruleStr.length > 0)
      {
	ruleStr = "{var obj = document.forms['" + holder[n].form.name + "'].elements['" + holder[n].name + "'];" + ruleStr + "}";
	var rule = new Function("", ruleStr);
        holder[n].onchange = rule;
	eval(ruleStr);
      }
    }
  }
  function setRadoGroups()
  {
    var groups = protect.getRadioGroups();
    if (groups == null)
	return;
    for (var i = 0; i < groups.length; i++)
    {
      var buttons = groups[i];
      if (buttons.length > 0)
      {
	if (buttons[0].length < 8)
	  break;
	var rName = buttons[0][0];
	var rule = buttons[0][5];
	var placeholder = buttons[0][6];
	var rSelected = buttons[0][7];
        var obj = protect.getObject(placeholder);
        if (obj == null)
	  continue;
	var placeholderArr = placeholder.split(".");
        var frm = document.forms[placeholderArr[placeholderArr.length-1]];
        if (frm == null)
	  continue;
	var selObj = protect.getObject(rSelected);
        var selVal = new String();
	if (selObj != null)
	  selVal = selObj.value;
	var buttonObjs = frm.elements[rName];
        for (var j = 0; j < buttons.length; j++)
	{
	  var rValue = buttons[j][1];
          var button = null;
	  for (var k = 0; k < buttonObjs.length; k++)
	  {
	      if (buttonObjs[k].value == rValue)
	      {
		  button = buttonObjs[k];
		  break;
	      }
	  }
	  var rString = buttons[j][2];
	  var rImg = buttons[j][3];
	  var rIframe = buttons[j][4];
          obj.appendChild(button);
	  if (selVal == rValue)
	    button.checked = true;
          else
	    button.checked = false;
	  button.disabled = false;
	  button.style.visibility="visible";
          if (rImg != null)
	  {
	    var img = new Image(30,20);
            img.src = rImg;
	    obj.appendChild(img);
	  }
          if (rIframe.length == 3)
	  {
	    var frameStrID = rIframe[2];
	    var frameStr = protect.getString(frameStrID);
	    var frameSrc = rIframe[0] + "?IFRAME.charset=" + rIframe[1] + "&IFRAME.string=" + frameStr;
	    var frameObj = document.createElement("iframe");
            frameObj.style.height = "20px";
            frameObj.style.width = "100px";
            frameObj.scrolling = "no";
	    frameObj.allowTransparency="true";
            frameObj.frameBorder="no";
	    frameObj.src = frameSrc;
	    obj.appendChild(frameObj);
	  }
          if (rString != null)
	  {
	    var str = protect.getString(rString);
	    var tn = document.createTextNode(str);
	    obj.appendChild(tn);
	  }
	  var lineBr = document.createElement("br");
	  obj.appendChild(lineBr);
	}
      }
      continue;
      var selObj = protect.getObject(rSelected);
      if (rSelected == null)
	continue;
      var selVal = selObj.value;
      if (selVal == null)
	continue;
      alert (selVal);
      for(j = 0; j < frm.elements.length; j++)
      {
	  alert (frm.elements[j].value);
	if (selVal == frm.elements[j].value)
	{
	  frm.elements[j].defaultChecked = true;
	  frm.elements[j].checked = true;
	  break;
	}
      }
    }
  }
  function setValidators()
  {
    var validatorArr = new Array();
    var initStr = new String();
    initStr = "{var errMessage = new String();";
    validatorArr[0] = initStr;
    var frms = document.forms;
    for (var i = 0; i < frms.length; i++)
    {
      var elems = frms[i].elements;
      for (var j = 0; j < elems.length; j++)
      {
	var validArr = protect.getValidatorRules(elems[j]);
	if (validArr != null)
	if (validArr != null)
	{
	  if (validArr.length != 4)
	    continue;
	  var tmpStr = new String();
	  tmpStr = "if (obj.elements['" + elems[j].name + "'] != null){var valid = true;";
	  if (validArr[0] != null)
	  {
	      tmpStr += "if (Number(obj.elements['" + elems[j].name + "'].value) < Number(" + validArr[0] + "))valid = false;";
	  }
	  if (validArr[1] != null)
	  {
	      tmpStr += "if (Number(obj.elements['" + elems[j].name + "'].value) > Number(" + validArr[1] + "))valid = false;";
	  }
	  if (validArr[3] != null)
	  {
	      tmpStr += "if (isNaN(Number(obj.elements['" + elems[j].name + "'].value)))valid = false;";
	  }
	  if ((validArr[0] != null || validArr[1] != null || validArr[3] != null) && validArr[2] != null)
	  {
	    tmpStr += "if (valid == false && obj.elements['" + elems[j].name + "'].disabled == false)";
	    tmpStr += "{errMessage += '\\n" + validArr[2] + "'; obj.elements['" + elems[j].name + "'].style.backgroundColor = 'tomato';}";
	    tmpStr += "else obj.elements['" + elems[j].name + "'].style.backgroundColor = 'white';}";
	  }
	  validatorArr[validatorArr.length] = tmpStr;
	}
      }
    }
    initStr = "if (errMessage.length > 0){alert (errMessage);return false;}return true;}";
    validatorArr[validatorArr.length] = initStr;
    return validatorArr.join("");
  }
  function runScripts()
  {
    var camObj = protect.getCamObj();
    var scripts = protect.baseGetElements(camObj, "runscript");
    if (scripts == null)
	return;
    for (var i = 0; i < scripts.length; i++)
    {
      var body = scripts[i].firstChild.data;
      eval(body);
    }
  }
  function setupPageAfterLoaded()
  {
    protect.languageInitiate();
    protect.setPage(window.location.toString());
    var charSet = protect.getCharset();
    document.charset = charSet;
    getPlaceHolders();
    setNodeText(protect.placeHolders);
    setNodeText(protect.placeHoldersName);
    setSelectors();
    setRadoGroups();
    validateStr = setValidators();
    runScripts();
  }
}
var validateStr = new String();
function validate(obj)
{
  var tmpFunc = new Function("obj", validateStr);
  return tmpFunc(obj);
}

