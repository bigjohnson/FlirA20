var rootX = 25;
var rootY = 25;
var imgWidth = 32;
var imgHeight = 16;
var rowHeight = 20;
var indent = 20;
var closedFolder = "/user/images/closedFolder.gif";
var closedFolderImg = new Image();
closedFolderImg.src = "/user/images/closedFolder.gif";
var openFolder = "/user/images/openFolder.gif";
var openFolderImg = new Image();
openFolderImg.src = "/user/images/openFolder.gif";
var docImg = "/user/images/doc.gif";
var docImgObj = new Image();
docImgObj.src = "/user/images/doc.gif";
var dbaObj = window.top.opener.dba;
var timer = null;
function stopFocus()
{
    if (timer != null)
	window.clearInterval(timer);
}
function setFocus()
{
    if (window.closed == false)
	window.focus();
    else
	stopFocus();
}
setInterval("setFocus();", 10);
function getElement(id, doc)
{
    doc = doc == null ? document : doc;
    if (id == null)
	return null;
    var obj = null;
    if (doc.getElementById)
    {
        obj = doc.getElementById(id);
    }
    else if (doc.all)
    {
        obj = doc.all[id];
    }
    if (obj == null)
    {
	for (var i = 0; i < doc.forms.length; i++)
	{
	    obj = doc.forms[i].elements[id];
	    if (obj != null)
		break;
	}
    }
    return obj;
}
function setupEtf(fileName)
{
  var holderID = "tree";
  var hasImplementation = window.document.implementation != null ? true : false;
  var hasCreateDoc = false;
  if (hasImplementation)
    hasCreateDoc = window.document.implementation.createDocument != null ? true : false;
  if (hasCreateDoc == true)
  {
    var fileDoc = window.document.implementation.createDocument("", "", null);
    fileDoc.onload = function(){fileLoaded(fileDoc, holderID);}
    fileDoc.load(fileName);
  }
  else if (window.ActiveXObject)
  {
    var fileDoc = new ActiveXObject("Microsoft.XMLDOM");
    fileDoc.onreadystatechange = function(){if (fileDoc.readyState == 4){fileLoaded(fileDoc, holderID);}}
    fileDoc.load(fileName);
  }
  else
  {
    return;
  }
}
function fileLoaded(doc, holderID)
{
    this.readyState = function(){return dbaObj.readyState();}
    this.xmlDoc = doc;
    this.holder = getElement(holderID);
    if (this.holder == null)
	return;
    parent.top.opener.wait("setupTree();", this, null);
    this.setupTree = function()
    {
      var tree = doc.getElementsByTagName("tree");
      var titleString = new String();
      if (tree.length < 1)
        return;
      var valueFrame = window.top.frames["valueFrame"];
      if (valueFrame == null)
        return;
      var textObj = getElement("selText", valueFrame.document);
      var valueObj = getElement("selVal", valueFrame.document);
      var titleId = tree[0].getAttribute("ref");
      titleString = dbaObj.getString(titleId);
      root = new treeNode("", titleString, true);
      root.holder = holder;
      root.textObj = textObj;
      root.valueObj = valueObj;
      addGroup(tree[0], root, holder, dbaObj, textObj, valueObj);
      root.open(rootX, rootY);
      holder.appendChild(root.getHTMLObject());
    }
}
function addGroup(xmlNode, nodeObj, holder, strDba)
{
    var groups = xmlNode.getElementsByTagName("group");
    var items = xmlNode.getElementsByTagName("item");
    var groupTextId = xmlNode.getAttribute("ref");
    var groupText = strDba.getString(groupTextId);
    //    alert (groupText);
    for (var i = 0; i < groups.length; i++)
    {
        if (groups[i].parentNode != xmlNode)
	    continue;
	var ref = groups[i].getAttribute("ref");
        var refText = strDba.getString(ref);
	var node = null;
	node = new treeNode("", refText, true);
	holder.appendChild(node.getHTMLObject());
	nodeObj.addNode(node);
	addGroup(groups[i], node, holder, strDba);
    }
    for (var i = 0; i < items.length; i++)
    {
        if (items[i].parentNode != xmlNode)
	    continue;
	var ref = items[i].getAttribute("ref");
        var refText = strDba.getString(ref);
	var node = null;
	var val = items[i].getAttribute("value");
	node = new treeNode(groupText, refText, false);
	node.setValue(val);
	holder.appendChild(node.getHTMLObject());
	nodeObj.addNode(node);
    }
}


function treeNode(groupText, folderText, isFolder)
{
    this.holder = null;
    this.element = document.createElement("span");
    this.element._treeNode = this;
    this.isFolder = isFolder;
    this.root = this;
    this.left = rootX;
    this.top = rootY;
    this.element.style.height = imgHeight;
    this.element.style.cursor = "default";
    this.nodes = new Array();
    this.text = new String(folderText);
    this.groupText = new String(groupText);
    this.textObj = null;
    this.valueObj = null;
    this.nodeValue = -1;
    this.isOpen = false;
    this.image = new Image();
    this.image.src = isFolder == true ? closedFolder : docImg;
    this.image.style.verticalAlign = "bottom";
    this.image.style.width = imgWidth;
    this.image.style.height = imgHeight;
    this.element.style.position = "absolute";
    this.element.style.left = this.left;
    this.element.style.top = this.top;
    this.element.style.visibility = "hidden";
    this.element.appendChild(this.image);
    this.element.style.fontFamily ="Tahoma";
    this.element.style.fontSize = "x-small";
    this.element.unselectable = "on";
    tn = document.createTextNode(this.text);
    this.element.appendChild(tn);
    this.element.onclick = click;
    this.element.onmouseover = mouseOver;
    this.element.onmouseout = mouseOut;
    this.setValue = function(val)
    {
	this.nodeValue = val;
    }
    function mouseOver()
    {
	this.style.textDecoration = "underline";
    }
    function mouseOut()
    {
	this.style.textDecoration = "none";
    }
    function click()
    {
	if (this._treeNode.isFolder)
	{
	  if (this._treeNode.isOpen)
	  {
	    this._treeNode.isOpen = false;
	    this._treeNode.image.src = closedFolder;
	  }
	  else
	  {
	    this._treeNode.isOpen = true;
	    this._treeNode.image.src = openFolder;
	  }
	}
	else
	{
	    if (this._treeNode.root.textObj != null && this._treeNode.root.valueObj != null)
	    {
		clearElement(this._treeNode.root.textObj);
		clearElement(this._treeNode.root.valueObj);
		var strTxt = new String();
                if (this._treeNode.groupText != null)
		    strText = this._treeNode.groupText + ", ";
		strText = strText + this._treeNode.text;
		var doc = window.top.frames["valueFrame"].document;
		var textStr = doc.createTextNode(strText);
		var valueStr = doc.createTextNode(this._treeNode.nodeValue);
		this._treeNode.root.textObj.appendChild(textStr);
		this._treeNode.root.valueObj.appendChild(valueStr);
	    }
	    //	    alert (this._treeNode.nodeValue);
	}
	this._treeNode.root.show(rootX, rootY);
        function clearElement(obj)
        {
	    for (var i = obj.childNodes.length - 1; i >= 0; i--)
	        obj.removeChild(obj.childNodes[i]);
        }
    }
    this.addRoot = function(root)
    {
	this.root = root;
    }
    this.addNode = function(node)
    {
	this.nodes[this.nodes.length] = node;
        this.nodes[this.nodes.length-1].addRoot(this.root);
    }
    this.open = function()
    {
	this.isOpen = true;
	this.image.src = openFolder;
        if (this.root != null)
	  this.root.show(rootX, rootY);
	else
	    this.show(rootX, rootY);
    }
    this.show = function(leftPos, topPos)
    {
        this.left = leftPos;
	this.top = topPos;
	this.element.style.visibility = "visible";
	this.element.style.left = this.left;
	this.element.style.top = this.top;
        var newTop = this.top + rowHeight;
	for (var i = 0; i < this.nodes.length; i++)
	{
	    if (this.isOpen)
		newTop = this.nodes[i].show(this.left + indent, newTop);
	    else
	        this.nodes[i].hide();
	}
	if (this.holder != null)
	this.holder.style.bottom = newTop - (rowHeight / 2);
	return newTop;
    }
    this.close = function(leftPos, topPos)
    {
	this.left = leftPos;
	this.top = topPos;
	this.element.style.left = this.left;
	this.element.style.top = this.top;
	this.isOpen = false;
	this.image.src = closedFolder;
	for (var i = 0; i < this.nodes.length; i++)
	  this.nodes[i].hide();
	return this.top + rowHeight;
    }
    this.hide = function()
    {
	this.element.style.visibility = "hidden";
     	for (var i = 0; i < this.nodes.length; i++)
	  this.nodes[i].hide();
    }
    this.getHTMLObject = function()
    {
      return this.element;
    }

}
Object.prototype._treeNode = treeNode;
