<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<title></title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table style="width:375px;">
  <tr>
    <td style="height:25px;width:125px;"><span id="etf_selText"></td>
    <td style="height:25px;width:250px;"><span id="selText" style="font-weight:bolder;"></span></td>
  </tr>
  <tr>
    <td style="height:25px;width:125px;"><span id="etf_selVal"></td>
    <td style="height:25px;width:250px;"><span id="selVal" style="font-weight:bolder;"></td>
  </tr>
  <tr>
    <td colspan="2" style="height:25px;width:375px;">
      <input type="button" value="" name="etf_setVal" style="visibility:hidden;" onClick="window.top.setRecieverValue();">
      <input type="button" value="" name="etf_close" style="visibility:hidden;" onClick="window.top.close();">
    </td>
  </tr>
</table>
</body>
</html>