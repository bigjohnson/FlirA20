
////////////////////////////////////////
// Validate dba extend languageDba

function validate()
{
//  languageDba.call(this);
  var protect = this._protected_(languageDba);


  protect.setupStrings();
}

