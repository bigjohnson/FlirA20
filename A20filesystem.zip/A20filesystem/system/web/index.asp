<HTML>
<HEAD>
<TITLE>FLIR Systems Camera Web</TITLE>
</HEAD>
<BODY LINK="#0000ff" VLINK="#800080">

<FONT FACE="Arial">
<TABLE CELLSPACING=0 BORDER=0 CELLPADDING=15 WIDTH=100%>
<TR>
<TD WIDTH="100%" VALIGN="MIDDLE" HEIGHT=75>
<U><H1 ALIGN="CENTER">Camera Web</H1></U></TD>
</TR>
</TABLE>

<TABLE BORDER="1" CELLSPACING=1 CELLPADDING=10 WIDTH=100% height="342">
<TR><TD WIDTH="7%" VALIGN="TOP" BGCOLOR="#21458C" height="318" >&nbsp;</TD>
<TD WIDTH="86%" VALIGN="TOP" height="318" bgcolor="#FFEEDD" >
<H2 align="center">&nbsp;</H2>
<p align="center">
<BR>
<BR>
<BR>
<a HREF="/user/index.html"><font size="5">User Pages</font></a></p>
<p align="center"><a HREF="/service/service.asp"><font size="5">Service Pages</font></a></p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<ALIGN="LEFT"><IMG SRC="/goahead.gif">
</TD>
<TD WIDTH="7%" VALIGN="TOP" BGCOLOR="#21458C" height="318" >&nbsp;</TD>
</TR>
</TABLE>

<TABLE CELLSPACING=0 BORDER=0 CELLPADDING=15 WIDTH=100%>
<TR>
<TD ALIGN="RIGHT" HEIGHT=25>
<H4><%getResourceValues("version.product.name");%>&nbsp;&nbsp;&nbsp;Serial: <%getResourceValues("version.product.serial");%></H4></TD>
</TR>
</TABLE>
</FONT>
</BODY>
</HTML>
