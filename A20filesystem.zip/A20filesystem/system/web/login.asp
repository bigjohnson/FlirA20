<HTML>
<HEAD>
<TITLE>FLIR Systems Camera, Login</TITLE>
<SCRIPT>
    function setfocus()
    {
        document.login.password.focus();
    }
</SCRIPT>
</HEAD>
<BODY LINK="#0000ff" VLINK="#800080" onLoad="setfocus()">
<FONT FACE="Arial">

<TABLE CELLSPACING=0 BORDER=0 CELLPADDING=15 WIDTH=100%>
<TR>
<TD WIDTH="100%" VALIGN="MIDDLE" HEIGHT=75>
<U><H1 ALIGN="CENTER">Service Web</H1></U></TD>
</TR>
</TABLE>

<TABLE BORDER="1" CELLSPACING=1 CELLPADDING=10 WIDTH=100% height="342">
<TR><TD WIDTH="23%" VALIGN="TOP" BGCOLOR="#6FD8FF" height="20" >
<H3>
Please Log In
</H3>
</TD>
<TD WIDTH="70%" VALIGN="TOP" ROWSPAN=2 height="318" BGCOLOR="#FFEEDD" >
<font size="4" >
<H3>Enter Service Web Password</H3>
<form action="/goform/LogIn" method="get" name=login>
<br>
Password:
<br>
<input type="password" size="20" name="password">
<br>
<br>
<input type="submit" value="Login">
</FORM></FONT></TD>
<TD WIDTH="7%" VALIGN="TOP" ROWSPAN=2 BGCOLOR="#6FD8FF" height="318" >&nbsp;</TD>
</TR>
<TR><TD WIDTH="23%" VALIGN="TOP" BGCOLOR="#6FD8FF" height="274" nowrap>
<H3></H3>
<BR>
</TR>
</TABLE>


<TABLE CELLSPACING=0 BORDER=0 CELLPADDING=15 WIDTH=100%>
<TR>
<TD><A ALIGN="LEFT" HREF="index.asp"><H4>Back to main page</H4></A></TD>
<TD VALIGN="MIDDLE" ALIGN="RIGHT" HEIGHT=25>
<H4><%getResourceValues("version.product.name");%>&nbsp;&nbsp;&nbsp;Serial: <%getResourceValues("version.product.serial");%></H4></TD>
</TR>
</TABLE>
</FONT>
</BODY>
</HTML>
