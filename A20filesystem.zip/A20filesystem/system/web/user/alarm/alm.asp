<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Alarm settings</title></head>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/multiple.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>

function fixForm(obj)
{
  var frmName = obj.name;
  var frmNameArr = frmName.split(".");
  var frmNum = "1";
  if (frmNameArr.length == 2)
  {
    frmNum = frmNameArr[1];
  }
  var actName = "checkbox.actalm." +  frmNum;
  var actObj = obj.elements[actName];
  var actState = actObj.checked;
  for (var i = 3; i < obj.elements.length; i++)
  {
    obj.elements[i].disabled = actState == false ? true : false;
  }
}
</script>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table border="0" width="520">
<%includeFile( "/user/alarm/alarm.inc", "config.monitor.alarm.maxnum" );%>
</table>
</body>