<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Batch settings</title></head>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
function fixForm(obj)
{
  var actObj = obj.elements["checkbox.useBatch"];
  var actState = actObj.checked;
  for (var i = 3; i < obj.elements.length; i++)
  {
    obj.elements[i].disabled = actState == false ? true : false;
  }
}
</script>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<form method="POST" action="/goform/setResourceValues" NAME="batch" onSubmit="fixForm(this);">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/alarm/batch.asp">
  <table>
    <tr>
      <th colspan="2">
          <span id="bts_bts"></span>
      </th>
    </tr>
    <tr>
      <td class="tdt" colspan="2">
        <input type="hidden" name="checkboxdescr" value="useBatch:monitor.batchMode|true:monitor.batchMode|false">
        <input type="checkbox" name="checkbox.useBatch" value="true" <%ifResource("monitor.batchMode", "EQ", "true", "checked", "");%> style="visibility:hidden;">
          <span id="bts_usebatch"></span>
    </tr>
    <tr>
       <td class="tdl">
           &nbsp;<span id="bts_trigg"></span>
       </td>
       <td class="tdr">
           <input type="hidden" name="triggSrcVal" value="<%getResourceValue("monitor.trigger.1.src");%>">
           <select size="1" name="monitor.trigger.1.src" style="visibility:hidden;"></select><select size="1" class="selSmall" name="monitor.trigger.1.srcId" style="visibility:hidden;"></select><br>
           <select size="1" name="monitor.trigger.1.srcRes" style="visibility:hidden;"></select>
             <input type=hidden name="srcRes_Selected" value="<%getResourceValue("monitor.trigger.1.srcRes");%>">
             <input type=hidden name="srcId_Selected" value="<%getResourceValue("monitor.trigger.1.srcId");%>">
       </td>
     </tr>
     <tr>
       <td class="tdl">
         &nbsp;<span id="bts_cond"></span>
       </td>
       <td class="tdr">
           <input type="hidden" name="cond" value="<%getResourceValue("monitor.trigger.1.condition");%>">
           <select size="1" name="monitor.trigger.1.condition" style="visibility:hidden;"></select>
       </td>
     </tr>
     <tr>
       <td class="tdl">
         &nbsp;<span id="bts_thres"></span>
       </td>
       <td class="tdr">
           <input type="text" name="TEMPERATURE.monitor.trigger.1.threshold" class="textStyle" value="<%getTemperatureValue("monitor.trigger.1.threshold");%>" style="visibility:hidden;">
           <span id="tunit1" style="spanVis"></span>
       </td>
     </tr>
     <tr>
       <td class="tdl">
         &nbsp;<span id="bts_hyst"></span>
       </td>
       <td class="tdr">
           <input type="text" name="DIFF_TEMPERATURE.monitor.trigger.1.hysteresis" class="textStyle" value="<%getDiffTempValue("monitor.trigger.1.hysteresis", "%0.1f");%>" style="visibility:hidden;">
           <span id="tunit2" style="spanVis"></span>
       </td>
     </tr>
     <tr>
      <td class="tdt" colspan="2">
        <br>
        <input type="submit" value="" name="bts_submit" class="update" style="visibility:hidden;">
      </td>
     </tr>
  </table>
</table>
<input type="hidden" name="system.autosync" value="2">
</form>
</body>
</html>