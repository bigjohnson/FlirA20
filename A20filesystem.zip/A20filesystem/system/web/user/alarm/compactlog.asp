<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Short log</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/logg.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
    function popUp(img)
    {
       window.open("/goform/setResourceValues?redirect=/user/imgPop.asp&system.web.temp1=" + img, "displayWindow", "width=660,height=500");
    }
</script>
</head>
<body OnLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table style="width:520px;visibility:hidden;" id="logTable">
<%createAlarmLog( "system.web.temp1", "/user/logdetails.asp", "expandlog", "/user/showimg.asp", "/user/result.asp", "newWindow", "class=\"td1\"", "class=\"td2\"", "class=\"td3\"", "", "", "class=\"td4\"" );%>
</table>
</body>
</html>
