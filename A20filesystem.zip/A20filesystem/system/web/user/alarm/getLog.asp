<html>
<head>
<meta http-equiv="pragma" content="no-cache">
<title>Log</title>
<script>
window.location = "../../tmp/alarmlog.txt"
</script>
</head>
<body>
</body>