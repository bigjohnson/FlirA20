<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Images</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<span id="img_img" style="visibility:hidden;">
<table>
<%listFiles("28.0/images", "jpg", "translate");%>
</table>
</body>
</html>