<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Alarm log settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<script>
function getFile()
{
    var logWin = window.open("/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true", "hideWindow", "width=640,height=480,menubar=yes,resizable=yes,scrollbars=yes,toolbar=yes");
}
function openImgDir()
{
  window.open("../empty.html?redirect=/user/alarm/images.asp", "_blank", "width=300,height=400,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes");
}
</script>
<table>
  <tr>
    <th colspan="2">
      <span id="als_als"></span>
    </th>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
      &nbsp;<input type="button" value="" name="als_img" class="update75" onClick="javascript:window.open('../empty.html?redirect=/user/alarm/images.asp', '_blank', 'width=300,height=400,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes');" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
      &nbsp;<input type="submit" name="als_getlog" class="update75" value="" onClick="javascript:getFile();" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
  <td width="100%" height="1" align="left" id="als_td1" style="visibility:hidden;" valign="top" colspan="3" bgcolor="#000000">
  </tr>
  <form name="logSet" ACTION=/goform/setResourceValues METHOD=POST onSubmit="if (validate(this))showMessage(this, 'logSet_message');else return false;">
    <tr>
      <td class="tdlt" colspan="2">
        <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/alarm/logactions.asp">
        <input type="hidden" name="logSet_message" value="">
        <span id="als_lim"></span>
      </td>
    </tr>
    <tr>
      <td class="tdl">&nbsp;<span id="als_lent"></span>
      </td>
      <td class="tdr">
        <input type="text" class="textStyle" style="visibility:hidden;" name="monitor.log.logSize" value="<%getResourceValue("monitor.log.logSize");%>">
      </td>
    </tr>
    <tr>
      <td class="tdl">&nbsp;<span id="als_savedimg"></span>
      </td>
      <td class="tdr">
        <input type="text" class="textStyle" style="visibility:hidden;" name="monitor.log.imageSize" value="<%getResourceValue("monitor.log.imageSize");%>">
      </td>
    </tr>
    <tr>
      <td colspan="2" class="tdts_nw">
        &nbsp;<input type="submit" class="update" name="als_submit" value="" style="visibility:hidden;">
      </td>
    </tr>
  </form>
  <tr>
    <td class="tdl" style="width:100%;" colspan="2">
      <li style="list-style-type:none;"><span id="als_note"></span>
        <ul style="list-style-type:none;">
          <span id="als_li1"></span>
        </ul>
        <ul style="list-style-type:none;">
          <span id="als_li2"></span><br>
          <span id="als_li3"></span>
        </ul>
      </li>
    </td>
  </tr>
  <tr>
    <td colspan="2" class="tdts_nw">
      <form name="restart" ACTION=/goform/setResourceValues METHOD=POST onSubmit="return showConfirm(this, 'restart_message', false) == true ? true : false;">
        <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/alarm/logactions.asp">
        <input type="hidden" name="restart_message" value="">
        <input type="hidden" name="system.restart" value="true">
        &nbsp;<input type="submit" class="update" name="als_restart" value="" style="visibility:hidden;">
      </form>
    </td>
  </tr>
  <tr>
  <td width="100%" height="1" align="left" valign="top" colspan="3" id="als_td2" style="visibility:hidden;" bgcolor="#000000">
  </tr>
  <tr>
    <td class="tdts" colspan="2">
      <br><br>
      <FORM name="clearlog" ACTION=/goform/setResourceValues METHOD=POST onSubmit="return showConfirm(this, 'clearlog_message', false) == true ? true : false;">
        <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/alarm/logactions.asp">
        <input type="hidden" name="monitor.log.clear" value="true">
        <input type="hidden" name="clearlog_message" value="">
        &nbsp;<input type="submit" class="update75" name="als_clearlog" value="" style="visibility:hidden;">
        <input type="hidden" name="system.autosync" value="2">
      </form>
    </td>
  </tr>
</table>
</body>
</html>
