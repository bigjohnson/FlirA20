<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<title>Log head</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table style="width:460px">
  <tr>
    <td class="tdh" style="width:90px;" id="logh_date"></td>
    <td class="tdh" style="width:130px;"id="logh_time"></td>
    <td class="tdh" style="width:45px;" id="logh_id"></td>
    <td class="tdh" style="width:60px;" id="logh_state"></td>
    <td class="tdh" style="width:115px;" id="logh_simg"></td>
  </tr>
</table>
<hr width="100%" size="1" color="#000000">
</body>

</html>
