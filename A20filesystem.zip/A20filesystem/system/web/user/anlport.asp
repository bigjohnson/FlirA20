<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Analog ports</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<FORM METHOD="post" ACTION="/goform/setResourceValues" name="anlgForm" onSubmit="return validate(this);">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/anlport.asp">
<table>
  <tr>
    <th colspan="2">
      <span id="anlp_anlp"></span>
    </th>
  </tr>
  <tr>
    <td class="tdlt">
      <span id="anlp_anlgin"></span>
    </td>
    <td class="tdr">
      <span id="anlp_valin" style="visibility:hidden;"><%getResourceValue("system.ioports.anlgin", "%0.1f");%></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_hval1"></span>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlginHigh" size="10" value="<%getResourceValue( "system.ioports.anlginHigh", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_lval1"></span>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlginLow" size="10" value="<%getResourceValue( "system.ioports.anlginLow", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdlt">
      <span id="anlp_anlgout1"></span>
    </td>
    <td class="tdr">
      <span id="anlp_valout1" style="visibility:hidden;"><%getResourceValue("system.ioports.anlgout1", "%0.1f");%></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_hval2"></span>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlgout1High" size="10" value="<%getResourceValue( "system.ioports.anlgout1High", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_lval2"></span>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlgout1Low" size="10" value="<%getResourceValue( "system.ioports.anlgout1Low", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdlt">
      <span id="anlp_anlgout2"></span>
    </td>
    </td>
    <td class="tdr">
      <span id="anlp_valout2" style="visibility:hidden;"><%getResourceValue("system.ioports.anlgout2", "%0.1f");%></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_hval3"></sapn>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlgout2High" size="10" value="<%getResourceValue( "system.ioports.anlgout2High", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="anlp_lval3"></span>
    </td>
    <td class="tdr">
        &nbsp;<input type="text" class="textStyle" name="system.ioports.anlgout2Low" size="10" value="<%getResourceValue( "system.ioports.anlgout2Low", "%0.1f" );%>" style="visibility:hidden;">
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <br><input type="submit" value="" name="anlp_submit" class="update" style="visibility:hidden;">
    </td>
  </tr>
</table>
<input type="hidden" name="system.autosync" value="2">
</form>
</body>
</html>