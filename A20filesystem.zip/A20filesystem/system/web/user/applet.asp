<HTML>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<body>
<div ID="dv" style="overflow:hidden;"><p>
<applet name="apl" code="RTPPlayerApplet.class" archive="/user/applets/RTPPlayerApplet.jar" align="baseline"
width="100%" height="100%">
<!-- Browser compability prams -->
<param name="ApplicationClass" value="RTTPPlayerApplet">
<param name="cabbase" value="RTTPPlayerApplet.cab">
<param name="uselibrary" value="RTTPPlayerApplet">
<param name="uselibrarycodebase" value="RTTPPlayerApplet.cab">
<param name="uselibraryversion" value="1,1 ,2,3"
<!-- applet params -->
<param name="mcenable" value="<%getResourceValues("system.rtp.mcenable");%>">
<param name="mcaddress" value="<%getResourceValues("system.rtp.mcaddress");%>">
<param name="port" value="<%getResourceValues("system.rtp.port");%>">
<param name="ttl" value="<%getResourceValues("system.rtp.ttl");%>">
<param name="pt" value="<%getResourceValues("system.rtp.pt");%>">
<param name="downsample" value="<%getResourceValues("system.rtp.downsample");%>">
</applet></p></div>
</body>
</HTML>