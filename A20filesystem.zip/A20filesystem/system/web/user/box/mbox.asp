<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Box settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/multiple.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
<!--
function fixParMasks(obj)
{
  var objNameArr = obj.name.split(".");
  var nameNum = 1;
  if (objNameArr.length == 2)
    nameNum = objNameArr[1];
  var active = obj.elements["checkbox.actmbox." + String(nameNum)];
  var locSet = obj.elements["locset." + String(nameNum)];
  var showLbl = obj.elements["showLabel." + String(nameNum)];
  var showHot = obj.elements["showHot." + String(nameNum)];
  var target = obj.elements["image.mfunc.mbox." + String(nameNum) + ".parMask"];
  if (active == null || locSet == null || showLbl == null || showHot == null || target == null)
    return;
  var mask = 0;
  var mask = active.checked && locSet.checked ? mask |= 0x07 : mask &= ~0x07;
  mask = active.checked && showLbl.checked ? mask |= 0x40 : mask &= ~0x40;
  mask = active.checked && showHot.checked ? mask |= 0x80 : mask &= ~0x80;
  target.value = mask;
  return validate(obj);
}
-->
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<form name="VALIDATE:mbform$">
<input type="hidden" name="BREAK:checkbox.checked:CONTINUE:STOP|checkbox.actmbox.$" value="NOMESSAGE">
<input type="hidden" name="NUMBER:>=:0:<:imgWidth|image.mfunc.mbox.$.x" value="X-value must be between #2# and #4#">
<input type="hidden" name="JUMP:NUMBER:>=:0:<:imgWidth:FAILED:1|image.mfunc.mbox.$.x" value="NOMESSAGE">
<input type="hidden" name="REMAINING:>=:0:<:imgWidth#-#mbform$.image.mfunc.mbox.$.x|image.mfunc.mbox.$.width" value="Width must be between #2# and #4#, or the X-value must be decreased">
<input type="hidden" name="NUMBER:>=:0:<:imgHeight|image.mfunc.mbox.$.y" value="Y-value must be between #2# and #4#">
<input type="hidden" name="JUMP:NUMBER:>=:0:<:imgHeight:FAILED:1|image.mfunc.mbox.$.y" value="NOMESSAGE">
<input type="hidden" name="REMAINING:>=:0:<:imgHeight#-#mbform$.image.mfunc.mbox.$.y|image.mfunc.mbox.$.height" value="Height must be between #2# and #4#, or the Y-value must be decreased">
<input type="hidden" name="BREAK:checkbox.checked:CONTINUE:STOP|locset.$" value="NOMESSAGE">
<input type="hidden" name="NUMBER:>=:minDist:<=:maxDist|DISTANCE.image.mfunc.mbox.$.distance" value="Distance must be between #2# and #4#">
<input type="hidden" name="NUMBER:>=:minEmiss:<=:maxEmiss|image.mfunc.mbox.$.emissivity" value="Emissivity must be between #2# and #4#">
<input type="hidden" name="NUMBER:>=:minTemp:<=:maxTemp|TEMPERATURE.image.mbox.spot.$.ambTemp" value="Ambient temperature must be between #2# and #4#">
</form>
<table>
<%includeFile("/user/box/mbox.inc", "config.measure.mbox.maxnum");%>
</table>
</body></html>
