<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<title>Camera Control</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
var width = 250;
var height = 469;
var af = <%getResourceValue("config.image.autofocus");%>;
if (af == false)
  height -= 50;
var f = <%getResourceValue("image.focus.motorPresent");%>;
if (f == false)
{
  height -= 75;
}
function setSize()
{
  window.resizeTo(width, height);
  if (af == true)
  {
    var obj = getObject("f20");
    removeObject(obj);
  }
  else if (f == true)
  {
    var obj = getObject("f40");
    removeObject(obj);
  }
  else
  {
    var obj = getObject("f40");
    removeObject(obj);
    var obj = getObject("f20");
    removeObject(obj);
    obj = getObject("ft");
    removeObject(obj);
  }
  function removeObject(obj)
  {
    if (obj != null)
    {
      var par = obj.parentNode;
      if (par != null)
        par.removeChild(obj);
    }
  }
  function getObject(objName)
  {
    var obj = null;
    if (document.getElementById)
    {
      // W3C DOM
      obj = document.getElementById(objName);
    }
    else if (document.all)
    {
      // IE4 DOM
      obj = document.all[objName];
    }
    return obj;
  }
  setup();
}
function openImgDir()
{
  window.open("/user/empty.html?redirect=/user/alarm/images.asp", "_blank", "width=300,height=400,menubar=yes,resizable=yes,toolbar=yes,scrollbars=yes");
}
</script>
</head>
<body background="bkg.gif" onLoad="setSize();">
<%includeFile("/include/langForm.inc");%>
<table style="width:220px;" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td style="width:220px;" align="center" colspan="4">
    <font face="Arial" size="3"><b><span id="cam_lev"></span></b></font>
  </td>
</tr>
<tr>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="-200">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;<<&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="-20">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;&nbsp;<&nbsp;&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:right;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="+20">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:right;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="+200">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;>>&nbsp;&nbsp;">
    </FORM>
  </td>
</tr>

<tr>
  <td style="width:220px;text-align:center;" colspan="4">
    <font face="Arial" size="3"><b><span id="cam_span"></span></b></font>
  </td>
</tr>
<tr>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="-200">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;<<&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="-20">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;&nbsp;<&nbsp;&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="+20">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;">
    </FORM>
  </td>
  <td style="width:55px;text-align:right;">
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="+200">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_bt" VALUE="&nbsp;&nbsp;>>&nbsp;&nbsp;">
    </FORM>
  </td>
</tr>
<tr>
  <td style="width:220px;text-align:center;" colspan="4">
    <font face="Arial" size="3"><b><span id="cam_autoadj"></span></b></font>
  </td>
</tr>
<tr>
  <td style="width:55px;text-align:left;">
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.cont" VALUE="true">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_on" VALUE="">
    </FORM>
  </td>
  <td style="width:110px;text-align:center;" colspan="2">
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.now" VALUE="true">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_now" VALUE="">
    </FORM>
  </td>
  <td style="width:55px;text-align:right;">
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.cont" VALUE="false">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_off" VALUE="">
    </FORM>
  </td>
</tr>

<tr id="ft">
  <td style="width:55px;text-align:center;">
    <font face="Arial" size="3"><span id="cam_near"></span></font>
  </td> 
  <td style="width:110px;text-align:center;" colspan="2">
    <font face="Arial" size="3"><b><span id="cam_focus"></span></b></font>
  </td>
   <td style="width:55px;text-align:center;">
    <font face="Arial" size="3"><span id="cam_far"></span></font>
  </td> 
</tr>
<tr id="f20">
  <td style="width:220px;text-align:center;" colspan="4">
    <div>
      <table style="width:200px;text-align:center;">
        <tr>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="600">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:40px;" name="cam_bt" VALUE="<<<">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="150">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:33px;" name="cam_bt" VALUE="&nbsp;<<&nbsp;">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="50">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:20px;" name="cam_bt" VALUE="&nbsp;<">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="50">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:20px;" name="cam_bt" VALUE=">&nbsp">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="150">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:33px;" name="cam_bt" VALUE="&nbsp;>>&nbsp;">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="1">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="600">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:40px;" name="cam_bt" VALUE=">>>">
            </FORM>
          </td>
        </tr>
      </table>
    </div>
  </td>
</tr>
<tr id="f40">
  <td style="width:220px;text-align:center;" colspan="4">
    <div>
      <table style="width:200px;text-align:center;">
        <tr>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-100">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:40px;" name="cam_bt" VALUE="<<<">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-50">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:33px;" name="cam_bt" VALUE="&nbsp;<<&nbsp;">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="-15">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:20px;" name="cam_bt" VALUE="&nbsp;<">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="15">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:20px;" name="cam_bt" VALUE=">&nbsp">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="50">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:33px;" name="cam_bt" VALUE="&nbsp;>>&nbsp;">
            </FORM>
          </td>
          <td>
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="100">
              <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="400">
              <INPUT TYPE="hidden" NAME="image.focus.motor" VALUE="0">
              <INPUT TYPE="submit" class="update" style="visibility:hidden;width:40px;" name="cam_bt" VALUE=">>>">
            </FORM>
          </td>
        </tr>
        <tr>
          <td colspan="6">
            <FORM ACTION=/goform/setResourceValues METHOD=POST>
              <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
              <INPUT TYPE="hidden" NAME="image.focus.auto" VALUE="true"><!-- change resource to "AutoFocus" when present -->
              <INPUT TYPE="submit" class="update" VALUE="Auto">
            </FORM>
          </td>
        </tr>
      </table>
    </div>
  </td>
</tr>


<tr>
  <td style="width:220px;text-align:center;" colspan="4">
    <font face="Arial" size="3"><b><span id="cam_mode"></span></b></font>
  </td>
</tr>
<tr>
  <td style="width:110px;text-align:center;"colspan="2">
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.freeze" VALUE="true">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_freeze" VALUE="">
    </FORM>
  </td>
  <td style="width:110px;text-align:center;" colspan="2">
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
      <INPUT TYPE="hidden" NAME="image.adj.freeze" VALUE="false">
      <INPUT TYPE="submit" class="update" style="visibility:hidden;" name="cam_live" VALUE="">
    </FORM>
  </td>
</tr>

<tr>
  <td style="width:220px;text-align:center;" colspan="4">
    <font face="Arial" size="3"><b><span id="cam_file"></span></b></font>
  </td>
</tr>
<tr>
  <td style="width:220px;text-align:center;" colspan="4">
  <div>
    <table style="width:200px;text-align:center;">
      <td style="width:60px;text-align:center;">
        <FORM ACTION=/goform/setResourceValues METHOD=POST>
          <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
          <INPUT TYPE="hidden" NAME="image.file.autostore" VALUE="true">
          <input type="submit" class="update" style="width:55px;visibility:hidden;" name="cam_save" value="">
        </form>
      </td>
      <td style="width:70px;text-align:center;">
        <form>
          <input type="button" name="cam_view" value="" class="update" style="width:55px;visibility:hidden;" onClick="javascript:openImgDir();">
        </form>
      </td>
      <td style="width:60px;text-align:center;">
        <FORM ACTION=/goform/setResourceValues METHOD=POST onSubmit="return window.confirm('Are you sure you want to remove all images?') == true ? true : false;">
          <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camcontrol.asp">
          <input type="hidden" name="image.file.deleteDir" value="<%getResourceValue("image.file.currDir");%>">
          <input type="submit" class="update" style="width:55px;visibility:hidden;" name="cam_clear" value="">
        </form>
      </td>
    </table>
  </div>
  </td>
</tr>
</table>

</body>
</html>
