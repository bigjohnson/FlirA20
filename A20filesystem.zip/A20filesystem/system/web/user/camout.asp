<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Camera outputs</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<script>
function fixForm()
{
  var obj = document.forms['camOut'].elements['checkbox.enabled'];
  var isDisabled = obj.checked == true ? true : false;
  for (var i = 12; i < document.forms['camOut'].elements.length; i++)
  {
    obj = document.forms['camOut'].elements[i];
    obj.disabled = isDisabled;
  }
  obj = document.forms['camOut'].elements['monitor.output.dig3'];
  obj.options[1].value = 0;
  if (obj.selectedIndex == 1)
  {
    obj = document.forms['camOut'].elements['system.ioports.vsync_inactive'];
    obj.value = false;
  }
  else
  {
    obj = document.forms['camOut'].elements['system.ioports.vsync_inactive'];
    obj.value = true;
  }
}

</script>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<FORM name="camOut" ACTION=/goform/setResourceValues METHOD=POST OnSubmit="fixForm();">
  <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/camout.asp">
  <input type=hidden name="dig1" value="<%getResourceValue("monitor.output.dig1");%>">
  <input type=hidden name="dig2" value="<%getResourceValue("monitor.output.dig2");%>">
  <input type=hidden name="dig3" value="<%getResourceValue("monitor.output.dig3");%>">
  <input type=hidden name="digbidir" value="<%getResourceValue("monitor.output.digbidir");%>">
  <input type=hidden name="anlg1Src" value="<%getResourceValue("monitor.output.anlg1Src");%>">
  <input type=hidden name="anlg1Id" value="<%getResourceValue("monitor.output.anlg1Id");%>">
  <input type=hidden name="anlg1Res" value="<%getResourceValue("monitor.output.anlg1Res");%>">
  <input type=hidden name="anlg2Src" value="<%getResourceValue("monitor.output.anlg2Src");%>">
  <input type=hidden name="anlg2Id" value="<%getResourceValue("monitor.output.anlg2Id");%>">
  <input type=hidden name="anlg2Res" value="<%getResourceValue("monitor.output.anlg2Res");%>">
  <input type ="hidden" name="system.ioports.vsync_inactive" value="<%getResourceValue("system.ioports.vsync_inactive");%>">
<table>
  <tr>
    <th colspan="2">
            <span id="iop_iop"></span>
    </th>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
        <input type="hidden" name="checkboxdescr" value="enabled:monitor.output.enabled|false:monitor.output.enabled|true">
        <input type="checkbox" name="checkbox.enabled" value="true" <%ifResource("monitor.output.enabled", "EQ", "false", "checked", "");%> style="visibility:hidden;">
        <span id="iop_disout"></span><br><br>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
        <span id="iop_digp"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_dig1"></span>
    </td>
    <td class="tdr">
        &nbsp;<select size="1" name="monitor.output.dig1" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_dig2"></span>
    </td>
    <td class="tdr">
        &nbsp;<select size="1" name="monitor.output.dig2" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_dig3"></span>
    </td>
    <td class="tdr">
        &nbsp;<select size="1" name="monitor.output.dig3" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_bidir"></span>
    </td>
    <td class="tdr">
      <font size="3" face="Tahoma">
        &nbsp;<select size="1" name="monitor.output.digbidir" <%ifResource("system.ioports.digbidir_out", "EQ", "true", "", "disabled=true");%> style="visibility:hidden;"></select><br><br>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
        <span id="iop_anlp"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_anl1"></span>
    </td>
    <td class="tdr">
        <select size="1" name="monitor.output.anlg1Src" style="visibility:hidden;"></select>
        <select size="1" name="monitor.output.anlg1Id" class="selSmall" style="visibility:hidden;"></select><br>
        <select size="1" name="monitor.output.anlg1Res" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
        &nbsp;<span id="iop_anl2"></span>
    </td>
    <td class="tdr">
        <select size="1" name="monitor.output.anlg2Src" style="visibility:hidden;"></select>
        <select size="1" name="monitor.output.anlg2Id" class="selSmall" style="visibility:hidden;"></select><br>
        <select size="1" name="monitor.output.anlg2Res" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
      <td class="tdt" colspan="2">
         <br>
         <INPUT TYPE="hidden" NAME="webserver.delay" VALUE="350">
         <input type="submit" value="" name="iop_submit" class="update" style="visibility:hidden;">
      </td>
  </tr>
  <input type="hidden" name="system.autosync" value="2">
  </form>
</table>
</body>
</html>
