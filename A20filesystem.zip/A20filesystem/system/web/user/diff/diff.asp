<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Diff settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/multiple.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
<!--
function fixForm(obj)
{
  for (var i = 1; i < obj.elements.length; i++)
  {
    if (obj.elements[i].disabled == true)
    {
      obj.elements[i].disabled = false;
    }
  }
}
-->
</script>
</head>
<body  onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table style="width:450px;">
<%includeFile("/user/diff/diff.inc", "config.measure.diff.maxnum");%>
</table>
</body></html>