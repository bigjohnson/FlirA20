<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Camera user interface settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table>
<tr>
   <th>
      <span id="cgui_cgui"></span>
   </th>
</tr>
<FORM name="testform" METHOD="post" ACTION="/goform/setResourceValues">
  <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/guiset.asp">
   <tr>
      <td class="tdt">
            <input type="hidden" name="checkboxdescr" value="graphMode:gui.system.hideGraphics|true:gui.system.hideGraphics|false">
            <input type="checkbox" name="checkbox.graphMode" value="true" <%ifResource("gui.system.hideGraphics", "EQ", "false", "", "checked");%> style="visibility:hidden">
            <span id="cgui_hgraph"></span><br><br>
      </td>
   </tr>
   <tr>
      <td class="tdt">
         <span id="cgui_comp"></span>
      </td>
   </tr>
   <tr>
<!-- Label -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="label:gui.marker.text.0.state|SHOW:gui.marker.text.0.state|HIDE">
         <input type="checkbox" name="checkbox.label" value="true" <%ifResource("gui.marker.text.0.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_label"></span>
         <input type=hidden name="gui.marker.text.0.commit" value="true">
      </td>
   </tr>
   <tr>
<!-- Logo -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="logo:gui.marker.icon.0.state|SHOW:gui.marker.icon.0.state|HIDE">
         <input type="checkbox" name="checkbox.logo" value="true" <%ifResource("gui.marker.icon.0.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_logo"></span>
         <input type=hidden name="gui.marker.icon.0.commit" value="true">
      </td>
   </tr>
   <tr>
<!-- Scale -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="scale:gui.status.scale.state|SHOW:gui.status.scale.state|HIDE">
         <input type="checkbox" name="checkbox.scale" value="true" <%ifResource("gui.status.scale.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_scale"></span>
         <input type=hidden name="gui.status.scale.commit" value="true">
      </td>
   </tr>
   <tr>
<!-- Infobar -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="bar:gui.status.bar.state|SHOW:gui.status.bar.state|HIDE">
         <input type="checkbox" name="checkbox.bar" value="true" <%ifResource("gui.status.bar.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_infobar"></span>
         <input type=hidden name="gui.status.bar.commit" value="true"></p>
      </td>
   </tr>
   <tr>
      <td class="tdt">
        <span id="cgui_infobarlbl"></span>
      </td>
   </tr>
   <tr>
<!-- Date/Time -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="clock:gui.status.clock.state|SHOW:gui.status.clock.state|HIDE">
         <input type="checkbox" name="checkbox.clock" value="true" <%ifResource("gui.status.clock.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_dt"></span>
         <input type=hidden name="gui.status.clock.commit" value="true">
      </td>
   </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  var emiss  = ifResource("gui.status.emissFact.state", "EQ", "SHOW");
  var obDist = ifResource("gui.status.objDist.state", "EQ", "SHOW");
  var humid  = ifResource("gui.status.relHum.state", "EQ", "SHOW");
  var atm    = ifResource("gui.status.tAtm.state", "EQ", "SHOW");
  var amb    = ifResource("gui.status.tAmbient.state", "EQ", "SHOW");
  write("<tr><td class='tdts'>\n<input type='hidden' name='checkboxdescr' value='emis:gui.status.emissFact.state|SHOW:gui.status.emissFact.state|HIDE'>\n");
  write("<input type='checkbox' name='checkbox.emis' value='true' ");
  if (emiss == "true")
    write("checked");
  write(" style='visibility:hidden'><span id='cgui_emiss'></span>\n<input type=hidden name='gui.status.emissFact.commit' value='true'>\n</td>\n</tr>\n");

  write("<tr><td class='tdts'>\n<input type='hidden' name='checkboxdescr' value='obd:gui.status.objDist.state|SHOW:gui.status.objDist.state|HIDE'>\n");
  write("<input type='checkbox' name='checkbox.obd' value='true' ");
  if (obDist == "true")
    write("checked");
  write(" style='visibility:hidden'><span id='cgui_dist'></span>\n<input type=hidden name='gui.status.objDist.commit' value='true'>\n</td>\n</tr>\n");

  write("<tr><td class='tdts'>\n<input type='hidden' name='checkboxdescr' value='tamb:gui.status.tAmbient.state|SHOW:gui.status.tAmbient.state|HIDE'>\n");
  write("<input type='checkbox' name='checkbox.tamb' value='true' ");
  if (amb == "true")
    write("checked");
  write(" style='visibility:hidden'><span id='cgui_refl'></span>\n<input type=hidden name='gui.status.tAmbient.commit' value='true'>\n</td>\n</tr>\n");

  write("<tr><td class='tdts'>\n<input type='hidden' name='checkboxdescr' value='atmtemp:gui.status.tAtm.state|SHOW:gui.status.tAtm.state|HIDE'>\n");
  write("<input type='checkbox' name='checkbox.atmtemp' value='true' ");
  if (atm == "true")
    write("checked");
  write(" style='visibility:hidden'><span id='cgui_atm'></span>\n<input type=hidden name='gui.status.tAtm.commit' value='true'>\n</td>\n</tr>\n");

  write('<tr><td class="tdts">\n<input type="hidden" name="checkboxdescr" value="rhum:gui.status.relHum.state|SHOW:gui.status.relHum.state|HIDE">\n');
  write('<input type="checkbox" name="checkbox.rhum" value="true" ');
  if (humid == "true")
    write("checked");
  write(' style="visibility:hidden"><span id="cgui_relhum"></span>\n<input type=hidden name="gui.status.relHum.commit" value="true">\n</td>\n</tr>\n');
}
%>
<!-- Range -->
    <tr>
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="case:gui.status.case.state|SHOW:gui.status.case.state|HIDE">
         <input type="checkbox" name="checkbox.case" value="true" <%ifResource("gui.status.case.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_range"></span>
         <input type=hidden name="gui.status.case.commit" value="true">
      </td>
   </tr>
   <tr>
<!-- Lens info -->
      <td class="tdts">
         <input type="hidden" name="checkboxdescr" value="linf:gui.status.lensInfo.state|SHOW:gui.status.lensInfo.state|HIDE">
         <input type="checkbox" name="checkbox.linf" value="true" <%ifResource("gui.status.lensInfo.state", "EQ", "HIDE", "", "checked");%> style="visibility:hidden"><span id="cgui_linf"></span>
         <input type=hidden name="gui.status.lensInfo.commit" value="true">
      </td>
   </tr>
   <tr>
      <td class="tdt">
         <br>
         <input type="hidden" name="system.autosync" value="2">
         <input type="submit" value="" name="cgui_submit" class="update" style="visibility:hidden">
      </td>
   </tr>
</form>
</table> 
</body>
</html>