<html>
<head>
<meta http-equiv="pragma" content="no-cache">
<title><%getResourceValue("version.product.name");%></title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
</head>
<body>
<input type="hidden" name="admlock" value="true">
<table style="width:100%;">
  <tr>
    <td style="width:20%;">
      <a href="../index.asp" target="_top"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
    </td>
    <th style="width:80%;vertical-align:middle;text-align:center;font-size:400%;font-family:Century Gothic;">
        <a href="start.asp" target="mainframe"><%getResourceValue("version.product.name");%></a>
    </th>
  </tr>
</table>
</body>
</html>
