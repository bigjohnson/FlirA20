<html>
<head>
<meta http-equiv="pragma" content="no-cache">
<title>Image</title></head>
<body>
  <img src="/IMAGES/<%getResourceValue("system.web.temp1");%>" width="640" height="480">
</body>
</html>