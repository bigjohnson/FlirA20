<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Image settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<script>
function fixForm(frm)
{
  for (var i = 1; i < document.forms[frm].elements.length; i++)
  {
    if (document.forms[frm].elements[i].disabled == true)
    {
      document.forms[frm].elements[i].disabled = false;
    }
  }
}
function setOverride(obj)
{
  document.forms['imgForm'].elements['image.adj.prefs.override'].value = obj.selectedIndex == 0 ? true : false;
}
</script>
<body onLoad="setup();clickBox(document.forms['imgForm'].elements['checkbox.fLinear']);">
<%includeFile("/include/langForm.inc");%>
<FORM METHOD="post" name="imgForm" ACTION="/goform/setResourceValues" onSubmit="return validate(this);">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/imgparams.asp">
<table>
  <tr>
    <th colspan="2">
      <span id="imset_imset"></span>
    </th>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <span id="imset_pres"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="imset_adj"></span>
    </td>
    <td class="tdr">
              <input type="hidden" name="imgSet_adjAutoCont" value="<%getResourceValue( "image.adj.auto.cont" );%>">
        &nbsp;<select size="1" name="image.adj.auto.cont" class="selLarge" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="imset_met"></span>
    </td>
    <td class="tdr">
              <input type="hidden" name="imgSet_adjAutoMode" value="<%getResourceValue( "image.adj.auto.mode" );%>">
        &nbsp;<select name="image.adj.auto.mode" class="selLarge" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="imset_pal"></span>
    </td>
    <td class="tdr">
              <input type="hidden" name="imgSet_palette" value="<%getResourceValue( "image.adj.palette.filename" );%>">
        &nbsp;<select size="1" class="selLarge" name="image.adj.palette.filename" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
<%
ifResource("config.measure.tempOK", "EQ", "true", "<span id='imset_tscale'>", "<span id='imset_scale'>");
%>
    </span></td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
      <input type="hidden" name="checkboxdescr" value="fLinear:image.adj.forceLinear|true:image.adj.forceLinear|false">
<script>
function clickBox(obj)
{
  if (obj.checked)
    obj.form.elements['image.adj.auto.mode'].disabled = true;
  else
    obj.form.elements['image.adj.auto.mode'].disabled = false;
}
</script>
      <input type="checkbox" size="6" name="checkbox.fLinear" style="visibility:hidden;" value="true" <%ifResource("image.adj.forceLinear", "EQ", "true", "checked", "");%> onClick="clickBox(this);"><span id="imset_flin"></span>
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<tr><td class='tdl'>&nbsp;<span id='imset_hval'></span></td><td class='tdr'>&nbsp;<input type='text'  style='visibility:hidden;' name='TEMPERATURE.image.adj.highT' class='textStyle' value='");
  getTemperatureValue("image.adj.highT", "%0.1f");
  write("'><span id='imset_tunit1'></span>");
  write("</td></tr>");
  write("<tr><td class='tdl'>&nbsp;<span id='imset_lval'></span></td><td class='tdr'>&nbsp;<input type='text' style='visibility:hidden;'  name='TEMPERATURE.image.adj.lowT' class='textStyle' value='");
  getTemperatureValue("image.adj.lowT", "%0.1f");
  write("'><span id='imset_tunit2'></span>");
  write("<input type='hidden' name='imgSet_latchMode' value='");
  getResourceValue( "image.adj.latchMode" );
  write("'>");
  write("</td></tr>");
  write("<tr>\n<td class='tdl'>&nbsp;<span id='imset_lto'></span></td>\n<td class='tdr'>\n&nbsp;<select size='1' name='image.adj.latchMode' style='visibility:hidden;'>");
  write("</select>\n</td>\n</tr>\n");
}
%>
  <tr>
    <td class="tdl">
         &nbsp;<span id="imset_reb"></span>
    </td>
    <td class="tdr">
              <input type="hidden" name="imgSet_dsOverride" value="<%getResourceValue( "system.dsoverride" );%>">
         &nbsp;<select size="1" name="system.dsoverride" onChange="javascript:setOverride(this);" style="visibility:hidden;"></select><br><br>
    </td>
 </tr>
  <tr>
    <td class="tdt" colspan="2">
        <br><input type="submit" value="" style="visibility:hidden;" name="imset_submit" class="update">
    </td>
  </tr>
</table>
<input type="hidden" name="image.adj.prefs.override" value="<%getResourceValue("image.adj.prefs.override");%>">
<input type="hidden" name="system.autosync" value="2">
</form>
</body>
</html> 