<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Isotherm settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/multiple.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
function isoSubmit(obj)
{
  applyOnForm(obj.name, 'submit');
  return validateForm(obj);
}
function openIsoCtrl(isoNum)
{
  var popurl = "/goform/setResourceValues?redirect=/user/iso/isoControl.asp&system.web.temp1=image.mfunc.isotherm."
  popurl += isoNum;
  var typeObj = document.forms['iForm.' + isoNum].elements['image.mfunc.isotherm.' + isoNum + '.type'];
  popurl += "&system.web.temp2=" + typeObj.options[typeObj.selectedIndex].value + "&system.web.temp3="
  popurl += isoNum;
  winpops=window.open(popurl,"","width=220,height=335");
  return false;
}
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<form name="BEHAVIOR:iForm$">

</form>
<form name="VALIDATE:iForm$">
  <input type="hidden" name="BREAK:checkbox.checked:CONTINUE:STOP|checkbox.actiso.$" value="NOMESSAGE">
  <input type="hidden" name="JUMP:combobox.selected:==:2:FAILED:1|image.mfunc.isotherm.$.type" value="NOMESSAGE">
  <input type="hidden" name="NUMBER:>=:iForm$.TEMPERATURE.image.mfunc.isotherm.$.lowT|TEMPERATURE.image.mfunc.isotherm.$.highT" value="High value must be equal to or greater than Low temperature">
</form>
<table>
<%includeFile("/user/iso/iso.inc", "config.measure.isotherm.maxnum");%>
</table>
</body></html>