<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Isotherm control</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
  <table style="width:100%;">
    <th style="width:100%;text-align:center;" colspan="4"><span id="isoc_isoc">
<%
var isoPath = getResourceValue ( "system.web.temp1", "false");
var isoTypePath = isoPath + ".type";
var isoType = getResourceValue ( isoTypePath, "false");
var isoNum = getResourceValue ( "system.web.temp3", "false");
var maxIso = getResourceValue ( "config.measure.isotherm.maxnum", "false");
var highPath = isoPath + ".high";
var highVal = getResourceValue ( highPath, "false");
var lowPath = isoPath + ".low";
var lowVal = getResourceValue ( lowPath, "false");
if (maxIso != "1")
{
  write(isoNum);
}
write("</span></th></tr><tr><td colspan='4'>&nbsp;</td></tr>");
if (isoType != "interval")
{
  write("<tr><td class='tdlStat' style='width:100%;text-align:center;' colspan='4'><span id='isoc_pos'></span></td></tr>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal - 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_hdd' class='update' style='width:30px;visibility:hidden;' value='<<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal - 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_hd' class='update' style='width:30px;visibility:hidden;' value='<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal + 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_hup' class='update' style='width:30px;visibility:hidden;' value='>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal + 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_hpp' class='update' style='width:30px;visibility:hidden;' value='>>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
  write("<tr><td style='width:100%text-align:center;' colspan='4'><form  ACTION=/goform/setResourceValues METHOD=POST><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'><INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
  getResourceValue("image.adj.level");
  write("'>\n<input type='submit' name='isoc_home' class='update' style='visibility:hidden;'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
}
else
{
  write("<tr><td class='tdlStat' style='width:100%;text-align:center;' colspan='4'><span id='isoc_high'></span></td></tr>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal - 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_hdd' class='update' style='width:30px;visibility:hidden;' value='<<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal - 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_hd' class='update' style='width:30px;visibility:hidden' value='<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal + 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_hup' class='update' style='width:30px;visibility:hidden;' value='>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
var val = highVal + 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_hpp' class='update' style='width:30px;visibility:hidden;' value='>>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
  write("<tr><td style='width:100%text-align:center;' colspan='4'><form  ACTION=/goform/setResourceValues METHOD=POST><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'><INPUT TYPE='hidden' NAME='");
  write(highPath);
  write("' VALUE='");
  getResourceValue("image.adj.level");
  write("'>\n<input type='submit' name='isoc_home' class='update' style='visibility:hidden;'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
  write("<tr><td colspan='4'>&nbsp;</td></tr><tr><td class='tdlStat' style='width:100%;text-align:center;' colspan='4'><span id='isoc_low'></span></td><tr>");


  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(lowPath);
  write("' VALUE='");
var val = lowVal - 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_ldd' class='update' style='width:30px;visibility:hidden;' value='<<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(lowPath);
  write("' VALUE='");
var val = lowVal - 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_ld' class='update' style='width:30px;visibility:hidden;' value='<'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(lowPath);
  write("' VALUE='");
var val = lowVal + 5;
  write(val);
  write("'>\n<input type='submit' name='isoc_lup' class='update' style='width:30px;visibility:hidden;' value='>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>");
  write("<td style='width:25%text-align:center;'>\n<FORM ACTION=/goform/setResourceValues METHOD=POST>\n<INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'>\n<INPUT TYPE='hidden' NAME='");
  write(lowPath);
  write("' VALUE='");
var val = lowVal + 50;
  write(val);
  write("'>\n<input type='submit' name='isoc_lpp' class='update' style='width:30px;visibility:hidden;' value='>>'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
  write("<tr><td style='width:100%text-align:center;' colspan='4'><form  ACTION=/goform/setResourceValues METHOD=POST><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/iso/isoControl.asp'><INPUT TYPE='hidden' NAME='");
  write(lowPath);
  write("' VALUE='");
  getResourceValue("image.adj.level");
  write("'>\n<input type='submit' name='isoc_home' class='update' style='visibility:hidden;'>\n<input type='hidden' name='webserver.delay' value='350'></form>\n</td>\n</tr>");
}
%>
  </table>
</body>
</html>