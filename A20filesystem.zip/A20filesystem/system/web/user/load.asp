<html>
<head>
<title>Loading application</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.3"></script>
<script>
<!--
var images = new Array();
var imgFiles = new Array("/flirtrans.gif", "/A40.gif", "/camera.gif", "/user/images/czech.gif,", "/user/images/denmark.gif", "/user/images/english.gif", "/user/images/finland.gif", "/user/images/france.gif", "/user/images/germany.gif", "/user/images/hungary.gif,", "/user/images/italy.gif", "/user/images/japan.gif", "/user/images/norway.gif", "/user/images/poland.gif", "/user/images/portugal.gif", "/user/images/russia.gif", "/user/images/spain.gif", "/user/images/sweden.gif", "/user/images/usa.gif");
for (var i = 0; i < imgFiles.length; i++)
{
    var img = new Image();
    img.src = imgFiles[i];
    images[images.length] = img;
}
-->
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table width="100%" height="100%" style="width:100%;">
<tr>
  <td width="100%" height="35%">&nbsp;</td>
</tr>
<tr>
  <td width="100%" height="10%">
    <center>
      <h1>Loading application</h1><br><br>
    <center>
  </td>
</tr>
<tr>
  <td width="100%" height="55%">&nbsp;</td>
</tr>
</table>
</body>
</html>