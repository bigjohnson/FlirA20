<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Localisation</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
var vMode = new Array(<%CTextOptions("image.videomode", "\"");%>);//"
var tmpWin = null;
var currNode = null;
function closeTmpWin()
{
  this.timer = null;
  if (tmpWin == null)
    return;
  window.clearInterval(timer);
  tmpWin.close();
  tmpWin = null;
}
function changeMode()
{
  var switchOK = confirm("This will restart your camera!\nPress OK to continue.");
  if (switchOK)
  {
    var vModeFrm = document.forms["vmode"];
    if (vModeFrm == null)
      return;
    var vModeObj = vModeFrm.elements["videoModeVal"];
    if (vModeObj == null)
      return;
    if (vMode == undefined)
      var vMode = new Array(<%CTextOptions("image.videomode", "'");%>);
    if (vMode.length < 3)
      return;

    var currNode = null;
    if (document.getElementsById != null)
      currNode = document.getElementsById("loc_videomode");
    else if (document.all != null)
      currNode = document.all["loc_videomode"];
    if (currNode == null)
      return;
    var newMode;
    var currMode = vMode[0];
    if (currMode == vMode[1])
      newMode = vMode[2];
    else
      newMode = vMode[1];
    vMode[0] = newMode;
    var newNode = document.createTextNode(newMode);
    currNode.removeChild(currNode.childNodes[0]);
    currNode.appendChild(newNode);
    tmpWin = window.open("/goform/setResourceValues?image.videomode=" + newMode, "hideWindow", "width=100,height=100,menubar=no,resizable=no,scrollbars=no,toolbar=no");
    closeTmpWin.timer = timer;
    window.setInterval("closeTmpWin();", 1500);
  }
}
function setLangFile(obj)
{
  if (obj == null)
    return;
  if (obj.value == null)
    return;
  var fName = obj.value + ".FLF";
  if (obj.value == "English")
    fName = "";
  var frm = document.forms["locForm"];
  if (frm == null)
    return;
  var fnObj = frm.elements["gui.local.languageFile"];
  var langObj = frm.elements["gui.local.language"];
  if (fnObj == null)
    return;
  if (fnObj.value == null)
    return;
  fnObj.value = fName;
  if (langObj == null)
    return;
  if (langObj.value == null)
    return;
  langObj.value = obj.value;
}
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table>
  <tr>
    <th colspan="2">
       <span id="loc_loc" style="visibility:hidden;"></span>
    </th>
  </tr>
  <tr>
    <td class="tdl" style="width:100%;" colspan="2">
      <br>
      <form name="vmode"><input type="hidden" name="videoModeVal" value="<%getResourceValue("image.videomode");%>"></form>
      <span id="loc_currmode" style="visibility:hidden;"></span>&nbsp;<span id="loc_videomode" style="font-weight:bold;visibility:hidden;"></span><span>
      <br>
      <input type="button" name="loc_vmSubmit" value="" onClick="changeMode();" style="visibility:hidden;"></span>
    </td>
  </tr>
  <form method="post" action="/goform/setResourceValues" name="locForm">
  <input type="hidden" name="redirect" value="/user/locale.asp">
  <tr>
    <td class="tdl">
       &nbsp;<span id="loc_lang"></span>
    </td>
    <td class="tdr">
       <input type="hidden" name="gui.local.language" value="<%getResourceValue("gui.local.language");%>">
       <input type="hidden" name="gui.local.languageFile" value="<%getResourceValue("gui.local.languageFile");%>">
       <span id="RADIOGROUP.loc_langChoise.locForm" style="visibility:hidden;">
       </span>
       <input type="hidden" name="gui.system.reset" value="true">
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<tr><td class='tdl'>&nbsp;<span id='loc_tunit' style='visibility:hidden;'></span></td><td class='tdr'>&nbsp;<select size='1' name='gui.local.tempUnit' style='visibility:hidden;'></select>\n</td>\n</tr>\n");
  write("<tr><td class='tdl'>&nbsp;<span id='loc_dunit' style='visibility:hidden;'></span></td><td class='tdr'>&nbsp;<select size='1' name='gui.local.distUnit' style='visibility:hidden;'></select>");
  var selectedUnit = getResourceValue("gui.local.distUnit", "false");
  write("<input type='hidden' name='tunitVal' value='");
  getResourceValue("gui.local.tempUnit");
  write("'><input type='hidden' name='dunitVal' value='");
  getResourceValue("gui.local.distUnit");
  write("'></td>\n</tr>\n");

}
%>
  <tr>
    <td class="tdl">
       &nbsp;<span id="loc_tformat" style="visibility:hidden;"></span>
    </td>
    <td class="tdr">
             <input type="hidden" name="tformatVal" value="<%getResourceValue("gui.local.timeFormat");%>">
       &nbsp;<select size="1" name="gui.local.timeFormat" style="visibility:hidden;"></select>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="loc_dformat" style="visibility:hidden;"></span>
    </td>
    <td class="tdr">
             <input type="hidden" name="dformatVal" value="<%getResourceValue("gui.local.dateFormat");%>">
       &nbsp;<select size="1" name="gui.local.dateFormat" style="visibility:hidden;"></select>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
       <br>
       <input type="hidden" name="system.autosync" value="2">
       <input type="submit" class="update" name="loc_submit" value="" style="visibility:hidden;"><br>
<span style="visibility:hidden">
<input type="radio" name="local.language" value="English" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Swedish" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="French" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="German" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Czech" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Portugese" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Hungar" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Polish" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Spanish" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Russian" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Norwegian" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Danish" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Finnish" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Italian" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
<input type="radio" name="local.language" value="Japanese" disabled="true" style="visibility:hidden;" onClick="setLangFile(this);">
</span>
    </td>
  </tr>
  </FORM>
</table>
</body>
</html>