<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Log entry</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/logg.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<script>
    function popUp(img)
    {
       window.open("/goform/setResourceValues?redirect=/user/imgPop.asp&system.web.temp1=" + img, "displayWindow", "width=660,height=500");
    }
</script>
<form>
<table style="width:100%;" style="visibility=hidden;" id="detLog">
  <tr>
    <td style="width:100%;height:1;background-color:#000000;" colspan="3">
    </td>
  </tr>
        <%createDetailedLog( "system.web.temp1", "class=\"td4\" style=\"width:33%\"", "class=\"td4\" style=\"width:33%\"", "class=\"td4\" style=\"width:33%\"" );%>
</table>
</form>
</body>

</html>
