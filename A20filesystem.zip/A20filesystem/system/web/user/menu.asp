<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Menu frame</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
  function openCamCtrl()
  {
    var popurl="/user/camcontrol.asp"

    winpops=window.open(popurl,"","width=240,height=390");
    return false;
  }
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table style="width:100%;">
  <tr>
    <td class="tdt" style="width:100%;">
      <span id="men_img"></span>
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
var showIso = ifResource("config.measure.isoCoverage", "EQ", "true");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='box/mbox.asp' target='mainframe'><span id='men_box'></span></a></td></tr>\n");
}
if (showMeasure == "false" && isoNum != 0)
{
  write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='iso/iso.asp' target='mainframe'><span id='men_iso'></span></a></td></tr>\n");
}
%>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="imgparams.asp" target="mainframe"><span id="men_img_set"></span></a>
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='objpar.asp' target='mainframe'><span id='men_obpar'></span></a></td></tr>\n");
%>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="result.asp" target="newWindow" onClick="window.top.openViewer();return false;"><span id="men_imgView"></span></a>
    </td>
  </tr>
  <tr>
    <td style="width:100%">
      &nbsp;
    </td>
  </tr>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<tr><td class='tdt' style='width:100%;'><span id='men_meas'></span></td></tr>\n");
    if (showSpot == "true")
      write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='spot/spot.asp' target='mainframe'><span id='men_spot'></span></a></td></tr>\n");
    if (showBox == "true")
      write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='box/mbox.asp' target='mainframe'><span id='men_box'></span></a></td></tr>\n");
    if (showDiff == "true")
      write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='diff/diff.asp' target='mainframe'><span id='men_diff'></span></a></td></tr>\n");
    if (showIso == "true")
      write("<tr><td class='tdts' style='width:100%;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='iso/iso.asp' target='mainframe'><span id='men_iso'></span></a></td></tr>\n");
    write("<tr>\n<td style='width:100%;'>&nbsp;</td>\n</tr>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<tr><td class='tdt' style='width:100%;'><span id='men_almlog_group'></span></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='alarm/alm.asp' target='mainframe'><span id='men_alm'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='alarm/batch.asp' target='mainframe'><span id='men_batch'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='alarm/alarmlog.html' target='mainframe'><span id='men_almlog'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='alarm/logactions.asp' target='mainframe'><span id='men_logset'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;</td></tr><tr><td class='tdt' style='width:100%;'><span id='men_ports'></span></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='camout.asp' target='mainframe'><span id='men_camout'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='anlport.asp' target='mainframe'><span id='men_anlgport'></span></a></td></tr><tr><td class='tdts' style='width:100%;'>");
    write("&nbsp;&nbsp;&nbsp;&nbsp;<a href='testout.asp' target='mainframe'><span id='men_testio'></span></a></td></tr><tr><td style='width:100%'>&nbsp;</td></tr>");
  }
%>
  <tr>
    <td class="tdt" style="width:100%;">
      <span id="men_gen"></span>
    </td>
  </tr>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="locale.asp" target="mainframe"><span id="men_local"></span></a>
    </td>
  </tr>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="guiset.asp" target="mainframe"><span id="men_camui"></span></a>
    </td>
  </tr>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="webset.asp" target="mainframe"><span id="men_webview"></span></a>
    </td>
  </tr>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="sysset.asp" target="mainframe"><span id="men_sysset"></span></a>
    </td>
  </tr>
  <tr>
    <td class="tdts" style="width:100%;">
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="sysstat.asp" target="mainframe"><span id="men_sysinf"></span></a>
    </td>
  </tr>
  <tr>
    <td style="width:100%">
      &nbsp;
    </td>
  </tr>
  <tr>
    <td style="width:100%">
      <INPUT TYPE="button" VALUE="" class="update" name="men_contr" style="visibility:hidden;" OnClick="return openCamCtrl()">
    </td>
  </tr>
</table>
</body>
</html>
