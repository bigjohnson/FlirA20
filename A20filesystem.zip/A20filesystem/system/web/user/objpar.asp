<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache"/>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Object parameters</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css"/>
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css"/>
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<form METHOD="post" ACTION="/goform/setResourceValues" name="opForm" onSubmit="return validate(this);">
<input TYPE="hidden" NAME="redirect" VALUE="/user/objpar.asp">
<table>
  <tr>
    <th colspan="2">
      <span id="obp_obp"></span>
    </th>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_emiss"></span>
    </td>
    <td class="tdr">
        <input type="text" name="image.objpar.emissivity" class="textStyle" style="visibility:hidden;" value="<%getResourceValue( "image.objpar.emissivity", "%0.2f" );%>">
        <input type="button" value="" name="obp_lookup" style="visibility:hidden;" onClick="popEmisTable('image.objpar.emissivity');">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_dist"></span>
    </td>
    <td class="tdr">
        <input type="text" name="DISTANCE.image.objpar.distance" class="textStyle" style="visibility:hidden;" value="<%getDistanceValue( "image.objpar.distance" );%>">
        <span id="obp_dunit1"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_refl"></span>
    </td>
    <td class="tdr">
        <input type="text" name="TEMPERATURE.image.objpar.ambTemp" class="textStyle" style="visibility:hidden;" value="<%getTemperatureValue( "image.objpar.ambTemp" );%>">
        <span id="obp_tunit1"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_atm"></span>
    </td>
    <td class="tdr">
        <input type="text" name="TEMPERATURE.image.objpar.atmTemp" class="textStyle" style="visibility:hidden;" value="<%getTemperatureValue( "image.objpar.atmTemp" );%>">
        <span id="obp_tunit2"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_relhum"></span>
    </td>
    <td class="tdr">
        <input type="text" name="image.objpar.relHum" class="textStyle" style="visibility:hidden;" value="<%getResourceValue( "image.objpar.relHum", "%0.2f" );%>">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_eotrans"></span>
    </td>
    <td class="tdr">
        <input type="text" name="image.objpar.extOptTrans" class="textStyle" style="visibility:hidden;" value="<%getResourceValue( "image.objpar.extOptTrans", "%0.2f" );%>">
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_eosrc"></span>
    </td>
    <td class="tdr">
        <span id="obp_selsrc">
          <input type="hidden" name="extOptTemp_src" value="<%getResourceValue( "monitor.input.extOptTemp" );%>">
          <select size="1" name="monitor.input.extOptTemp" style="visibility:hidden;" ></select>
        </span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_eotemp"></span>
    </td>
    <td class="tdr">
        <input type="text" name="TEMPERATURE.image.objpar.extOptTemp" class="textStyle" style="visibility:hidden;" value="<%getTemperatureValue( "image.objpar.extOptTemp", "%0.1f" );%>">
        <span id="obp_tunit3"></span>
        <br><br>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="obp_ref"></span>
    </td>
    <td class="tdr">
        <input type="text" name="TEMPERATURE.image.mfunc.reftemp.1.valueT" class="textStyle" style="visibility:hidden;" value="<%getTemperatureValue( "image.mfunc.reftemp.1.valueT", "%0.1f" );%>">
        <span id="obp_tunit4"></span>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <br>
        <input type="submit" value="" class="update" style="visibility:hidden;" name="obp_submit" id="obp_submit">
    </td>
  </tr>
</table>
<input type="hidden" name="system.autosync" value="2">
</form>
</body>
</html>