<HTML>
<HEAD>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<TITLE>Result table</TITLE>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
function reloadDoc()
{
  window.location = '/user/empty.html?redirect=' + document.URL;
}
<%
var shallReload = ifResource("system.web.restabDelay", "NEQ", "0");
if (shallReload == "true")
{
  write("var reloadDelay = new Number(1000);reloadDelay *= ");
  getResourceValue("system.web.restabDelay");
  write(";var reloadTimer = setTimeout('reloadDoc()', reloadDelay );");
}
%>
</script>
</HEAD>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<span style="visibility:hidden;" id="res_table">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var haveIO = ifResource("config.system.ioports", "EQ", "true");
if (haveIO == "true")
{
  var haveAlarm = ifResource("config.monitor.alarm.maxnum", "NEQ", "0");
  var showAlarm = ifResource("system.web.showAlarm", "EQ", "true");
  if (haveAlarm == "true" && showAlarm == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_alm'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:30px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:210px;' id='res_cond'></TD>");
    write("<TD class='tdt_nwc' style='width:60px;'>&nbsp;</TD></TR>");
    getRestab( "monitor.alarm", "active", "", "", "#", ":ALARM:", ":<span class=\"spanRed\" id=\"res_red\"></span>|<span class=\"spanGreen\" id=\"res_green\"></span>:result" );
    write("</TABLE>");
  }
}
if (showMeasure == "true")
{
  var haveSpots = ifResource("config.measure.spot.maxnum", "NEQ", "0");
  var showSpots = ifResource("system.web.showSpot", "EQ", "true");
  if (haveSpots == "true" && showSpots == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_spot'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:65px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:95px;' id='res_temp'></TD>");
    write("<TD class='tdt_nwc' style='width:70px;' id='res_x'></TD>");
    write("<TD class='tdt_nwc' style='width:70px;' id='res_y'></TD></TR>");
    getRestab( "image.mfunc.spot", "active", "", "", "#", "valueT", "x", "y" );
    write("</TABLE>");
  }
}
var haveBoxes = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showBoxes = ifResource("system.web.showMbox", "EQ", "true");
if (haveBoxes == "true" &&  showBoxes == "true")
{
  if (showMeasure == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_box'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:40px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:65px;' id='res_cov'></TD>");
    write("<TD class='tdt_nwc' style='width:65px;' id='res_min'></TD>");
    write("<TD class='tdt_nwc' style='width:65px;' id='res_max'></TD>");
    write("<TD class='tdt_nwc' style='width:65px;' id='res_avg'></TD></TR>");
    getRestab( "image.mfunc.mbox", "active", "", "", "#", ":%%0.1f:isoCoverage", "minT", "maxT", "avgT" );
    write("</TABLE>");
  }
  else
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_box'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:65px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:235px;' id='res_cov2'></TD>");
    getRestab( "image.mfunc.mbox", "active", "", "", "#", ":%%0.1f:isoCoverage" );
  }
}
if (showMeasure == "true")
{
  var haveLines = ifResource("config.measure.mline.maxnum", "NEQ", "0");
  var showLines = ifResource("system.web.showLine", "EQ", "true");
  if (haveLines == "true" &&  showLines == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_line'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:65px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:75px;' id='res_min'></TD>");
    write("<TD class='tdt_nwc' style='width:75px;' id='res_max'></TD>");
    write("<TD class='tdt_nwc' style='width:75px;' id='res_curs'></TD></TR>");
    getRestab( "image.mfunc.mline", "active", "", "", "#", "minT", "maxT", "valueT" );
    write("</TABLE>");
  }
}
if (showMeasure == "true")
{
  var haveIsos = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
  var showIsos = ifResource("system.web.showIso", "EQ", "true");
  if (haveIsos == "true" &&  showIsos == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_iso'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:65px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:117px;' id='res_low'></TD>");
    write("<TD class='tdt_nwc' style='width:118px;' id='res_high'></TD>");
    getRestab( "image.mfunc.isotherm", "active", "", "", "#", "lowT", "highT" );
    write("</TABLE>");
  }
}
if (showMeasure == "true")
{
  var haveDiffs = ifResource("config.measure.diff.maxnum", "NEQ", "0");
  var showDiffs = ifResource("system.web.showDiff", "EQ", "true");
  if (haveDiffs == "true" &&  showDiffs == "true")
  {
    write("<TABLE style='width:300px;'><TR><TH style='text-align:center;' id='res_diff'></TH></TR><TR><TD><TABLE style='width:300px;'><TR>");
    write("<TD class='tdt_nwc' style='width:50px;text-align:left;' id='res_no'></TD>");
    write("<TD class='tdt_nwc' style='width:85px;' id='res_val0'></TD>");
    write("<TD class='tdt_nwc' style='width:20px;'>#</TD>");
    write("<TD class='tdt_nwc' style='width:85px;' id='res_val1'></TD>");
    write("<TD class='tdt_nwc' style='width:20px;'>#</TD>");
    write("<TD class='tdt_nwc' style='width:45px;' id='res_dVal'></TD>");
    getRestab( "image.mfunc.diff", "active", "", "", "#", "type0", "id0", "type1", "id1", ":DT:valueT" );
    write("</TABLE>");
  }
}
if (shallReload != "true")
{
  write ("<tr><td><input type='button' value='' class='update' name='res_refresh' onClick='reloadDoc();'></td></tr>");
}
%>
</TABLE>
</span>
</BODY>
</HTML>
