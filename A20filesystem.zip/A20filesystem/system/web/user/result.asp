<head>
<title>Web viewer</title>
<%
var haveResults = "false";
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var haveIO = ifResource("config.system.ioports", "EQ", "true");
if (showMeasure == "true")
{
  var haveSpots = ifResource("config.measure.spot.maxnum", "NEQ", "0");
  var showSpots = ifResource("system.web.showSpot", "EQ", "true");
  var haveBoxes = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
  var showBoxes = ifResource("system.web.showMbox", "EQ", "true");
  var haveLines = ifResource("config.measure.mline.maxnum", "NEQ", "0");
  var showLines = ifResource("system.web.showLine", "EQ", "true");
  var haveIsos = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
  var showIsos = ifResource("system.web.showIso", "EQ", "true");
  var haveDiffs = ifResource("config.measure.diff.maxnum", "NEQ", "0");
  var showDiffs = ifResource("system.web.showDiff", "EQ", "true");
  if ((haveSpots == "true" && showSpots == "true") ||
     (haveBoxes == "true" && showBoxes == "true") ||
     (haveLines == "true" && showLines == "true") ||
     (haveIsos == "true" && showIsos == "true") ||
     (haveDiffs == "true" && showDiffs == "true"))
       haveResults = "true";
}
if (haveIO == "true")
{
  var haveAlarm = ifResource("config.monitor.alarm.maxnum", "NEQ", "0");
  var showAlarm = ifResource("system.web.showAlarm", "EQ", "true");
  if (haveAlarm == "true" && showAlarm == "true")
    haveResults = "true";
}
if (haveResults == "true")
{
  write("<script>function setFrame(){window.frames['imgView'].location = '/user/result.html';}</script>");
}
else
{
  write("<script>function setFrame(){window.frames['imgView'].location = '/user/result2.html';}</script>");
}
%>
</head>
<FRAMESET BORDER="0" FRAMEBORDER="0" FRAMESPACING="0" ROWS="*" onLoad="javascript:setFrame();">
    <FRAME name = "imgView" SRC="empty.html">
</FRAMESET>
