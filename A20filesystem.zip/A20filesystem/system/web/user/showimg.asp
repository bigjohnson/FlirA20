<html>
<head>
<meta http-equiv="pragma" content="no-cache">
<title>Show image</title>
</head>

<body bgcolor="#F8F9D9" onLoad="javascript:Load()">
<script>
function Load()
{
   window.width=660;
}
</script>
<img border="0" src="/IMAGES/<%getResourceValues( "system.web.temp1" );%>" WIDTH="640" HEIGHT="480">
<br>
<br>
<INPUT TYPE="submit" VALUE="Close" OnClick="window.close()">

</body>

</html>
