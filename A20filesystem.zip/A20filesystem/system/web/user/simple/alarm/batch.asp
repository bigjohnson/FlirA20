<html>
<head>
<title>Camera user web</title>
</head>
<body background="/user/bkg.gif" bgColor="moccasin">
  <table width="100%">
    <tr>
<!-- head  -->
      <td width="220px">
        <a href="/index.asp"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
      </td>
      <td>
        <center><font size="400%" face="Century gothic"><a href="/user/simple/index.asp"><%getResourceValue("version.product.name");%></a></font></center>
      </td>
    </tr>
    <tr>
      <td vAlign="top">
<!-- menu  -->
<div>
<font face="Century gothic"><b>Image</b></font><br>
<font weight="lighter" face="Tahoma">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
}

if (showMeasure == "false" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
}
%>
&nbsp;<a href="/user/simple/imgparams.asp">Image settings</a><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("&nbsp;<a href='/user/simple/objpar.asp'>Object parameters</a><br>\n");
%>
</font>
</div>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showLine    = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showLine == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<br><div><font face='Century gothic'><b>Measurments</b></font><br><font weight='lighter' face='Tahoma'>\n");
    if (showSpot == "true")
      write("&nbsp;<a href='/user/simple/spot/spot.asp'>Spots</a><br>\n");
    if (showBox == "true")
      write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
    if (showLine == "true")
      write("&nbsp;<a href='/user/simple/line/line.asp'>Lines</a><br>\n");
    if (showDiff == "true")
      write("&nbsp;<a href='/user/simple/diff/diff.asp'>Diffs</a><br>\n");
    if (showIso == "true")
      write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
    write("</font></div>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<br><div><font face='Century gothic'><b>Alarm and logging</b></font><br><font weight='lighter' face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/alarm/alm.asp'>Alarms</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/batch.asp'>Batch settings</a><br>");
    write("&nbsp;<a href='/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true'>Alarm log</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/logactions.asp'>Log settings</a><br></font></div>");
    write("<br><div><font face='Century gothic'><b>Camera ports</b></font><br><font weight='lighter' face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/camout.asp'>Camera outputs</a><br>");
    write("&nbsp;<a href='/user/simple/anlport.asp'>Analog ports</a><br>");
    write("&nbsp;<a href='/user/simple/testout.asp'>Test I/O ports</a><br></font></div>");
  }
%>
<br>
<div>
<font face="Century gothic"><b>General settings</b></font><br>
<font weight="lighter" face="Tahoma">
  &nbsp;<a href="/user/simple/locale.asp">Local settings</span></a><br>
  &nbsp;<a href="/user/simple/guiset.asp">Camera user interface</a><br>
  &nbsp;<a href="/user/simple/sysset.asp">System settings</a><br>
  &nbsp;<a href="/user/simple/sysstat.asp">System information</a><br>
  &nbsp;<a href="/user/simple/camControl.asp">Camera control</a><br>
</font>
</div>
      </td>
      <td vAlign="top">
<!-- body -->
<form method="POST" action="/goform/setResourceValues">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/alarm/batch.asp">
<font face="Century gothic" size="5"><b>Batch settings</b></font><br>
<input type="hidden" name="checkboxdescr" value="useBatch:monitor.batchMode|true:monitor.batchMode|false">
<input type="checkbox" name="checkbox.useBatch" value="true" <%ifResource("monitor.batchMode", "EQ", "true", "checked", "");%>><font face="Tahoma">Use batch mode</font><br>
&nbsp;<font face="Tahoma">Trigger</font>
<select size="1" name="monitor.trigger.1.src">
  <option value="spot" <%ifResource("monitor.trigger.1.src", "EQ", "spot", "selected", "");%>>Spot</option>
  <option value="mbox" <%ifResource("monitor.trigger.1.src", "EQ", "mbox", "selected", "");%>>Box</option>
  <option value="diff" <%ifResource("monitor.trigger.1.src", "EQ", "diff", "selected", "");%>>Diff</option>
  <option value="anlgIn" <%ifResource("monitor.trigger.1.src", "EQ", "anlgIn", "selected", "");%>>Analog in</option>
  <option value="intTemp" <%ifResource("monitor.trigger.1.src", "EQ", "intTemp", "selected", "");%>>Int temp</option>
  <option value="digIn" <%ifResource("monitor.trigger.1.src", "EQ", "digIn", "selected", "");%>>Digital in.</option>
  <option value="digBidir" <%ifResource("monitor.trigger.1.src", "EQ", "digBidir", "selected", "");%>>Dig. bi-dir</option>
</select>
<input type="text" size="2" name="monitor.trigger.1.srcId" value="<%getResourceValue("monitor.trigger.1.srcId");%>">
<select size="1" name="monitor.alarm.$.srcRes">
  <option value="value" <%ifResource("monitor.trigger.1.srcRes", "EQ", "value", "selected", "");%>>Value</option>
  <option value="max" <%ifResource("monitor.trigger.1.srcRes", "EQ", "max", "selected", "");%>>Max</option>
  <option value="min" <%ifResource("monitor.trigger.1.srcRes", "EQ", "min", "selected", "");%>>Min</option>
  <option value="avg" <%ifResource("monitor.trigger.1.srcRes", "EQ", "avg", "selected", "");%>>Average</option>
  <option value="iso" <%ifResource("monitor.trigger.1.srcRes", "EQ", "iso", "selected", "");%>>Coverage</option>
</select><br>
&nbsp;<font face="Tahoma">Condition</font>
<select size="1" name="monitor.trigger.1.condition">
  <option value="greater" <%ifResource("monitor.trigger.1.condition", "EQ", "greater", "selected", "");%>>Greater</option>
  <option value="less" <%ifResource("monitor.trigger.1.condition", "EQ", "less", "selected", "");%>>Less</option>
  <option value="high" <%ifResource("monitor.trigger.1.condition", "EQ", "high", "selected", "");%>>High</option>
  <option value="low" <%ifResource("monitor.trigger.1.condition", "EQ", "low", "selected", "");%>>Low</option>
</select><br>
&nbsp;<font face="Tahoma">Threshold:
&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="TEMPERATURE.monitor.trigger.1.threshold" value="<%getResourceValue("monitor.trigger.1.threshold", "%0.1f");%>">
</font><br>
&nbsp;<font face="Tahoma">Hysteresis:
&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="DIFF_TEMPERATURE.monitor.trigger.1.hysteresis" value="<%getResourceValue("monitor.trigger.1.hysteresis", "%0.1f");%>">
</font><br>
<input type="submit" value="Update settings">
<input type="hidden" name="system.autosync" value="2">
</form>
      </td>
    </tr>
  </table>
</body>
</html>