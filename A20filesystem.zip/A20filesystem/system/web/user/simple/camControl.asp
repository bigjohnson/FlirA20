<html>
<head>
<title>Camera Control</title>
</head>
<body background="/user/bkg.gif">
<table>
 <tr>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
  <td>
    <font face="Tahoma"><b><center>Level</center></b></font>
  </td>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="-200">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;<<&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="-20">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;&nbsp;<&nbsp;&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="+20">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.level" VALUE="+200">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;>>&nbsp;&nbsp;"></center>
    </FORM>
  </td>
 </tr>
 <tr>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
  <td>
    <font face="Tahoma"><b><center>Span</center></b></font>
  </td>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="-200">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;<<&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="-20">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;&nbsp;<&nbsp;&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="+20">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;"></center>
    </FORM>
  </td>
  <td>
    <FORM ACTION=/goform/incResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.span" VALUE="+200">
      <center><INPUT TYPE="submit" VALUE="&nbsp;&nbsp;>>&nbsp;&nbsp;"></center>
    </FORM>
  </td>
 </tr>
 <tr>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
  <td>
    <font face="Tahoma"><b><center>Auto adjust</center></b></font>
  </td>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.cont" VALUE="true">
      <center><INPUT TYPE="submit" VALUE="On"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.now" VALUE="true">
      <center><INPUT TYPE="submit" VALUE="Adj now"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.auto.cont" VALUE="false">
      <center><INPUT TYPE="submit" VALUE="Off"></center>
    </FORM>
  </td>
 </tr>
<%
 var af = getResourceValue("config.image.autofocus", "false");
 var mf = getResourceValue("image.focus.motorPresent", "false");
 if (mf == "true")
 {
   write("<tr><td><font face='Tahoma'><center>Near</center></font></td><td>&nbsp;</td><td><font face='Tahoma'><b><center>Focus</center></b></font></td><td>&nbsp;</td><td><font face='Tahoma'><center>Far</center></font></td></tr>");
   if (af == "false")
   {
     write("<tr><td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-100'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='<<<'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-50'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;<<&nbsp;'></center></form></td>");
     write("<td><center><table><tr><td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-15'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;<'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='15'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='>&nbsp;'></center></form></td></tr></table></center></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='50'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;>>&nbsp;'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='100'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='400'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='>>>'></center></form></td></tr>");
     write("<tr><td>&nbsp;</td><td>&nbsp;</td><td><center><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.auto' VALUE='true'><INPUT TYPE='submit' VALUE='Auto'></center></td><td>&nbsp;</td><td>&nbsp;</td></tr>");
   }
   else
   {
     write("<tr><td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='600'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='<<<'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='150'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;<<&nbsp;'></center></form></td>");
     write("<td><center><table><tr><td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='-1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='50'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;<'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='50'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='>&nbsp;'></center></form></td></tr></table></center></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='150'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='&nbsp;>>&nbsp;'></center></form></td>");
     write("<td><FORM ACTION='/goform/setResourceValues' METHOD='POST'><INPUT TYPE='hidden' NAME='redirect' VALUE='/user/simple/camControl.asp'>");
     write("<INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='1'><INPUT TYPE='hidden' NAME='webserver.delay' VALUE='600'>");
     write("<center><INPUT TYPE='hidden' NAME='image.focus.motor' VALUE='0'><INPUT TYPE='submit' VALUE='>>>'></center></form></td></tr>");
   }
 }
%>
 <tr>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
  <td>
    <font face="Tahoma"><b><center>Image mode</center></b></font>
  </td>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.freeze" VALUE="true">
      <center><INPUT TYPE="submit" VALUE="Freeze"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
  <td>
    <FORM ACTION=/goform/setResourceValues METHOD=POST>
      <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
      <INPUT TYPE="hidden" NAME="image.adj.freeze" VALUE="false">
      <center><INPUT TYPE="submit" VALUE="Live"></center>
    </FORM>
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
  <td>
    <font face="Tahoma"><b><center>Image file</center></b></font>
  </td>
  <td>&nbsp;
  </td>
  <td>&nbsp;
  </td>
 </tr>
 <tr>
  <td>
        <FORM ACTION=/goform/setResourceValues METHOD=POST>
          <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
          <INPUT TYPE="hidden" NAME="image.file.autostore" VALUE="true">
          <center><input type="submit" value="Save"></center>
        </form>
  </td>
  <td>&nbsp;
  </td>
  <td>
        <form ACTION="/user/simple/images.asp" method="post">
          <center><input type="submit" value="View"></center>
        </form>
  </td>
  <td>&nbsp;
  </td>
  <td>
        <FORM ACTION=/goform/setResourceValues METHOD=POST>
          <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camControl.asp">
          <input type="hidden" name="image.file.deleteDir" value="<%getResourceValue("image.file.currDir");%>">
          <center><input type="submit" value="Clear all"></center>
        </form>
  </td>
 </tr>

</table>
<br>
<br>
<a href="/user/simple/index.asp"><b>User web</b></a>
</body>
</html>
