<html>
<head>
<title>Camera user web</title>
</head>
<body background="/user/bkg.gif" bgColor="moccasin">
  <table width="100%">
    <tr>
<!-- head  -->
      <td width="220px">
        <a href="/index.asp"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
      </td>
      <td>
        <center><font size="400%" face="Century gothic"><a href="/user/simple/index.asp"><%getResourceValue("version.product.name");%></a></font></center>
      </td>
    </tr>
    <tr>
      <td vAlign="top">
<!-- menu  -->
<div>
<font face="Century gothic"><b>Image</b></font><br>
<font face="Tahoma">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
}

if (showMeasure == "false" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
}
%>
&nbsp;<a href="/user/simple/imgparams.asp">Image settings</a><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("&nbsp;<a href='/user/simple/objpar.asp'>Object parameters</a><br>\n");
%>
</font>
</div>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showLine    = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showLine == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<br><div><font face='Century gothic'><b>Measurments</b></font><br><font face='Tahoma'>\n");
    if (showSpot == "true")
      write("&nbsp;<a href='/user/simple/spot/spot.asp'>Spots</a><br>\n");
    if (showBox == "true")
      write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
    if (showLine == "true")
      write("&nbsp;<a href='/user/simple/line/line.asp'>Lines</a><br>\n");
    if (showDiff == "true")
      write("&nbsp;<a href='/user/simple/diff/diff.asp'>Diffs</a><br>\n");
    if (showIso == "true")
      write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
    write("</font></div>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<br><div><font face='Century gothic'><b>Alarm and logging</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/alarm/alm.asp'>Alarms</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/batch.asp'>Batch settings</a><br>");
    write("&nbsp;<a href='/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true'>Alarm log</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/logactions.asp'>Log settings</a><br></font></div>");
    write("<br><div><font face='Century gothic'><b>Camera ports</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/camout.asp'>Camera outputs</a><br>");
    write("&nbsp;<a href='/user/simple/anlport.asp'>Analog ports</a><br>");
    write("&nbsp;<a href='/user/simple/testout.asp'>Test I/O ports</a><br></font></div>");
  }
%>
<br>
<div>
<font face="Century gothic"><b>General settings</b></font><br>
<font face="Tahoma">
  &nbsp;<a href="/user/simple/locale.asp">Local settings</span></a><br>
  &nbsp;<a href="/user/simple/guiset.asp">Camera user interface</a><br>
  &nbsp;<a href="/user/simple/sysset.asp">System settings</a><br>
  &nbsp;<a href="/user/simple/sysstat.asp">System information</a><br>
  &nbsp;<a href="/user/simple/camControl.asp">Camera control</a><br>
</font>
</div>
      </td>
      <td vAlign="top">
<!-- body -->
<font face="Century gothic" size="5"><b>Camera outputs</b></font><br>
<form name="logSet" ACTION="/goform/setResourceValues" METHOD="POST">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/camout.asp">
<input type="hidden" name="checkboxdescr" value="enabled:monitor.output.enabled|false:monitor.output.enabled|true">
<input type="checkbox" name="checkbox.enabled" value="true" <%ifResource("monitor.output.enabled", "EQ", "false", "checked", "");%>><font face="Tahoma"><b>Disable output</b></font><br>
<br>
<font face="Tahoma"><b>Digital ports</b></font><br>
<font face="Tahoma">Digital out 1:</font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select size="1" name="monitor.output.dig1">
  <option value="0">Off</option>
<%
var alms = getResourceValue("config.monitor.alarm.maxnum", "false");
var i;
var sel = getResourceValue("monitor.output.dig1", "false");
for (i = 1; i <= alms; i++)
{
  write("  <option value='");
  write(i);
  write("'");
  if (sel == i)
  {
    write(" selected");
  }
  write(">Alarm ");
  write(i);
  write("</option>\n");
}
%>
</select><br>
<font face="Tahoma">Digital out 2:</font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select size="1" name="monitor.output.dig2">
  <option value="0">Off</option>
<%
var alms = getResourceValue("config.monitor.alarm.maxnum", "false");
var i;
var sel = getResourceValue("monitor.output.dig2", "false");
for (i = 1; i <= alms; i++)
{
  write("  <option value='");
  write(i);
  write("'");
  if (sel == i)
  {
    write(" selected");
  }
  write(">Alarm ");
  write(i);
  write("</option>\n");
}
%>
</select><br>
<font face="Tahoma">Digital out 3:</font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select size="1" name="monitor.output.dig3">
  <option value="0">Off</option>
<%
var alms = getResourceValue("config.monitor.alarm.maxnum", "false");
var i;
var sel = getResourceValue("monitor.output.dig3", "false");
for (i = 1; i <= alms; i++)
{
  write("  <option value='");
  write(i);
  write("'");
  if (sel == i)
  {
    write(" selected");
  }
  write(">Alarm ");
  write(i);
  write("</option>\n");
}
%>
</select>
<input type="hidden" name="checkboxdescr" value="vsync:system.ioports.vsync_inactive|false:system.ioports.vsync_inactive|true">
<input type="checkbox" name="checkbox.vsync" value="true" <%ifResource("system.ioports.vsync_inactive", "EQ", "false", "checked", "");%>><font face="Tahoma">V-Sync</font><br>
<font face="Tahoma">Bi-dir digital out:</font>
<select size="1" name="monitor.output.digbidir">
  <option value="0">Off</option>
<%
var alms = getResourceValue("config.monitor.alarm.maxnum", "false");
var i;
var sel = getResourceValue("monitor.output.digbidir", "false");
for (i = 1; i <= alms; i++)
{
  write("  <option value='");
  write(i);
  write("'");
  if (sel == i)
  {
    write(" selected");
  }
  write(">Alarm ");
  write(i);
  write("</option>\n");
}
%>
</select><br>
<br>
<font face="Tahoma"><b>Analog ports</b></font><br>
<font face="Tahoma">Analog out 1:</font>
<select size="1" name="monitor.output.anlg1Src">
  <option value="spot" <%ifResource("monitor.output.anlg1Src", "EQ", "spot", "selected", "");%>>Spot</option>
  <option value="mbox" <%ifResource("monitor.output.anlg1Src", "EQ", "mbox", "selected", "");%>>Box</option>
  <option value="isotherm" <%ifResource("monitor.output.anlg1Src", "EQ", "diff", "selected", "");%>>Differance</option>
  <option value="refTemp" <%ifResource("monitor.output.anlg1Src", "EQ", "anlgIn", "selected", "");%>>Analog input</option>
  <option value="refTemp" <%ifResource("monitor.output.anlg1Src", "EQ", "intTemp", "selected", "");%>>Internal temp</option>
</select>
<input type="text" size="2" name="monitor.output.anlg1Id" value="<%getResourceValue("monitor.output.anlg1Id");%>">
<select size="1" name="monitor.output.anlg1Res">
  <option value="value" <%ifResource("monitor.output.anlg1Res", "EQ", "value", "selected", "");%>>Value</option>
  <option value="max" <%ifResource("monitor.output.anlg1Res", "EQ", "max", "selected", "");%>>Max</option>
  <option value="min" <%ifResource("monitor.output.anlg1Res", "EQ", "min", "selected", "");%>>Min</option>
  <option value="avg" <%ifResource("monitor.output.anlg1Res", "EQ", "avg", "selected", "");%>>Average</option>
  <option value="iso" <%ifResource("monitor.output.anlg1Res", "EQ", "iso", "selected", "");%>>Coverage</option>
</select><br>
<font face="Tahoma">Analog out 2:</font>
<select size="1" name="monitor.output.anlg2Src">
  <option value="spot" <%ifResource("monitor.output.anlg2Src", "EQ", "spot", "selected", "");%>>Spot</option>
  <option value="mbox" <%ifResource("monitor.output.anlg2Src", "EQ", "mbox", "selected", "");%>>Box</option>
  <option value="isotherm" <%ifResource("monitor.output.anlg2Src", "EQ", "diff", "selected", "");%>>Differance</option>
  <option value="refTemp" <%ifResource("monitor.output.anlg2Src", "EQ", "anlgIn", "selected", "");%>>Analog input</option>
  <option value="refTemp" <%ifResource("monitor.output.anlg2Src", "EQ", "intTemp", "selected", "");%>>Internal temp</option>
</select>
<input type="text" size="2" name="monitor.output.anlg2Id" value="<%getResourceValue("monitor.output.anlg2Id");%>">
<select size="1" name="monitor.output.anlg2Res">
  <option value="value" <%ifResource("monitor.output.anlg2Res", "EQ", "value", "selected", "");%>>Value</option>
  <option value="max" <%ifResource("monitor.output.anlg2Res", "EQ", "max", "selected", "");%>>Max</option>
  <option value="min" <%ifResource("monitor.output.anlg2Res", "EQ", "min", "selected", "");%>>Min</option>
  <option value="avg" <%ifResource("monitor.output.anlg2Res", "EQ", "avg", "selected", "");%>>Average</option>
  <option value="iso" <%ifResource("monitor.output.anlg2Res", "EQ", "iso", "selected", "");%>>Coverage</option>
</select><br>
<input type="hidden" name="system.autosync" value="2">
<input type="submit" value="Update settings">
</form>
      </td>
    </tr>
  </table>
</body>
</html>