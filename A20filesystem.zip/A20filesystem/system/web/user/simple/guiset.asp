<html>
<head>
<title>Camera user web</title>
</head>
<body background="/user/bkg.gif" bgColor="moccasin">
  <table width="100%">
    <tr>
<!-- head  -->
      <td width="220px">
        <a href="/index.asp"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
      </td>
      <td>
        <center><font size="400%" face="Century gothic"><a href="/user/simple/index.asp"><%getResourceValue("version.product.name");%></a></font></center>
      </td>
    </tr>
    <tr>
      <td vAlign="top">
<!-- menu  -->
<div>
<font face="Century gothic"><b>Image</b></font><br>
<font face="Tahoma">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
}

if (showMeasure == "false" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
}
%>
&nbsp;<a href="/user/simple/imgparams.asp">Image settings</a><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("&nbsp;<a href='/user/simple/objpar.asp'>Object parameters</a><br>\n");
%>
</font>
</div>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showLine    = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showLine == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<br><div><font face='Century gothic'><b>Measurments</b></font><br><font face='Tahoma'>\n");
    if (showSpot == "true")
      write("&nbsp;<a href='/user/simple/spot/spot.asp'>Spots</a><br>\n");
    if (showBox == "true")
      write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
    if (showLine == "true")
      write("&nbsp;<a href='/user/simple/line/line.asp'>Lines</a><br>\n");
    if (showDiff == "true")
      write("&nbsp;<a href='/user/simple/diff/diff.asp'>Diffs</a><br>\n");
    if (showIso == "true")
      write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
    write("</font></div>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<br><div><font face='Century gothic'><b>Alarm and logging</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/alarm/alm.asp'>Alarms</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/batch.asp'>Batch settings</a><br>");
    write("&nbsp;<a href='/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true'>Alarm log</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/logactions.asp'>Log settings</a><br></font></div>");
    write("<br><div><font face='Century gothic'><b>Camera ports</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/camout.asp'>Camera outputs</a><br>");
    write("&nbsp;<a href='/user/simple/anlport.asp'>Analog ports</a><br>");
    write("&nbsp;<a href='/user/simple/testout.asp'>Test I/O ports</a><br></font></div>");
  }
%>
<br>
<div>
<font face="Century gothic"><b>General settings</b></font><br>
<font face="Tahoma">
  &nbsp;<a href="/user/simple/locale.asp">Local settings</span></a><br>
  &nbsp;<a href="/user/simple/guiset.asp">Camera user interface</a><br>
  &nbsp;<a href="/user/simple/sysset.asp">System settings</a><br>
  &nbsp;<a href="/user/simple/sysstat.asp">System information</a><br>
  &nbsp;<a href="/user/simple/camControl.asp">Camera control</a><br>
</font>
</div>
      </td>
      <td vAlign="top">
<!-- body -->
<font face="Century gothic" size="5"><b>Camera user interface settings</b></font><br>
<form name="logSet" ACTION="/goform/setResourceValues" METHOD="POST">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/guiset.asp">
<input type="hidden" name="checkboxdescr" value="graphMode:gui.system.hideGraphics|true:gui.system.hideGraphics|false">
<input type="checkbox" name="checkbox.graphMode" value="true" <%ifResource( "gui.system.hideGraphics", "EQ", "true", "checked", "" );%>>
<font face="Tahoma"><b>Hide graphics</b></font><br>
<br>
<font face="Tahoma"><b>Components</b></font><br>
<input type="hidden" name="checkboxdescr" value="label:gui.marker.text.0.state|SHOW:gui.marker.text.0.state|HIDE">
<input type="checkbox" name="checkbox.label" value="true" <%ifResource( "gui.marker.text.0.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Label</font><br>
<input type="hidden" name="checkboxdescr" value="logo:gui.marker.icon.0.state|SHOW:gui.marker.icon.0.state|HIDE">
<input type="checkbox" name="checkbox.logo" value="true" <%ifResource( "gui.marker.icon.0.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Logo</font><br>
<input type="hidden" name="checkboxdescr" value="scale:gui.status.scale.state|SHOW:gui.status.scale.state|HIDE">
<input type="checkbox" name="checkbox.scale" value="true" <%ifResource( "gui.status.scale.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Scale</font><br>
<input type="hidden" name="checkboxdescr" value="bar:gui.status.bar.state|SHOW:gui.status.bar.state|HIDE">
<input type="checkbox" name="checkbox.bar" value="true" <%ifResource( "gui.status.bar.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Infobar</font><br>
<br>
<font face="Tahoma"><b>Infobar</b></font><br>
<input type="hidden" name="checkboxdescr" value="dt:gui.status.clock.state|SHOW:gui.status.clock.state|HIDE">
<input type="checkbox" name="checkbox.dt" value="true" <%ifResource( "gui.status.clock.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Date/Time</font><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<input type='hidden' name='checkboxdescr' value='emiss:gui.status.emissFact.state|SHOW:gui.status.emissFact.state|HIDE'><input type='checkbox' name='checkbox.emiss' value='true'");
  ifResource( "gui.status.emissFact.state", "EQ", "SHOW", "checked", "" );
  write("><font face='Tahoma'>Emissivity</font><br><input type='hidden' name='checkboxdescr' value='obd:gui.status.objDist.state|SHOW:gui.status.objDist.state|HIDE'>");
  write("<input type='checkbox' name='checkbox.obd' value='true'");
  ifResource( "gui.status.objDist.state", "EQ", "SHOW", " checked", "" );
  write("><font face='Tahoma'>Object distance</font><br><input type='hidden' name='checkboxdescr' value='tamb:gui.status.tAmbient.state|SHOW:gui.status.tAmbient.state|HIDE'>");
  write("<input type='checkbox' name='checkbox.tamb' value='true'");
  ifResource( "gui.status.tAmbient.state", "EQ", "SHOW", " checked", "" );
  write("><font face='Tahoma'>Reflected temperature</font><br><input type='hidden' name='checkboxdescr' value='tatm:gui.status.tAtm.state|SHOW:gui.status.tAtm.state|HIDE'>");
  write("<input type='checkbox' name='checkbox.tatm' value='true'");
  ifResource( "gui.status.tAtm.state", "EQ", "SHOW", " checked", "" );
  write("><font face='Tahoma'>Atmospheric temperature</font><br><input type='hidden' name='checkboxdescr' value='rhum:gui.status.relHum.state|SHOW:gui.status.relHum.state|HIDE'>");
  write("<input type='checkbox' name='checkbox.rhum' value='true'");
  ifResource( "gui.status.relHum.state", "EQ", "SHOW", " checked", "" );
  write("><font face='Tahoma'>Relative humidity</font><br>");
}
%>
<input type="hidden" name="checkboxdescr" value="range:gui.status.case.state|SHOW:gui.status.case.state|HIDE">
<input type="checkbox" name="checkbox.range" value="true" <%ifResource( "gui.status.case.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Range</font><br>
<input type="hidden" name="checkboxdescr" value="linf:gui.status.lensInfo.state|SHOW:gui.status.lensInfo.state|HIDE">
<input type="checkbox" name="checkbox.linf" value="true" <%ifResource( "gui.status.lensInfo.state", "EQ", "SHOW", "checked", "" );%>>
<font face="Tahoma">Lens information</font><br>
<input type="hidden" name="system.autosync" value="2">
<input type="submit" value="Update settings">
</form>
      </td>
    </tr>
  </table>
</body>
</html>