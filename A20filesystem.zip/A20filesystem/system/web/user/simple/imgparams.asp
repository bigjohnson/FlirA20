<html>
<head>
<title>Camera user web</title>
</head>
<body background="/user/bkg.gif" bgColor="moccasin">
  <table width="100%">
    <tr>
<!-- head  -->
      <td width="220px">
        <a href="/index.asp"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
      </td>
      <td>
        <center><font size="400%" face="Century gothic"><a href="/user/simple/index.asp"><%getResourceValue("version.product.name");%></a></font></center>
      </td>
    </tr>
    <tr>
      <td vAlign="top">
<!-- menu  -->
<div>
<font face="Century gothic"><b>Image</b></font><br>
<font face="Tahoma">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
}

if (showMeasure == "false" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
}
%>
&nbsp;<a href="/user/simple/imgparams.asp">Image settings</a><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("&nbsp;<a href='/user/simple/objpar.asp'>Object parameters</a><br>\n");
%>
</font>
</div>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showLine    = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showLine == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<br><div><font face='Century gothic'><b>Measurments</b></font><br><font face='Tahoma'>\n");
    if (showSpot == "true")
      write("&nbsp;<a href='/user/simple/spot/spot.asp'>Spots</a><br>\n");
    if (showBox == "true")
      write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
    if (showLine == "true")
      write("&nbsp;<a href='/user/simple/line/line.asp'>Lines</a><br>\n");
    if (showDiff == "true")
      write("&nbsp;<a href='/user/simple/diff/diff.asp'>Diffs</a><br>\n");
    if (showIso == "true")
      write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
    write("</font></div>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<br><div><font face='Century gothic'><b>Alarm and logging</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/alarm/alm.asp'>Alarms</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/batch.asp'>Batch settings</a><br>");
    write("&nbsp;<a href='/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true'>Alarm log</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/logactions.asp'>Log settings</a><br></font></div>");
    write("<br><div><font face='Century gothic'><b>Camera ports</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/camout.asp'>Camera outputs</a><br>");
    write("&nbsp;<a href='/user/simple/anlport.asp'>Analog ports</a><br>");
    write("&nbsp;<a href='/user/simple/testout.asp'>Test I/O ports</a><br></font></div>");
  }
%>
<br>
<div>
<font face="Century gothic"><b>General settings</b></font><br>
<font face="Tahoma">
  &nbsp;<a href="/user/simple/locale.asp">Local settings</span></a><br>
  &nbsp;<a href="/user/simple/guiset.asp">Camera user interface</a><br>
  &nbsp;<a href="/user/simple/sysset.asp">System settings</a><br>
  &nbsp;<a href="/user/simple/sysstat.asp">System information</a><br>
  &nbsp;<a href="/user/simple/camControl.asp">Camera control</a><br>
</font>
</div>
      </td>
      <td vAlign="top">
<!-- body -->
<FORM METHOD="post" name="imgForm" ACTION="/goform/setResourceValues">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/simple/imgparams.asp">
<table>
  <tr>
    <th colspan="2">
      <font face="Century gothic" size="5"><b>Image settings</b></font>
    </th>
  </tr>
  <tr>
    <td colspan="2">
      <font face="Tahoma"><b>Presentation</b></font>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font  face="Tahoma">Adjust:</font>
    </td>
    <td>
        &nbsp;
        <select size="1" name="image.adj.auto.cont">
          <option value="true" <%ifResource("image.adj.auto.cont", "EQ", "true", "selected", "");%>>Auto</option>
          <option value="false" <%ifResource("image.adj.auto.cont", "EQ", "false", "selected", "");%>>Manual</option>
        </select>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Method:</font>
    </td>
    <td>
        &nbsp;
        <select name="image.adj.auto.mode">
          <option value="level" <%ifResource("image.adj.auto.mode", "EQ", "level", "selected", "");%>>Brightness</option>
          <option value="levelSpan" <%ifResource("image.adj.auto.mode", "EQ", "levelSpan", "selected", "");%>>Contrast/Brightness</option>
          <option value="histogram" <%ifResource("image.adj.auto.mode", "EQ", "histogram", "selected", "");%>>Histogram</option>
        </select>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Palette:</font>
    </td>
    <td>
        &nbsp;
        <select size="1" name="image.adj.palette.filename">
          <option value="bw.pal" <%ifResource("image.adj.palette.filename", "EQ", "bw.pal", "selected", "");%>>Gray (white hot)</option>
          <option value="bwr.pal" <%ifResource("image.adj.palette.filename", "EQ", "bwr.pal", "selected", "");%>>Gray (black hot)</option>
          <option value="iron.pal" <%ifResource("image.adj.palette.filename", "EQ", "iron.pal", "selected", "");%>>Iron</option>
          <option value="rainHC.pal" <%ifResource("image.adj.palette.filename", "EQ", "rainHC.pal", "selected", "");%>>Rainbow HC</option>
          <option value="rainbow.pal" <%ifResource("image.adj.palette.filename", "EQ", "rainbow.pal", "selected", "");%>>Rainbow</option>
        </select>
    </td>
  </tr>
  <tr>
    <td colspan="2">
<font face="Tahoma">
<%
ifResource("config.measure.tempOK", "EQ", "true", "<b>Temperature scale</b>", "<b>Scale</b>");
%>
</font>
    </td>
  </tr>
  <tr>
    <td colspan="2">
<font face="Tahoma">
      <input type="hidden" name="checkboxdescr" value="fLinear:image.adj.forceLinear|true:image.adj.forceLinear|false">
      <input type="checkbox" name="checkbox.fLinear" value="true" <%ifResource("image.adj.forceLinear", "EQ", "true", "checked", "");%>>Force linear
</font>
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<tr><td>&nbsp;<font face='Tahoma'>High value:</font></td><td>&nbsp;<input type='text' name='TEMPERATURE.image.adj.highT' value='");
  getTemperatureValue("image.adj.highT", "%0.1f");
  write("'>");
  getTempUnit();
  write("</td></tr>");
  write("<tr><td>&nbsp;<font face='Tahoma'>Low value:</font></td><td>&nbsp;<input type='text' name='TEMPERATURE.image.adj.lowT' value='");
  getTemperatureValue("image.adj.lowT", "%0.1f");
  write("'>");
  getTempUnit();
  write("</td></tr>");
  write("<tr>\n<td>&nbsp;<font face='Tahoma'>Lock to</font></td>\n<td>\n&nbsp;<select size='1' name='image.adj.latchMode'>");
  write("<option value='pixel' ");
  ifResource("", "EQ", "pixel", "selected", "");
  write(">Signal</option><option value='temp'");
  ifResource("", "EQ", "temp", "selected", "");
  write(">Temperature</option></select>\n</td>\n</tr>\n");
}
%>
  <tr>
    <td>
<font face="Tahoma">At reboot</font>
    </td>
    <td>
        &nbsp;
        <select size="1" name="system.dsoverride">
           <option value="true" <%ifResource("system.dsoverride", "EQ", "true", "selected", "");%>>Reinit range</option>
           <option value="false" <%ifResource("system.dsoverride", "EQ", "false", "selected", "");%>>Keep range</option>
        </select><br><br>
    </td>
 </tr>
  <tr>
    <td colspan="2">
        <br><input type="submit" value="Update settings">
    </td>
  </tr>
</table>
<input type="hidden" name="system.autosync" value="2">
</form>
      </td>
    </tr>
  </table>
</body>
</html>