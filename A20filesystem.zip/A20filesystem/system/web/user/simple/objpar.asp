<html>
<head>
<title>Camera user web</title>
</head>
<body background="/user/bkg.gif" bgColor="moccasin">
  <table width="100%">
    <tr>
<!-- head  -->
      <td width="220px">
        <a href="/index.asp"><img border="0" src="/flirtrans.gif" width="204" height="74"><a>
      </td>
      <td>
        <center><font size="400%" face="Century gothic"><a href="/user/simple/index.asp"><%getResourceValue("version.product.name");%></a></font></center>
      </td>
    </tr>
    <tr>
      <td vAlign="top">
<!-- menu  -->
<div>
<font face="Century gothic"><b>Image</b></font><br>
<font face="Tahoma">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var isoNum     = getResourceValue("config.measure.isotherm.maxnum", "false");
if (showMeasure == "false" && showBox == "true" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
}

if (showMeasure == "false" && isoNum != 0)
{
  write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
}
%>
&nbsp;<a href="/user/simple/imgparams.asp">Image settings</a><br>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
  write("&nbsp;<a href='/user/simple/objpar.asp'>Object parameters</a><br>\n");
%>
</font>
</div>

<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var showSpot    = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var showBox     = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var showLine    = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var showDiff    = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var showIso     = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((showSpot == "true") || (showBox == "true") || (showLine == "true") || (showDiff == "true") || (showIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
if (showMeasure == "true")
  {
    write("<br><div><font face='Century gothic'><b>Measurments</b></font><br><font face='Tahoma'>\n");
    if (showSpot == "true")
      write("&nbsp;<a href='/user/simple/spot/spot.asp'>Spots</a><br>\n");
    if (showBox == "true")
      write("&nbsp;<a href='/user/simple/box/mbox.asp'>Boxes</a><br>\n");
    if (showLine == "true")
      write("&nbsp;<a href='/user/simple/line/line.asp'>Lines</a><br>\n");
    if (showDiff == "true")
      write("&nbsp;<a href='/user/simple/diff/diff.asp'>Diffs</a><br>\n");
    if (showIso == "true")
      write("&nbsp;<a href='/user/simple/iso/iso.asp'>Isotherms</a><br>\n");
    write("</font></div>\n");
  }
%>
<%
  var haveIO = ifResource("config.system.ioports", "EQ", "true");
  if (haveIO == "true")
  {
    write("<br><div><font face='Century gothic'><b>Alarm and logging</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/alarm/alm.asp'>Alarms</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/batch.asp'>Batch settings</a><br>");
    write("&nbsp;<a href='/goform/setResourceValues?redirect=/user/alarm/getLog.asp&monitor.log.file=28.0/system/web/tmp/alarmlog.txt&monitor.log.commit=true'>Alarm log</a><br>");
    write("&nbsp;<a href='/user/simple/alarm/logactions.asp'>Log settings</a><br></font></div>");
    write("<br><div><font face='Century gothic'><b>Camera ports</b></font><br><font face='Tahoma'>\n");
    write("&nbsp;<a href='/user/simple/camout.asp'>Camera outputs</a><br>");
    write("&nbsp;<a href='/user/simple/anlport.asp'>Analog ports</a><br>");
    write("&nbsp;<a href='/user/simple/testout.asp'>Test I/O ports</a><br></font></div>");
  }
%>
<br>
<div>
<font face="Century gothic"><b>General settings</b></font><br>
<font face="Tahoma">
  &nbsp;<a href="/user/simple/locale.asp">Local settings</span></a><br>
  &nbsp;<a href="/user/simple/guiset.asp">Camera user interface</a><br>
  &nbsp;<a href="/user/simple/sysset.asp">System settings</a><br>
  &nbsp;<a href="/user/simple/sysstat.asp">System information</a><br>
  &nbsp;<a href="/user/simple/camControl.asp">Camera control</a><br>
</font>
</div>
      </td>
      <td vAlign="top">
<!-- body -->
<form METHOD="post" ACTION="/goform/setResourceValues">
<input TYPE="hidden" NAME="redirect" VALUE="/user/simple/objpar.asp">
<table>
  <tr>
    <th colspan="2">
      <font face="Century gothic" size="5"><b>Object parameters</b></font>
    </th>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Emissivity:</font>
    </td>
    <td>
        <input type="text" name="image.objpar.emissivity" value="<%getResourceValue( "image.objpar.emissivity", "%0.2f" );%>">
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Object distance:</font>
    </td>
    <td>
        <input type="text" name="DISTANCE.image.objpar.distance" value="<%getDistanceValue( "image.objpar.distance" );%>"><font face="Tahoma"><%getDistUnit();%></font>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Reflected temperature:</font>
    </td>
    <td>
        <input type="text" name="TEMPERATURE.image.objpar.ambTemp" value="<%getTemperatureValue( "image.objpar.ambTemp" );%>"><%getTempUnit();%>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Atmpsperic temperature:</font>
    </td>
    <td>
        <input type="text" name="TEMPERATURE.image.objpar.atmTemp" value="<%getTemperatureValue( "image.objpar.atmTemp" );%>"><%getTempUnit();%>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Relative humidity:</font>
    </td>
    <td>
        <input type="text" name="image.objpar.relHum" value="<%getResourceValue( "image.objpar.relHum", "%0.2f" );%>">
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Ext. optics transm.:</font>
    </td>
    <td>
        <input type="text" name="image.objpar.extOptTrans" value="<%getResourceValue( "image.objpar.extOptTrans", "%0.2f" );%>">
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Ext. optics source</font>
    </td>
    <td>
        <span id="obp_selsrc">
          <select size="1" name="monitor.input.extOptTemp" style="visibility:hidden;" >
            <option value="none" <%ifResource("monitor.input.extOptTemp", "EQ", "none", "selected", "");%>>Value</option>
            <option value="anlgIn" <%ifResource("monitor.input.extOptTemp", "EQ", "anlgIn", "selected", "");%>>Analog in</option>
            <option value="intTemp" <%ifResource("monitor.input.extOptTemp", "EQ", "intTemp", "selected", "");%>>Int. temp.</option>
          </select>
        </span>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Ext. optics temp.:</font>
    </td>
    <td class="tdr">
        <input type="text" name="TEMPERATURE.image.objpar.extOptTemp" value="<%getTemperatureValue( "image.objpar.extOptTemp", "%0.1f" );%>"><%getTempUnit();%>
        <br><br>
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;<font face="Tahoma">Reference temp:</font>
    </td>
    <td>
        <input type="text" name="TEMPERATURE.image.mfunc.reftemp.1.valueT" value="<%getTemperatureValue( "image.mfunc.reftemp.1.valueT", "%0.1f" );%>"><%getTempUnit();%>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <br>
        <input type="submit" value="Update settings">
    </td>
  </tr>
</table>
<input type="hidden" name="system.autosync" value="2">
</form>
      </td>
    </tr>
  </table>
</body>
</html>