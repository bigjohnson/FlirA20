<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Spot settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/multiple.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
<!--
function fixParMasks(obj)
{
  var frmNameArr = obj.name.split(".");
  var frmNum = "1";
  if (frmNameArr.length == 2)
    frmNum = frmNameArr[1];
  var locset = obj.elements["locset." + frmNum];
  var lbl = obj.elements["showLabel." + frmNum];
  var active = obj.elements["checkbox.actspot." + frmNum];
  var target = obj.elements["image.mfunc.spot." + frmNum + ".parMask"];
  var mask = 0;
  locset.checked == true && active.checked == true ? mask |= 0x07 : mask &= ~0x07;
  lbl.checked == true && active.checked == true ? mask |= 0x040 : mask &= ~0x040;
  target.value = mask;
return validate(obj);
}
-->
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table>
<%includeFile("/user/spot/spot.inc", "config.measure.spot.maxnum");%>
</table>
</body>
</html>
