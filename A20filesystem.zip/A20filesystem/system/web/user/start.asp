<html>
<head>
<title>Start image</title>
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script>
function setCamImg()
{
  var camString = new String("<%getResourceValue("version.product.article");%>");
  var camName = camString.slice(0, 3);
  var imgRef = window.document.images['camImg'];
  if (imgRef == null)
      return;
  if (camName == "236")
  {
      imgRef.src = "/A40.gif";
  }
  else if (camName == "227")
  {
      imgRef.src = "/camera.gif";
  }
  else
  {
      imgRef.src = "/camera.gif";
  }
}
</script>
</head>

<body background="bkg.gif" onLoad="setCamImg();"><!--bgcolor="#F8F9D9">-->

<table border="0" width="100%" height="100%" align="center" valign="middle">
  <tr>
    <td width="100%" height="100%" align="center" valign="middle">
      <img border='0' id="camImg">
    </td>
  </tr>
</table>
</body>
</html>
