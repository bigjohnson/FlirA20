<HTML>
<HEAD>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Status table</title>
<meta http-equiv="pragma" content="no-cache">
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
function reloadDoc()
{
  window.location = '/user/empty.html?redirect=' + document.URL;
}
<%
var shallReload = ifResource("system.web.statusDelay", "NEQ", "0");
if (shallReload == "true")
{
  write("var reloadDelay = new Number(1000);reloadDelay *= ");
  getResourceValue("system.web.statusDelay");
  write(";var reloadTimer = setTimeout('reloadDoc()', reloadDelay );");
}
%>
</script>
</HEAD>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<span id="stat_content" style="visibility:hidden;">
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<TABLE style='width:660px;'>");
}
else
{
  write("<TABLE style='width:300px;'>");
}
%>
    <tr>
      <td class="tdlStat" style="width:80px;">
        <span id="stat_range"></span>
      </td>
      <td class="tdrStat" style="width:220px">
        <%getTemperatureValue( "image.status.tmin", "%0.0f" );%>&nbsp;-&nbsp;
        <%getTemperatureValue( "image.status.tmax", "%0.0f" );%>&nbsp;
        <span id="stat_tunit"></span>
<%
if (showMeasure == "true")
{
  write("</td><td class='tdlStat' style='width:100px;'><span id='stat_dist'></span></td><td class='tdrStat' style='width:100px'>");
  getDistanceValue( "image.objpar.distance" );write("&nbsp;<span id='stat_dunit'></span>");
  write("</td><td class='tdlStat' style='width:80px;'><span id='stat_emis'></span></td><td class='tdrStat' style='width:80px'>");
  getResourceValue( "image.objpar.emissivity", "%0.2f" );
}
%>
      </td>
    </tr>
    <tr>
      <td class="tdlStat" style="width:80px;">
        <span id="stat_date"></span>
      </td>
      <td class="tdrStat" style="width:220px">
        <%showDate("image.status.imgtime" );%>&nbsp;<%showTime("image.status.imgtime" );%>
<%
if (showMeasure == "true")
{
  write("</td><td class='tdlStat' style='width:100px;'><span id='stat_high'></span></td><td class='tdrStat' style='width:100px'>");
  getTemperatureValue( "image.adj.highT", "%0.1f" );write("<span id='stat_tunit'></span>");
  write("</td><td class='tdlStat' style='width:80px;'><span id='stat_low'></span></td><td class='tdrStat' style='width:80px'>");
  getTemperatureValue( "image.adj.lowT", "%0.1f" );write("<span id='stat_tunit'></span>");
}
%>
      </td>
    </tr>
</TABLE>
</span>
</BODY>
</HTML>