<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>System Settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
<script>
<!--
function setupHidden(frm)
{
  var objYear = document.forms['dtForm'].elements['system.time.year'];
  var objHour = document.forms['dtForm'].elements['system.time.hour'];
  if (objYear != null)
  {
    if (objYear.type == 'hidden')
    {
      var YY = Number(document.forms['dtForm'].elements['year'].value);
      var sYY = "" + YY;
      if (YY < 10)
        sYY = "200" + sYY;
      else
        sYY = 20 + sYY;
      objYear.value = sYY;
    }
  }
  if (objHour != null)
  {
    if (objHour.type == 'hidden')
    {
      hh = document.forms['dtForm'].elements['hour'].value;
      
      if (document.forms['dtForm'].elements['AmPm'].selectedIndex == 1)// Pm
      {
        if (hh != 12)// 12 Pm => 12
          hh += 12;
      }
      else if (hh == 12)// 12 Am => 0
        hh = 0;
      objHour.value = hh;
    }
  }
  return validate(frm);
}
-->
</script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<table>
  <tr>
    <th colspan="2">
      <span id="sset_sset" style="visibility:hidden;"></span>
    </th>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <span id="sset_dt" style="visibility:hidden;"></span>
    </td>
  </tr>
  <FORM ACTION=/goform/setResourceValues METHOD=POST name="dtForm" onSubmit="return setupHidden(this);">
  <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/sysset.asp">
  <tr>
    <td class="tdl">
          &nbsp;<span id="sset_date" style="visibility:hidden;"></span>
    </td>
    <td class="tdr" id="td1" style="visibility:hidden;">
<%
  var dateFormat = getResourceValue("gui.local.dateFormat", "false");
  if (dateFormat == "SI4" || dateFormat == "SI2")
  {
    if (dateFormat == "SI4")
    {
      write("<input type='hidden' name='minYear' value='1979'><input type='hidden' name='maxYear' value='2037'>");
      write("<input type='text' class='textMedium' name='system.time.year' value='");
      getResourceValue("system.time.year");
    }
    else
    {
      write("<input type='hidden' name='minYear' value='0'><input type='hidden' name='maxYear' value='37'>");
      write("<input type='hidden' name='system.time.year' value='");
      getResourceValue("system.time.year");
      write("'><input type='text' class='textSmall' name='year' value='");
    }
    write("' style='visibility:hidden;'>-<input type='text' class='textSmall' name='system.time.month' value='");
    getResourceValue("system.time.month");
    write("' style='visibility:hidden;'>-<input type='text' class='textSmall' name='system.time.day' value='");
    getResourceValue("system.time.day");
    write("' style='visibility:hidden;'>");
    
  }
  else if (dateFormat == "European")
  {
    write("<input type='hidden' name='minYear' value='0'><input type='hidden' name='maxYear' value='37'>");
    write("<input type='hidden' name='system.time.year' value='");
    getResourceValue("system.time.year");
    write("'><input type='text' class='textSmall' name='system.time.month' value='");
    getResourceValue("system.time.month");
    write("' style='visibility:hidden;'>/<input type='text' class='textSmall' name='system.time.day' value='");
    getResourceValue("system.time.day");
    write("' style='visibility:hidden;'>/<input type='text' class='textSmall' name='year' value='' style='visibility:hidden;'>");
  }
  else
  {
    write("<input type='hidden' name='minYear' value='0'><input type='hidden' name='maxYear' value='37'>");
    write("<input type='hidden' name='system.time.year' value='");
    getResourceValue("system.time.year");
    write("'><input type='text' class='textSmall' name='system.time.day' value='");
    getResourceValue("system.time.day");
    write("' style='visibility:hidden;'>/<input type='text' class='textSmall' name='system.time.month' value='");
    getResourceValue("system.time.month");
    write("' style='visibility:hidden;'>/<input type='text' class='textSmall' name='year' value='' style='visibility:hidden;'>");
  }
%>
<input type="hidden" name="minMonth" value="1">
<input type="hidden" name="maxMonth" value="12">
<input type="hidden" name="minDay" value="1">
<input type="hidden" name="maxDay" value="31">
<input type="hidden" name="minMin" value="0">
<input type="hidden" name="maxMin" value="59">
<input type="hidden" name="minSec" value="0">
<input type="hidden" name="maxSec" value="59">
    </td>
  </tr>
  <tr>
    <td class="tdl">
          &nbsp;<span id="sset_time" style="visibility:hidden;"></span>
    </td>
    <td class="tdr" style="visibility:hidden;" id="td2">
<%
  var timeFormat = getResourceValue("gui.local.timeFormat", "false");
  if (timeFormat == "24hour")
  {
    write("<input type='hidden' name='minHour' value='0'><input type='hidden' name='maxHour' value='23'>");
    write("<input type='text' class='textSmall' name='system.time.hour' value='");
    getResourceValue("system.time.hour");
    write("' style='visibility:hidden;'>:<input type='text' class='textSmall' name='system.time.min' value='");
    getResourceValue("system.time.min");
    write("' style='visibility:hidden;'>:<input type='text' class='textSmall' name='system.time.sec' value='");
    getResourceValue("system.time.sec");
    write("' style='visibility:hidden;'>");
  }
  else
  {
    write("<input type='hidden' name='minHour' value='1'><input type='hidden' name='maxHour' value='12'>");
    write("<input type='hidden' name='system.time.hour' value='");
    getResourceValue("system.time.hour");
    write("'><input type='text' class='textSmall' name='hour' value='' style='visibility:hidden;'><select size='1' class='selSmall' name='AmPm' style='visibility:hidden;'></select>:");
    write("<input type='text' class='textSmall' name='system.time.min' value='");
    getResourceValue("system.time.min");
    write("' style='visibility:hidden;'>:<input type='text' class='textSmall' name='system.time.sec' value='");
    getResourceValue("system.time.sec");
    write("' style='visibility:hidden;'>");
  }
%>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
        <br>
        <INPUT TYPE="hidden" NAME="system.time.control" VALUE="2">
        <input type="submit" value="" name="sset_submit" class="update" style='visibility:hidden;'>
        <input type="hidden" name="system.autosync" value="2">
        <br><br>
    </td>
  </tr>
  </form>
  <tr>
    <td class="tdt" colspan="2">
      <span id="sset_misc" style="visibility:hidden;"></span>
    </td>
  </tr>
  <FORM ACTION=/goform/setResourceValues METHOD=POST>
  <INPUT TYPE="hidden" NAME="redirect" VALUE="/user/sysset.asp">
  <tr>
    <td class="tdl">
      &nbsp;<span id="sset_trange" style="visibility:hidden;"></span>
    </td>
    <td class="tdr">
        &nbsp;<span  id="setcase" style="visibility:hidden;"><%caseSelectTag( "SETCASE.noforce" );%></span>
    </td>
  </tr>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
if (showMeasure == "true")
{
  write("<input type='hidden' name='mperiodSel' value='");
  getResourceValue("image.mfunc.mperiod");
  write("'><tr><td class='tdl'>&nbsp;<span id='sset_meas' style='visibility:hidden;'></span></td><td class='tdr'>&nbsp;<select size='1' name='image.mfunc.mperiod' style='visibility:hidden;'>");
  write("</select></td></tr>");
}
var showIO = ifResource("config.system.ioports", "EQ", "true");
if (showIO == "true")
{
  write("<input type='hidden' name='bidirSel' value='");
  getResourceValue("system.ioports.digbidir_out");
  write("'><tr><td class='tdl'>&nbsp;<span id='sset_bidir' style='visibility:hidden;'></span></td><td class='tdr'>&nbsp;<select size='1' name='system.ioports.digbidir_out' style='visibility:hidden;'>");
  write("</select></td></tr>");
}
%>
  <tr>
    <td class="tdt" colspan="2">
        <br>
        <%ifResource("system.autosync", "EQ", "true", "", "<input type=\"hidden\" name=\"system.autosync\" value=\"false\">");%>
        <input type="submit" value="" name="sset_submit2" class="update" style='visibility:hidden;'>
    </td>
  </tr>
  </form>
</table>
</body>
</html>