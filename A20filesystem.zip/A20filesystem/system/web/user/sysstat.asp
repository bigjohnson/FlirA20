<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>System information</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
  <table class="tableStat">
    <tr>
      <th colspan="2">
        <span id="syinf_syinf"></span>
      </th>
    </tr>
    <tr>
      <td class='tdt' colspan="2" style='padding-left:8px;'>
        <span id="syinf_proinf"></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_ctype"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_ctyperes" style="visibility:hidden;"><%getResourceValue( "version.product.name" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_pcode"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_pcoderes" style="visibility:hidden;"><%getResourceValue( "version.product.article" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_sno"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_snores" style="visibility:hidden;"><%getResourceValue( "version.product.serial" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_mandt"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_mandtres" style="visibility:hidden;"><%getResourceValue( "version.product.date" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdt colspan="2"' style='padding-left:8px;'>
        <span id="syinf_swver"></span>
      </td>
    </tr>
    <tr>
      <td>
        <span id="syinf_swinc" style="visibility:hidden;">
          <table>
            <%includeFile("/user/sw.inc", "version.swHighNum", "0");%>
          </table>
        </span>
      </td>
    <tr>
      <td class='tdt' colspan="2" style='padding-left:8px;'>
        <span id="syinf_hwidrev"></span>
      </td>
    <tr>
    <tr>
      <td>
        <span id="syinf_hwinc" style="visibility:hidden;">
          <table>
            <%includeFile("/user/hw.inc", "version.hwHighNum", "0");%>
          </table>
        </span>
      </td>
    </tr>
      <td class='tdt' colspan="2" style='padding-left:8px;'>
        <span id="syinf_systat"></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_fwri"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_fwrires" style="visibility:hidden;"><%getResourceValue( "system.statistics.flashWrite" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_mitemp"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_mitempres" style="visibility:hidden;"><%getResourceValue( "system.statistics.minTemp" );getTempUnit();%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_matemp"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_matempres" style="visibility:hidden;"><%getResourceValue( "system.statistics.maxTemp" );getTempUnit();%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_initt"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_inittres" style="visibility:hidden;"><%showDate( "system.statistics.init" );%>&nbsp;&nbsp;<%showTime( "system.statistics.init" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_runt"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_runtres" style="visibility:hidden;"><%formatSeconds( "system.statistics.runtime" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_sups"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_supsres" style="visibility:hidden;"><%getResourceValue( "system.statistics.startUp" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_upt"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_uptres" style="visibility:hidden;"><%formatSeconds( "system.statistics.uptime" );%></span>
      </td>
    </tr>
    <tr>
      <td class='tdlStat'>
        <span id="syinf_shop"></span>
      </td>
      <td class='tdrStat'>
        <span id="syinf_shopres" style="visibility:hidden;"><%getResourceValue( "system.statistics.shutter" );%></span>
      </td>
    </tr>
  </table>
</body>