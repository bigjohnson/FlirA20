<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Test camera outputs</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<script>
function Load()
{
  var frm = document.forms['tp'];
  var anlg1 = frm.elements['system.ioports.anlgout1S'].value;
  var anlg1Rel = anlg1 * 100;
  anlg1Rel = anlg1Rel / 255;
  var str1 = "" + anlg1Rel;
  var valArr1 = str1.split(".");
  frm.elements['anlg1'].value = valArr1[0];
  var anlg2 = frm.elements['system.ioports.anlgout2S'].value;
  var anlg2Rel = anlg2 * 100;
  anlg2Rel = anlg2Rel / 255;
  var str2 = "" + anlg2Rel;
  var valArr2 = str2.split(".");
  frm.elements['anlg2'].value = valArr2[0];
  var anlgIn = frm.elements['anlgInS'].value;
  var anlgInRel = anlgIn * 100;
  anlgInRel = anlgInRel / 4095;
  var str3 = "" + anlgInRel;
  var valArr3 = str3.split(".");
  anlgIn.value = valArr3[0];
  setup();
}
function setAnalog(obj)
{
  obj.elements['system.ioports.anlgout1S'].value = (obj.elements['anlg1'].value * 255) / 100 + 1;
  obj.elements['system.ioports.anlgout2S'].value = (obj.elements['anlg2'].value * 255) / 100 + 1;
  return validate(obj);
}
</script>
<body  onLoad="Load();">
<%includeFile("/include/langForm.inc");%>
<FORM name="tp" ACTION=/goform/setResourceValues METHOD=POST onSubmit="return setAnalog(this);">
<INPUT TYPE="hidden" NAME="redirect" VALUE="/user/testout.asp">
<table>
  <tr>
    <th colspan="2">
      <span id="ioto_ioto"></span>
    </th>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <span id="ioto_digin"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="ioto_diginval"></span>
    </td>
    <td class="tdr">
      <input type="hidden" name="diginresS" value="<%getResourceValue("system.ioports.digin1");%>">
      <span class="<%ifResource("system.ioports.digin1", "EQ", "true", "spanRed", "spanGreen");%>" id="ioto_diginres" style="visibility:hidden;"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="ioto_bidirval"></span>
    </td>
    <td class="tdr">
      <input type="hidden" name="digbidirresS" value="<%getResourceValue("system.ioports.digbidir");%>">
      <span class="<%ifResource("system.ioports.digbidir", "EQ", "true", "spanRed", "spanGreen");%>" id="ioto_bidirres" style="visibility:hidden;"></span>
        <br><br>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <span id="ioto_digout"></span>
    </td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
        &nbsp;<input type="hidden" name="checkboxdescr" value="dig1:system.ioports.digout1|true:system.ioports.digout1|false">
        <input type="checkbox" name="checkbox.dig1" value="true" <%ifResource("system.ioports.digout1", "EQ", "true", "checked", "");%> style="visibility:hidden;">
        <span id="ioto_digout1"></span>
    </td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
        &nbsp;<input type="hidden" name="checkboxdescr" value="dig2:system.ioports.digout2|true:system.ioports.digout2|false">
        <input type="checkbox" name="checkbox.dig2" value="true" <%ifResource("system.ioports.digout2", "EQ", "true", "checked", "");%> style="visibility:hidden;">
        <span id="ioto_digout2"></span>
    </td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
        <input type="hidden" name="system.ioports.vsync_inactive" value="true">
        &nbsp;<input type="hidden" name="checkboxdescr" value="digout3:system.ioports.digout3|true:system.ioports.digout3|false">
        <input type="checkbox" name="checkbox.digout3" value="true" <%ifResource("system.ioports.digout3", "EQ", "true", "checked", "");%> style="visibility:hidden;">
        <span id="ioto_digout3"></span>
    </td>
  </tr>
  <tr>
    <td class="tdts" colspan="2">
        &nbsp;<input type="hidden" name="checkboxdescr" value="digb:system.ioports.digbidir|true:system.ioports.digbidir|false">
        <input type="checkbox" name="checkbox.digb" value="true" <%ifResource("system.ioports.digbidir", "EQ", "true", "checked", "");%> <%ifResource("system.ioports.digbidir_out", "EQ", "true", "", "disabled=\"true\"");%> style="visibility:hidden;">
        <span id="ioto_bidir"></span><br><br>
    </td>
  </tr>
  <tr>
    <td class="tdlt">
      <span id="ioto_anlgin"></span>
    </td>
    <td class="tdr">
        <input type="hidden" name="anlgInS" value="<%getResourceValue("system.ioports.anlginS");%>">
        <span id="ioto_anlginres" style="visibility:hidden;"></span>&nbsp;<span id="ioto_perc1" style="visibility:hidden;">%</span>
        <br><br>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <span id="ioto_anlgout"></span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="ioto_anlgout1"></span>
    </td>
    <td class="tdr">
      <input type="hidden" name="system.ioports.anlgout1S" value="<%getResourceValue("system.ioports.anlgout1S");%>">
      <input type="text" size="4" class="textMedium" name="anlg1" value="kalle" style="visibility:hidden;"><span id="ioto_perc2" style="visibility:hidden;">%</span>
    </td>
  </tr>
  <tr>
    <td class="tdl">
      &nbsp;<span id="ioto_anlgout2"></span>
    <td class="tdr">
      <input type="hidden" name="system.ioports.anlgout2S" value="<%getResourceValue("system.ioports.anlgout2S");%>">
      <input type="text" size="4" class="textMedium" name="anlg2" value="" style="visibility:hidden;"><span id="ioto_perc3" style="visibility:hidden;">%</span>
    </td>
  </tr>
  <tr>
    <td class="tdt" colspan="2">
      <br>
      &nbsp;<input type="submit" value="" name="ioto_submit" style="visibility:hidden;" class="update">
    </td>
  </tr>
</table>
</form>
</body>
</html>
