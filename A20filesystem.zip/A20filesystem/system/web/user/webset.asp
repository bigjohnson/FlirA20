<html>
<head>
<%includeFile("/include/textEncoding.inc");%>
<meta http-equiv="pragma" content="no-cache">
<title>Image viewer settings</title>
<link rel="stylesheet" type="text/css" href="/user/tools/common.css">
<link rel="stylesheet" type="text/css" href="/user/tools/settings.css">
<script src="/include/noFrameIn.js" type="text/javascript" language="JavaScript1.3"></script>
<script src="/include/initPage.js" type="text/javascript" language="JavaScript1.5"></script>
</head>
<body onLoad="setup();">
<%includeFile("/include/langForm.inc");%>
<%
var showMeasure = ifResource("config.measure.tempOK", "EQ", "true");
var haveSpot = ifResource("config.measure.spot.maxnum", "NEQ", "0");
var haveBox  = ifResource("config.measure.mbox.maxnum", "NEQ", "0");
var haveLine = ifResource("config.measure.mline.maxnum", "NEQ", "0");
var haveIso  = ifResource("config.measure.isotherm.maxnum", "NEQ", "0");
var haveDiff = ifResource("config.measure.diff.maxnum", "NEQ", "0");
var haveAlm  = ifResource("config.monitor.alarm.maxnum", "NEQ", "0");
if ((showMeasure == "true") && ((haveSpot == "true") || (haveBox == "true") || (haveLine == "true") || (haveDiff == "true") || (haveIso == "true")))
  showMeasure = "true";
else
  showMeasure = "false";
%>
<table>
   <form method="post" action="/goform/setResourceValues" name="webForm" onSubmit="return validate(this);">
   <input type="hidden" name="redirect" value="/user/webset.asp">
   <tr>
      <th>
         <span id="wvs_wvs"></span>
      </th>
   </tr>
   <tr>
      <td class="tdt">
         <span id="wvs_wrdel"></span>
      </td>
   </tr>
   <tr>
     <td class="tdts">
       <table style="width:100%;">
<%
if (showMeasure == "true" || haveAlm == "true")
{
  write("<tr><td class='tdts_nw'><span id='wvs_resdel'></span></td><td class='tdts_nw'><input type='text' name='system.web.restabDelay' class='textStyle' value='");
  getResourceValue("system.web.restabDelay");
  write("' style='visibility:hidden;'>&nbsp;<span id='wvs_sec1'></span></td></tr>");
}
%>
               <tr>
                  <td class="tdts_nw">
                     <span id="wvs_statdel"></span>&nbsp;
                  </td>
                  <td class="tdts_nw">
                     <input type="text" name="system.web.statusDelay" class="textStyle" value="<%getResourceValue("system.web.statusDelay");%>" style="visibility:hidden;">&nbsp;<span id="wvs_sec2"></span>
                  </td>
               </tr>
            </table>
      </td>
   </tr>
<%
if (showMeasure == "true")
{
  var showSpot = ifResource("system.web.showSpot", "EQ", "true");
  var showBox  = ifResource("system.web.showMbox", "EQ", "true");
  var showLine = ifResource("system.web.showLine", "EQ", "true");
  var showIso  = ifResource("system.web.showIso", "EQ", "true");
  var showDiff = ifResource("system.web.showDiff", "EQ", "true");
  var showAlm = ifResource("system.web.showAlarm", "EQ", "true");
  write("<tr>\n<td>&nbsp;</td>\n</tr>\n<tr>\n<td class='tdt'><span id='wvs_cont'></span></td>\n</tr>\n<tr>\n<td class='tdts'>\n<table style='width:100%;'>\n");
  if (haveSpot == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='spot:system.web.showSpot|true:system.web.showSpot|false'>\n");
    write("<input type='checkbox' name='checkbox.spot' value='true' ");
    if (showSpot == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id='wvs_spot'></span>\n</td>\n</tr>\n");
  }
  if (haveBox == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='boxC:system.web.showMbox|true:system.web.showMbox|false'>\n");
    write("<input type='checkbox' name='checkbox.boxC' value='true' ");
    if (showBox == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id = 'wvs_box'></span>\n</td>\n</tr>\n");
  }
  if (haveLine == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='line:system.web.showLine|true:system.web.showLine|false'>\n");
    write("<input type='checkbox' name='checkbox.line' value='true' ");
    if (showLine == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id='wvs_line'></span>\n</td>\n</tr>\n");
  }
  if (haveIso == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='iso:system.web.showIso|true:system.web.showIso|false'>\n");
    write("<input type='checkbox' name='checkbox.iso' value='true' ");
    if (showIso == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id='wvs_iso'></span>\n</td>\n</tr>\n");
  }
  if (haveDiff == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='diff:system.web.showDiff|true:system.web.showDiff|false'>\n");
    write("<input type='checkbox' name='checkbox.diff' value='true' ");
    if (showDiff == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id='wvs_diff'></span>\n</td>\n</tr>\n");
  }
  if (haveAlm == "true")
  {
    write("<tr\n><td class='tdts_nw'>\n<input type='hidden' name='checkboxdescr' value='alarm:system.web.showAlarm|true:system.web.showAlarm|false'>\n");
    write("<input type='checkbox' name='checkbox.alarm' value='true' ");
    if (showAlm == "true")
      write("checked");
    write(" style='visibility:hidden;'>\n<span id='wvs_alm'></span>\n</td>\n</tr>\n");
  }
  write("</table>\n</td>\n</tr>\n");
}
%>
   <tr>
      <td class="tdt">
        <br>
        <input type="hidden" name="system.autosync" value="2">
        <input type="submit" value="" name="wvs_submit" class="update" style="visibility:hidden;">
      </td>
   </form>
</table>
</body>
</html>